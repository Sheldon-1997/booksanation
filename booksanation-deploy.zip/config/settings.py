"""
Django settings for Books A Nation (booksanation.com).

Environment-driven: copy .env.example to .env for production values.
Dev runs out of the box with SQLite and DEBUG=True.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# --- Optional .env loader (no external dependency) ---------------------------
_env_file = BASE_DIR / ".env"
if _env_file.exists():
    for _line in _env_file.read_text().splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _, _v = _line.partition("=")
            os.environ.setdefault(_k.strip(), _v.strip())

def env(key, default=None):
    return os.environ.get(key, default)

def env_bool(key, default=False):
    return str(env(key, default)).lower() in ("1", "true", "yes", "on")

# --- Core ---------------------------------------------------------------------
SECRET_KEY = env("DJANGO_SECRET_KEY", "dev-only-insecure-key-change-me")
DEBUG = env_bool("DJANGO_DEBUG", True)

ALLOWED_HOSTS = [h for h in env(
    "DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1,booksanation.com,www.booksanation.com"
).split(",") if h]

CSRF_TRUSTED_ORIGINS = [o for o in env(
    "DJANGO_CSRF_TRUSTED_ORIGINS",
    "https://booksanation.com,https://www.booksanation.com",
).split(",") if o]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.sitemaps",
    "core",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "core.context_processors.site_info",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

# --- Database -----------------------------------------------------------------
if env("POSTGRES_DB"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": env("POSTGRES_DB"),
            "USER": env("POSTGRES_USER", "booksanation"),
            "PASSWORD": env("POSTGRES_PASSWORD", ""),
            "HOST": env("POSTGRES_HOST", "127.0.0.1"),
            "PORT": env("POSTGRES_PORT", "5432"),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = env("DJANGO_TIME_ZONE", "America/New_York")
USE_I18N = True
USE_TZ = True

# --- Static & media -------------------------------------------------------------
STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# --- Email --------------------------------------------------------------------
# booksanation.com mail is GoDaddy "Professional Email powered by Titan" (MX secureserver.net),
# so the default outgoing server is GoDaddy's. Every inquiry, chat message and story goes to
# INQUIRY_NOTIFY_EMAIL, the owner's Titan inbox. Only EMAIL_HOST_USER and EMAIL_HOST_PASSWORD need
# to be set in .env. Override EMAIL_HOST/PORT if the mailbox moves elsewhere.
EMAIL_BACKEND = env(
    "DJANGO_EMAIL_BACKEND",
    "django.core.mail.backends.console.EmailBackend" if DEBUG
    else "django.core.mail.backends.smtp.EmailBackend",
)
EMAIL_HOST = env("EMAIL_HOST", "smtpout.secureserver.net")
EMAIL_PORT = int(env("EMAIL_PORT", "465"))
EMAIL_USE_SSL = env_bool("EMAIL_USE_SSL", EMAIL_PORT == 465)
EMAIL_USE_TLS = env_bool("EMAIL_USE_TLS", not EMAIL_USE_SSL)
EMAIL_TIMEOUT = 15
EMAIL_HOST_USER = env("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", "")
# The server's .env once set DJANGO_EMAIL_BACKEND to the console backend, which only prints
# mail to the log. In production with a mailbox configured, mail must really be sent.
if not DEBUG and EMAIL_HOST_USER and EMAIL_HOST_PASSWORD and EMAIL_BACKEND.endswith((".console.EmailBackend", ".dummy.EmailBackend")):
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", "Books A Nation <support@booksanation.com>")
INQUIRY_NOTIFY_EMAIL = env("INQUIRY_NOTIFY_EMAIL", "support@booksanation.com")

# --- Site identity (shown across the site) -------------------------------------
SITE_NAME = "Books A Nation"
SITE_DOMAIN = env("SITE_DOMAIN", "booksanation.com")
SITE_BASE_URL = env("SITE_BASE_URL", "https://booksanation.com")
CONTACT_EMAIL = env("CONTACT_EMAIL", "support@booksanation.com")
# Leave empty until the owner supplies the business number; the UI hides it when blank.
# Toll free number confirmed by the owner on 3 November 2026.
CONTACT_PHONE = env("CONTACT_PHONE", "+18663242109")
CONTACT_PHONE_DISPLAY = env("CONTACT_PHONE_DISPLAY", "1 (866) 324-2109")
# Business address lines separated by " | " (for example "12 Example Street | London | United Kingdom").
# Leave empty until the owner confirms a real address; nothing is shown when blank.
CONTACT_ADDRESS = env("CONTACT_ADDRESS", "47 Bergen Street, 3rd Floor | Brooklyn, NY 11201 | United States")
CONTACT_ADDRESS_LINES = [line.strip() for line in CONTACT_ADDRESS.split("|") if line.strip()]
# Structured form of the same address for the Organization schema (owner confirmed 2026-11-07).
CONTACT_POSTAL_ADDRESS = {
    "streetAddress": env("CONTACT_STREET", "47 Bergen Street, 3rd Floor"),
    "addressLocality": env("CONTACT_CITY", "Brooklyn"),
    "addressRegion": env("CONTACT_REGION", "NY"),
    "postalCode": env("CONTACT_POSTCODE", "11201"),
    "addressCountry": env("CONTACT_COUNTRY", "US"),
} if CONTACT_ADDRESS_LINES else {}
# Official social and business profiles. Only confirmed URLs belong here; blank entries are hidden everywhere.
# An env var SOCIAL_<KEY> overrides the code default, so a profile can be added by a normal code release.
# Every URL goes into the Organization schema (sameAs), which is how Google links the brand's profiles
# into one entity (knowledge panel). Profiles with footer=True also get an icon in the site footer.
SOCIAL_DEFAULTS = {
    "facebook": "https://www.facebook.com/BooksANation", "instagram": "https://www.instagram.com/books.a.nation/", "linkedin": "", "x": "", "youtube": "", "tiktok": "", "pinterest": "",
    "crunchbase": "", "trustpilot": "",
}
SOCIAL_LINKS = [
    {"key": key, "label": label, "footer": footer, "url": env(f"SOCIAL_{key.upper()}", "") or SOCIAL_DEFAULTS[key]}
    for key, label, footer in [
        ("facebook", "Facebook", True), ("instagram", "Instagram", True), ("linkedin", "LinkedIn", True),
        ("x", "X", True), ("youtube", "YouTube", True), ("tiktok", "TikTok", True), ("pinterest", "Pinterest", True),
        ("crunchbase", "Crunchbase", False), ("trustpilot", "Trustpilot", False),
    ]
]
SOCIAL_LINKS = [s for s in SOCIAL_LINKS if s["url"]]
SOCIAL_FOOTER_LINKS = [s for s in SOCIAL_LINKS if s["footer"]]

# IndexNow key (Bing, Yandex and partners). The key file is served at /<key>.txt.
INDEXNOW_KEY = env("INDEXNOW_KEY", "2801e0d633fa96015c0c6f8ef5b267d7")
# Google Search Console HTML tag verification token (content attribute only). Blank = tag not rendered.
GOOGLE_SITE_VERIFICATION = env("GOOGLE_SITE_VERIFICATION", "")
# Bing Webmaster Tools: paste the content value of the msvalidate.01 meta tag,
# or the BingSiteAuth.xml user id, into .env and the site verifies itself.
BING_SITE_VERIFICATION = env("BING_SITE_VERIFICATION", "")
# Contact form abuse limits
INQUIRY_MAX_PER_HOUR = int(env("INQUIRY_MAX_PER_HOUR", "5"))
CHAT_MAX_MESSAGES_PER_HOUR = int(env("CHAT_MAX_MESSAGES_PER_HOUR", "60"))
# Every chat message from a visitor is also emailed to INQUIRY_NOTIFY_EMAIL (the Titan inbox).
# Sent in a background thread so the chat stays fast; misses are retried by notify_leads.
CHAT_EMAIL_ASYNC = env_bool("CHAT_EMAIL_ASYNC", True)
# Private mail diagnostics endpoint (/ops/mail/). Only the SHA-256 of the token lives in the code.
OPS_TOKEN_SHA256 = env("OPS_TOKEN_SHA256", "d7b00e085bef24d24580433d04065c190b90685b20bb8940a7397fd1f8cbeb5a")
# Extra addresses the diagnostics endpoint may send a test email to (besides INQUIRY_NOTIFY_EMAIL).
OPS_TEST_RECIPIENTS = [
    "kevin.walker@booksanation.com", "lisa.martin@booksanation.com", "mark.william@booksanation.com",
]
# Google Search Console HTML file verification. Keep the file served even after verification succeeds.
# Tracking, call tracking and chat. Normally set in the admin under
# "Tracking and chat integrations"; these env values are only a fallback.
INTEGRATION_GTM_ID = env("GTM_ID", "")
INTEGRATION_GA4_ID = env("GA4_ID", "")
INTEGRATION_GOOGLE_ADS_ID = env("GOOGLE_ADS_ID", "")
INTEGRATION_GOOGLE_ADS_LEAD_LABEL = env("GOOGLE_ADS_LEAD_LABEL", "")
INTEGRATION_GOOGLE_ADS_CALL_LABEL = env("GOOGLE_ADS_CALL_LABEL", "")
INTEGRATION_MICROSOFT_UET_ID = env("MICROSOFT_UET_ID", "")
INTEGRATION_CALLRAIL_SWAP_URL = env("CALLRAIL_SWAP_URL", "")
INTEGRATION_TAWK_PROPERTY_ID = env("TAWK_PROPERTY_ID", "")
INTEGRATION_TAWK_WIDGET_ID = env("TAWK_WIDGET_ID", "")

GOOGLE_VERIFICATION_FILES = [f for f in env("GOOGLE_VERIFICATION_FILES", "google1d2ec52342b3c51d.html").split(",") if f]

# --- Production hardening -------------------------------------------------------
if not DEBUG:
    SECURE_SSL_REDIRECT = env_bool("DJANGO_SECURE_SSL_REDIRECT", True)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = int(env("DJANGO_HSTS_SECONDS", "2592000"))
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    X_FRAME_OPTIONS = "DENY"
    SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"


# --- Logging: lead email problems must be visible, not silent -------------------
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {"plain": {"format": "%(asctime)s %(levelname)s %(name)s: %(message)s"}},
    "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "plain"}},
    "root": {"handlers": ["console"], "level": "WARNING"},
    "loggers": {"core": {"handlers": ["console"], "level": "INFO", "propagate": False}},
}
