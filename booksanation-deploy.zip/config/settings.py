"""
Django settings for Books A Nation (booksanation.com).

Environment-driven: copy .env.example to .env for production values.
Dev runs out of the box with SQLite and DEBUG=True.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# --- Optional .env loader (no external dependency) ---------------------------
_env_file = BASE_DIR / ".env"
if _env_file.exists():
    for _line in _env_file.read_text().splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _, _v = _line.partition("=")
            os.environ.setdefault(_k.strip(), _v.strip())

def env(key, default=None):
    return os.environ.get(key, default)

def env_bool(key, default=False):
    return str(env(key, default)).lower() in ("1", "true", "yes", "on")

# --- Core ---------------------------------------------------------------------
SECRET_KEY = env("DJANGO_SECRET_KEY", "dev-only-insecure-key-change-me")
DEBUG = env_bool("DJANGO_DEBUG", True)

ALLOWED_HOSTS = [h for h in env(
    "DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1,booksanation.com,www.booksanation.com"
).split(",") if h]

CSRF_TRUSTED_ORIGINS = [o for o in env(
    "DJANGO_CSRF_TRUSTED_ORIGINS",
    "https://booksanation.com,https://www.booksanation.com",
).split(",") if o]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.sitemaps",
    "core",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "core.context_processors.site_info",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

# --- Database -----------------------------------------------------------------
if env("POSTGRES_DB"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": env("POSTGRES_DB"),
            "USER": env("POSTGRES_USER", "booksanation"),
            "PASSWORD": env("POSTGRES_PASSWORD", ""),
            "HOST": env("POSTGRES_HOST", "127.0.0.1"),
            "PORT": env("POSTGRES_PORT", "5432"),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = env("DJANGO_TIME_ZONE", "America/New_York")
USE_I18N = True
USE_TZ = True

# --- Static & media -------------------------------------------------------------
STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# --- Email (Titan via GoDaddy; fill real values in .env) ------------------------
EMAIL_BACKEND = env(
    "DJANGO_EMAIL_BACKEND",
    "django.core.mail.backends.console.EmailBackend" if DEBUG
    else "django.core.mail.backends.smtp.EmailBackend",
)
EMAIL_HOST = env("EMAIL_HOST", "smtp.titan.email")
EMAIL_PORT = int(env("EMAIL_PORT", "587"))
EMAIL_USE_TLS = env_bool("EMAIL_USE_TLS", True)
EMAIL_HOST_USER = env("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", "")
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", "Books A Nation <support@booksanation.com>")
INQUIRY_NOTIFY_EMAIL = env("INQUIRY_NOTIFY_EMAIL", "support@booksanation.com")

# --- Site identity (shown across the site) -------------------------------------
SITE_NAME = "Books A Nation"
SITE_DOMAIN = env("SITE_DOMAIN", "booksanation.com")
SITE_BASE_URL = env("SITE_BASE_URL", "https://booksanation.com")
CONTACT_EMAIL = env("CONTACT_EMAIL", "support@booksanation.com")
# Leave empty until the owner supplies the business number; the UI hides it when blank.
# Toll free number confirmed by the owner on 3 November 2026.
CONTACT_PHONE = env("CONTACT_PHONE", "+18663242109")
CONTACT_PHONE_DISPLAY = env("CONTACT_PHONE_DISPLAY", "1 (866) 324-2109")
# Business address lines separated by " | " (for example "12 Example Street | London | United Kingdom").
# Leave empty until the owner confirms a real address; nothing is shown when blank.
CONTACT_ADDRESS = env("CONTACT_ADDRESS", "")
CONTACT_ADDRESS_LINES = [line.strip() for line in CONTACT_ADDRESS.split("|") if line.strip()]
# Official social profiles. Only confirmed URLs belong here; blank entries are hidden everywhere.
SOCIAL_LINKS = [
    {"key": key, "label": label, "url": env(f"SOCIAL_{key.upper()}", "")}
    for key, label in [
        ("facebook", "Facebook"), ("instagram", "Instagram"), ("linkedin", "LinkedIn"),
        ("x", "X"), ("youtube", "YouTube"), ("tiktok", "TikTok"),
    ]
]
SOCIAL_LINKS = [s for s in SOCIAL_LINKS if s["url"]]

# IndexNow key (Bing, Yandex and partners). The key file is served at /<key>.txt.
INDEXNOW_KEY = env("INDEXNOW_KEY", "2801e0d633fa96015c0c6f8ef5b267d7")
# Google Search Console HTML tag verification token (content attribute only). Blank = tag not rendered.
GOOGLE_SITE_VERIFICATION = env("GOOGLE_SITE_VERIFICATION", "")

# --- Production hardening -------------------------------------------------------
if not DEBUG:
    SECURE_SSL_REDIRECT = env_bool("DJANGO_SECURE_SSL_REDIRECT", True)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = int(env("DJANGO_HSTS_SECONDS", "2592000"))
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    X_FRAME_OPTIONS = "DENY"
    SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"
