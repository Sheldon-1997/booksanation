"""Create the admin sign-in from .env, so nobody has to type it on the server console.

Put these two lines in /srv/booksanation/.env and the account exists within the hour:
    DJANGO_SUPERUSER_USERNAME=owner
    DJANGO_SUPERUSER_PASSWORD=<a long password>
Optional: DJANGO_SUPERUSER_EMAIL. The password is applied again if it changes in .env.
"""
import os

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Create or update the admin user from DJANGO_SUPERUSER_* in the environment"

    def handle(self, *args, **options):
        username = os.environ.get("DJANGO_SUPERUSER_USERNAME", "").strip()
        password = os.environ.get("DJANGO_SUPERUSER_PASSWORD", "")
        email = os.environ.get("DJANGO_SUPERUSER_EMAIL", "").strip()
        if not username or not password:
            self.stdout.write("ensure_admin: DJANGO_SUPERUSER_USERNAME/PASSWORD not set, nothing to do")
            return
        if len(password) < 10:
            self.stderr.write("ensure_admin: password must be at least 10 characters")
            return
        User = get_user_model()
        user, created = User.objects.get_or_create(username=username, defaults={"email": email})
        changed = created or not user.check_password(password)
        user.is_staff = True
        user.is_superuser = True
        user.is_active = True
        if email and user.email != email:
            user.email = email
        if changed:
            user.set_password(password)
        user.save()
        self.stdout.write(f"ensure_admin: {'created' if created else 'updated' if changed else 'ok'} {username}")
