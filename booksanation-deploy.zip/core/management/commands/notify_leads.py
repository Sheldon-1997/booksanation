"""Re-send notification emails that did not go out: inquiries and live chat messages.

Run by the hourly maintenance timer on the server, so a lead or chat sent while the
mailbox password was missing or the mail server was down still reaches the Titan inbox.
"""
from django.core.management.base import BaseCommand
from django.utils import timezone

from core.models import ChatSession, Inquiry
from core.views import send_chat_email, send_inquiry_email


class Command(BaseCommand):
    help = "Re-send notification emails for inquiries and chat messages that were not emailed yet"

    def handle(self, *args, **options):
        since = timezone.now() - timezone.timedelta(days=30)
        pending = Inquiry.objects.filter(email_sent=False, created_at__gte=since).order_by("created_at")[:50]
        sent = 0
        failed = False
        for inquiry in pending:
            if send_inquiry_email(inquiry):
                sent += 1
            else:
                self.stdout.write(f"inquiry {inquiry.pk}: {inquiry.email_error}")
                failed = True
                break  # the mail server is still refusing; try again next hour
        self.stdout.write(f"notify_leads: {sent} sent, {max(0, len(pending) - sent)} still waiting")
        if failed:
            return
        quiet = timezone.now() - timezone.timedelta(minutes=2)  # leave messages the chat thread is sending
        sessions = ChatSession.objects.filter(
            messages__sender="visitor", messages__emailed=False, messages__created_at__lt=quiet,
            created_at__gte=timezone.now() - timezone.timedelta(days=7),
        ).distinct()[:50]
        chats = 0
        for session in sessions:
            if not send_chat_email(session):
                self.stdout.write(f"chat {session.pk}: email failed, will retry")
                break
            chats += 1
        self.stdout.write(f"notify_leads: {chats} chat conversations emailed")
