"""Re-send the notification email for leads whose email did not go out.

Run by the hourly maintenance timer on the server, so a lead sent while the
mailbox password was missing or the mail server was down still reaches the inbox.
"""
from django.core.management.base import BaseCommand
from django.utils import timezone

from core.models import Inquiry
from core.views import send_inquiry_email


class Command(BaseCommand):
    help = "Re-send notification emails for inquiries that were not emailed yet"

    def handle(self, *args, **options):
        since = timezone.now() - timezone.timedelta(days=30)
        pending = Inquiry.objects.filter(email_sent=False, created_at__gte=since).order_by("created_at")[:50]
        sent = 0
        for inquiry in pending:
            if send_inquiry_email(inquiry):
                sent += 1
            else:
                self.stdout.write(f"inquiry {inquiry.pk}: {inquiry.email_error}")
                break  # the mail server is still refusing; try again next hour
        self.stdout.write(f"notify_leads: {sent} sent, {max(0, len(pending) - sent)} still waiting")
