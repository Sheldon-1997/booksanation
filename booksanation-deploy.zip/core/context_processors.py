from django.conf import settings
from django.middleware.csrf import get_token


def site_info(request):
    get_token(request)  # ensure the CSRF cookie is set for the chat/inquiry APIs
    return {
        "SITE_NAME": settings.SITE_NAME,
        "SITE_BASE_URL": settings.SITE_BASE_URL,
        "CONTACT_EMAIL": settings.CONTACT_EMAIL,
        "CONTACT_PHONE": settings.CONTACT_PHONE,
        "CONTACT_PHONE_DISPLAY": settings.CONTACT_PHONE_DISPLAY or settings.CONTACT_PHONE,
        "CANONICAL_URL": settings.SITE_BASE_URL.rstrip("/") + request.path,
    }
