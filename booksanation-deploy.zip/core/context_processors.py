from pathlib import Path

import json

from django.conf import settings
from django.core.cache import cache
from django.middleware.csrf import get_token


def _site_version():
    """Deploy version from the VERSION file, used to cache-bust static assets."""
    try:
        return (Path(settings.BASE_DIR) / "VERSION").read_text().strip() or "1"
    except OSError:
        return "1"


SITE_VERSION = _site_version()


_INTEGRATION_FIELDS = (
    "gtm_id", "ga4_id", "google_ads_id", "google_ads_lead_label", "google_ads_call_label",
    "microsoft_uet_id", "callrail_swap_url", "tawk_property_id", "tawk_widget_id",
)


def _integrations():
    """IDs from the admin (Tracking and chat integrations), falling back to settings/env."""
    data = cache.get("ban-integrations")
    if data is None:
        data = {f: getattr(settings, "INTEGRATION_" + f.upper(), "") or "" for f in _INTEGRATION_FIELDS}
        try:
            from .models import SiteIntegrations

            row = SiteIntegrations.objects.filter(pk=1).first()
            if row:
                for f in _INTEGRATION_FIELDS:
                    value = (getattr(row, f) or "").strip()
                    if value:
                        data[f] = value
        except Exception:
            pass  # table missing during first migrate: fall back to settings
        cache.set("ban-integrations", data, 60)
    track = dict(data)
    track["tawk"] = bool(data["tawk_property_id"] and data["tawk_widget_id"])
    track["gtag_ids"] = [i for i in (data["ga4_id"], data["google_ads_id"]) if i]
    track["trackers"] = bool(data["gtm_id"] or track["gtag_ids"] or data["microsoft_uet_id"] or data["callrail_swap_url"])
    track["any"] = track["trackers"] or track["tawk"]
    track["json"] = json.dumps({
        "gtm": data["gtm_id"],
        "ga4": data["ga4_id"],
        "ads": data["google_ads_id"],
        "adsLead": data["google_ads_lead_label"],
        "adsCall": data["google_ads_call_label"],
        "uet": data["microsoft_uet_id"],
        "callrail": data["callrail_swap_url"],
        "tawk": (data["tawk_property_id"] + "/" + data["tawk_widget_id"]) if track["tawk"] else "",
    }).replace("<", "\\u003c")
    return track


def _site_settings():
    data = cache.get("ban-sitesettings")
    if data is None:
        data = {"promo_enabled": True,
                "promo_text": "Up to 50% off publishing packages for new authors. Get your free quote today.",
                "promo_terms": ""}
        try:
            from .models import SiteSettings

            row = SiteSettings.objects.filter(pk=1).first()
            if row:
                data = {"promo_enabled": row.promo_enabled, "promo_text": row.promo_text.strip(),
                        "promo_terms": row.promo_terms.strip()}
        except Exception:
            pass
        cache.set("ban-sitesettings", data, 60)
    return data


def site_info(request):
    get_token(request)  # ensure the CSRF cookie is set for the chat/inquiry APIs
    return {
        "SITE_NAME": settings.SITE_NAME,
        "SITE_BASE_URL": settings.SITE_BASE_URL,
        "CONTACT_EMAIL": settings.CONTACT_EMAIL,
        "CONTACT_PHONE": settings.CONTACT_PHONE,
        "CONTACT_PHONE_DISPLAY": settings.CONTACT_PHONE_DISPLAY or settings.CONTACT_PHONE,
        "CANONICAL_URL": settings.SITE_BASE_URL.rstrip("/") + request.path,
        "SITE_VERSION": SITE_VERSION,
        "CONTACT_ADDRESS_LINES": settings.CONTACT_ADDRESS_LINES,
        "CONTACT_POSTAL_ADDRESS": settings.CONTACT_POSTAL_ADDRESS,
        "SOCIAL_LINKS": settings.SOCIAL_LINKS,
        "SOCIAL_FOOTER_LINKS": settings.SOCIAL_FOOTER_LINKS,
        "GOOGLE_SITE_VERIFICATION": settings.GOOGLE_SITE_VERIFICATION,
        "TRACK": _integrations(),
        "SITE": _site_settings(),
        "BING_SITE_VERIFICATION": settings.BING_SITE_VERIFICATION,
    }
