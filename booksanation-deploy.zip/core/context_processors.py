from pathlib import Path

from django.conf import settings
from django.middleware.csrf import get_token


def _site_version():
    """Deploy version from the VERSION file, used to cache-bust static assets."""
    try:
        return (Path(settings.BASE_DIR) / "VERSION").read_text().strip() or "1"
    except OSError:
        return "1"


SITE_VERSION = _site_version()


def site_info(request):
    get_token(request)  # ensure the CSRF cookie is set for the chat/inquiry APIs
    return {
        "SITE_NAME": settings.SITE_NAME,
        "SITE_BASE_URL": settings.SITE_BASE_URL,
        "CONTACT_EMAIL": settings.CONTACT_EMAIL,
        "CONTACT_PHONE": settings.CONTACT_PHONE,
        "CONTACT_PHONE_DISPLAY": settings.CONTACT_PHONE_DISPLAY or settings.CONTACT_PHONE,
        "CANONICAL_URL": settings.SITE_BASE_URL.rstrip("/") + request.path,
        "SITE_VERSION": SITE_VERSION,
        "CONTACT_ADDRESS_LINES": settings.CONTACT_ADDRESS_LINES,
        "SOCIAL_LINKS": settings.SOCIAL_LINKS,
        "GOOGLE_SITE_VERIFICATION": settings.GOOGLE_SITE_VERIFICATION,
    }
