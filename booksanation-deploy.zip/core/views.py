import io
import json
import secrets

from django.conf import settings
from django.core.mail import send_mail
from django.http import Http404, JsonResponse
from django.core.files.base import ContentFile
from django.shortcuts import redirect, render
from django.utils.html import escape
from django.views.decorators.http import require_GET, require_POST

from .data import TESTIMONIALS, FAQS, GENRE_TILES, PLATFORMS, SERVICES, STUDIO_COVERS, STUDIO_PICKER
from .models import ChatMessage, ChatSession, Inquiry, Testimonial


# --------------------------------------------------------------------------- #
#  Pages
# --------------------------------------------------------------------------- #

def home(request):
    return render(request, "core/home.html", {
        "services": SERVICES,
        "platforms": PLATFORMS,
        "covers": STUDIO_COVERS,
        "genres": GENRE_TILES,
        "meta_title": "Books A Nation | Self Publishing and Book Publishing Services for Authors",
        "meta_description": (
            "Books A Nation is a book publishing and self publishing company for "
            "authors. We edit, design, format, publish and market your book "
            "worldwide, on Amazon KDP, IngramSpark, Apple Books, Barnes and Noble "
            "and more. You keep your rights and your royalties."
        ),
    })


def about(request):
    return render(request, "core/about.html", {
        "meta_title": "About Us | Books A Nation",
        "meta_description": (
            "Books A Nation is an independent publishing services company. We "
            "work for authors: your book, your rights, your royalties."
        ),
    })


def services_index(request):
    return render(request, "core/services.html", {
        "services": SERVICES,
        "meta_title": "Publishing Services | Books A Nation",
        "meta_description": (
            "Editing, cover design, interior formatting, publishing and book "
            "marketing. Professional services for independent authors."
        ),
    })


def service_detail(request, slug):
    service = SERVICES.get(slug)
    if not service:
        raise Http404
    others = {k: v for k, v in SERVICES.items() if k != slug}
    return render(request, "core/service_detail.html", {
        "slug": slug,
        "service": service,
        "others": others,
        "meta_title": f"{service['name']} | Books A Nation",
        "meta_description": service["short"],
    })


def platforms_index(request):
    return render(request, "core/platforms.html", {
        "platforms": PLATFORMS,
        "meta_title": "Publishing Platforms | Books A Nation",
        "meta_description": (
            "We publish authors' books worldwide, on Amazon KDP, IngramSpark, "
            "Lulu, Kobo, B&N Press, Draft2Digital, Apple Books, Google Play "
            "Books and more."
        ),
    })


def platform_detail(request, slug):
    platform = PLATFORMS.get(slug)
    if not platform:
        raise Http404
    others = {k: v for k, v in PLATFORMS.items() if k != slug}
    return render(request, "core/platform_detail.html", {
        "slug": slug,
        "platform": platform,
        "others": others,
        "meta_title": f"Publishing on {platform['name']} | Books A Nation",
        "meta_description": platform["short"],
    })


def studio(request):
    return render(request, "core/studio.html", {
        "covers": STUDIO_PICKER,
        "meta_title": "The Studio | From Manuscript to Finished Book | Books A Nation",
        "meta_description": (
            "An interactive look at how a manuscript becomes a finished book: "
            "editing, cover design, formatting and the final printed copy."
        ),
    })


def contact(request):
    return render(request, "core/contact.html", {
        "services": SERVICES,
        "meta_title": "Contact Us | Books A Nation",
        "meta_description": (
            "Tell us about your book. Reach Books A Nation by contact form, "
            "live chat or email at support@booksanation.com."
        ),
    })


def faq(request):
    return render(request, "core/faq.html", {
        "faqs": FAQS,
        "faq_json": json.dumps({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": f["q"],
                    "acceptedAnswer": {"@type": "Answer", "text": f["a"]},
                }
                for f in FAQS
            ],
        }),
        "meta_title": "Frequently Asked Questions | Books A Nation",
        "meta_description": (
            "Answers about rights, royalties, platforms, timelines and pricing "
            "at Books A Nation."
        ),
    })


def _testimonial_entries():
    entries = []
    for t in Testimonial.objects.filter(approved=True, consent=True):
        entries.append({
            "name": t.name,
            "book": t.book_title,
            "quote": t.quote,
            "photo_url": t.photo.url if t.photo else "",
            "location": t.location,
        })
    for t in TESTIMONIALS:
        entries.append({**t, "photo_url": settings.STATIC_URL + t["photo"] if t.get("photo") else ""})
    return entries


def testimonials(request):
    return render(request, "core/testimonials.html", {
        "testimonials": _testimonial_entries(),
        "shared": request.GET.get("shared") == "1",
        "form_errors": [],
        "form_data": {},
        "meta_title": "Author Stories and Testimonials | Books A Nation",
        "meta_description": (
            "Hear from authors who published with Books A Nation. Real stories, "
            "shared with permission, about editing, cover design and publishing worldwide."
        ),
    })


MAX_PHOTO_BYTES = 8 * 1024 * 1024


def _process_photo(upload):
    """Validate the upload with Pillow, strip metadata, fit inside 1600px, return JPEG bytes."""
    from PIL import Image, ImageOps, UnidentifiedImageError

    if upload.size > MAX_PHOTO_BYTES:
        raise ValueError("Please choose a photo under 8 MB.")
    try:
        img = Image.open(upload)
        img.load()
    except (UnidentifiedImageError, OSError):
        raise ValueError("That file is not a photo we can read. Please use a JPG or PNG.")
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("RGB", "L"):
        img = img.convert("RGB")
    elif img.mode == "L":
        img = img.convert("RGB")
    img.thumbnail((1600, 1600), Image.LANCZOS)
    if img.width < 300 or img.height < 300:
        raise ValueError("That photo is very small. Please send one at least 300 pixels wide.")
    out = io.BytesIO()
    img.save(out, format="JPEG", quality=86, optimize=True, progressive=True)
    return out.getvalue()


@require_POST
def testimonial_submit(request):
    data = request.POST
    if data.get("website"):  # honeypot field, bots fill it in
        return redirect("/testimonials/?shared=1")

    name = _clean(data.get("name"), 120)
    email = _clean(data.get("email"), 254)
    book_title = _clean(data.get("book_title"), 200)
    location = _clean(data.get("location"), 120)
    quote = _clean(data.get("quote"), 900)
    consent = data.get("consent") == "on"

    errors = []
    if not name:
        errors.append("Please add your name.")
    if not email or "@" not in email:
        errors.append("Please add a working email address.")
    if not book_title:
        errors.append("Please add the title of your book.")
    if len(quote) < 40:
        errors.append("Please write a few sentences about your experience, at least 40 characters.")
    if not consent:
        errors.append("Please tick the permission box so we can show your story.")

    photo_bytes = None
    upload = request.FILES.get("photo")
    if upload:
        try:
            photo_bytes = _process_photo(upload)
        except ValueError as exc:
            errors.append(str(exc))

    if errors:
        return render(request, "core/testimonials.html", {
            "testimonials": _testimonial_entries(),
            "shared": False,
            "form_errors": errors,
            "form_data": {"name": name, "email": email, "book_title": book_title,
                          "location": location, "quote": quote},
            "meta_title": "Author Stories and Testimonials | Books A Nation",
            "meta_description": "Share your publishing story with Books A Nation.",
        }, status=400)

    t = Testimonial(
        name=name, email=email, book_title=book_title, location=location,
        quote=quote, consent=consent,
        submitted_ip=(request.META.get("HTTP_X_FORWARDED_FOR", "").split(",")[0].strip()
                      or request.META.get("REMOTE_ADDR")),
    )
    if photo_bytes:
        t.photo.save("photo.jpg", ContentFile(photo_bytes), save=False)
    t.save()

    try:
        send_mail(
            subject=f"New author story from {t.name} | Books A Nation",
            message=(
                f"Name: {t.name}\nEmail: {t.email}\nBook: {t.book_title}\n"
                f"Location: {t.location or 'not given'}\nPhoto: {'yes' if t.photo else 'no'}\n\n"
                f"{t.quote}\n\nApprove it in the admin panel: "
                f"{settings.SITE_BASE_URL.rstrip('/')}/admin/core/testimonial/{t.pk}/change/"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.INQUIRY_NOTIFY_EMAIL],
            fail_silently=True,
        )
    except Exception:
        pass

    return redirect("/testimonials/?shared=1")


def privacy(request):
    return render(request, "core/privacy.html", {
        "meta_title": "Privacy Policy | Books A Nation",
        "meta_description": "How Books A Nation collects, uses and protects your information.",
    })


def terms(request):
    return render(request, "core/terms.html", {
        "meta_title": "Terms of Service | Books A Nation",
        "meta_description": "The terms that govern use of booksanation.com and our services.",
    })


def robots_txt(request):
    content = (
        "User-agent: *\n"
        "Allow: /\n"
        f"Sitemap: {settings.SITE_BASE_URL.rstrip('/')}/sitemap.xml\n"
    )
    from django.http import HttpResponse
    return HttpResponse(content, content_type="text/plain")


def handler404(request, exception=None):
    return render(request, "core/404.html", status=404)


# --------------------------------------------------------------------------- #
#  Inquiry form + live chat API
# --------------------------------------------------------------------------- #

def _clean(value, limit=2000):
    return escape(str(value or "").strip())[:limit]


@require_POST
def submit_inquiry(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        data = request.POST

    name = _clean(data.get("name"), 120)
    email = _clean(data.get("email"), 254)
    message = _clean(data.get("message"), 4000)
    if not (name and email and message):
        return JsonResponse({"ok": False, "error": "Please fill in your name, email and message."}, status=400)

    service = data.get("service", "publishing")
    if service not in dict(Inquiry.SERVICE_CHOICES):
        service = "other"

    inquiry = Inquiry.objects.create(
        name=name,
        email=email,
        phone=_clean(data.get("phone"), 40),
        service=service,
        message=message,
        page=_clean(data.get("page"), 200),
    )

    try:
        send_mail(
            subject=f"New inquiry from {inquiry.name} | Books A Nation",
            message=(
                f"Name: {inquiry.name}\nEmail: {inquiry.email}\n"
                f"Phone: {inquiry.phone or 'not given'}\nService: {inquiry.get_service_display()}\n"
                f"Page: {inquiry.page or 'not given'}\n\n{inquiry.message}"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.INQUIRY_NOTIFY_EMAIL],
            fail_silently=True,
        )
    except Exception:
        pass  # The inquiry is stored either way; email is best-effort.

    return JsonResponse({"ok": True})


@require_POST
def chat_send(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return JsonResponse({"ok": False}, status=400)

    body = _clean(data.get("body"), 2000)
    if not body:
        return JsonResponse({"ok": False, "error": "Empty message."}, status=400)

    key = _clean(data.get("session"), 64)
    session = None
    if key:
        session = ChatSession.objects.filter(session_key=key).first()
    if session is None:
        key = secrets.token_hex(16)
        session = ChatSession.objects.create(
            session_key=key,
            visitor_name=_clean(data.get("name"), 120),
            visitor_email=_clean(data.get("email"), 254),
        )
    else:
        updated = False
        if not session.visitor_name and data.get("name"):
            session.visitor_name = _clean(data.get("name"), 120)
            updated = True
        if not session.visitor_email and data.get("email"):
            session.visitor_email = _clean(data.get("email"), 254)
            updated = True
        if updated:
            session.save(update_fields=["visitor_name", "visitor_email"])

    ChatMessage.objects.create(session=session, sender="visitor", body=body)
    return JsonResponse({"ok": True, "session": key})


@require_GET
def chat_poll(request):
    key = _clean(request.GET.get("session"), 64)
    after = request.GET.get("after", "0")
    try:
        after_id = int(after)
    except ValueError:
        after_id = 0

    session = ChatSession.objects.filter(session_key=key).first()
    if session is None:
        return JsonResponse({"ok": True, "messages": []})

    messages = [
        {"id": m.id, "sender": m.sender, "body": m.body,
         "at": m.created_at.strftime("%H:%M")}
        for m in session.messages.filter(id__gt=after_id)
    ]
    return JsonResponse({"ok": True, "messages": messages})
