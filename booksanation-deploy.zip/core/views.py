import json
import secrets

from django.conf import settings
from django.core.mail import send_mail
from django.http import Http404, JsonResponse
from django.shortcuts import render
from django.utils.html import escape
from django.views.decorators.http import require_GET, require_POST

from .data import TESTIMONIALS, FAQS, GENRE_TILES, PLATFORMS, SERVICES, STUDIO_COVERS, STUDIO_PICKER
from .models import ChatMessage, ChatSession, Inquiry


# --------------------------------------------------------------------------- #
#  Pages
# --------------------------------------------------------------------------- #

def home(request):
    return render(request, "core/home.html", {
        "services": SERVICES,
        "platforms": PLATFORMS,
        "covers": STUDIO_COVERS,
        "genres": GENRE_TILES,
        "meta_title": "Books A Nation | Self Publishing and Book Publishing Services for Authors",
        "meta_description": (
            "Books A Nation is a book publishing and self publishing company for "
            "authors. We edit, design, format, publish and market your book "
            "worldwide, on Amazon KDP, IngramSpark, Apple Books, Barnes and Noble "
            "and more. You keep your rights and your royalties."
        ),
    })


def about(request):
    return render(request, "core/about.html", {
        "meta_title": "About Us | Books A Nation",
        "meta_description": (
            "Books A Nation is an independent publishing services company. We "
            "work for authors: your book, your rights, your royalties."
        ),
    })


def services_index(request):
    return render(request, "core/services.html", {
        "services": SERVICES,
        "meta_title": "Publishing Services | Books A Nation",
        "meta_description": (
            "Editing, cover design, interior formatting, publishing and book "
            "marketing. Professional services for independent authors."
        ),
    })


def service_detail(request, slug):
    service = SERVICES.get(slug)
    if not service:
        raise Http404
    others = {k: v for k, v in SERVICES.items() if k != slug}
    return render(request, "core/service_detail.html", {
        "slug": slug,
        "service": service,
        "others": others,
        "meta_title": f"{service['name']} | Books A Nation",
        "meta_description": service["short"],
    })


def platforms_index(request):
    return render(request, "core/platforms.html", {
        "platforms": PLATFORMS,
        "meta_title": "Publishing Platforms | Books A Nation",
        "meta_description": (
            "We publish authors' books worldwide, on Amazon KDP, IngramSpark, "
            "Lulu, Kobo, B&N Press, Draft2Digital, Apple Books, Google Play "
            "Books and more."
        ),
    })


def platform_detail(request, slug):
    platform = PLATFORMS.get(slug)
    if not platform:
        raise Http404
    others = {k: v for k, v in PLATFORMS.items() if k != slug}
    return render(request, "core/platform_detail.html", {
        "slug": slug,
        "platform": platform,
        "others": others,
        "meta_title": f"Publishing on {platform['name']} | Books A Nation",
        "meta_description": platform["short"],
    })


def studio(request):
    return render(request, "core/studio.html", {
        "covers": STUDIO_PICKER,
        "meta_title": "The Studio | From Manuscript to Finished Book | Books A Nation",
        "meta_description": (
            "An interactive look at how a manuscript becomes a finished book: "
            "editing, cover design, formatting and the final printed copy."
        ),
    })


def contact(request):
    return render(request, "core/contact.html", {
        "services": SERVICES,
        "meta_title": "Contact Us | Books A Nation",
        "meta_description": (
            "Tell us about your book. Reach Books A Nation by contact form, "
            "live chat or email at support@booksanation.com."
        ),
    })


def faq(request):
    return render(request, "core/faq.html", {
        "faqs": FAQS,
        "faq_json": json.dumps({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": f["q"],
                    "acceptedAnswer": {"@type": "Answer", "text": f["a"]},
                }
                for f in FAQS
            ],
        }),
        "meta_title": "Frequently Asked Questions | Books A Nation",
        "meta_description": (
            "Answers about rights, royalties, platforms, timelines and pricing "
            "at Books A Nation."
        ),
    })


def testimonials(request):
    return render(request, "core/testimonials.html", {
        "testimonials": TESTIMONIALS,
        "meta_title": "Author Stories and Testimonials | Books A Nation",
        "meta_description": (
            "Hear from authors who published with Books A Nation. Real stories, "
            "shared with permission, about editing, cover design and publishing worldwide."
        ),
    })


def privacy(request):
    return render(request, "core/privacy.html", {
        "meta_title": "Privacy Policy | Books A Nation",
        "meta_description": "How Books A Nation collects, uses and protects your information.",
    })


def terms(request):
    return render(request, "core/terms.html", {
        "meta_title": "Terms of Service | Books A Nation",
        "meta_description": "The terms that govern use of booksanation.com and our services.",
    })


def robots_txt(request):
    content = (
        "User-agent: *\n"
        "Allow: /\n"
        f"Sitemap: {settings.SITE_BASE_URL.rstrip('/')}/sitemap.xml\n"
    )
    from django.http import HttpResponse
    return HttpResponse(content, content_type="text/plain")


def handler404(request, exception=None):
    return render(request, "core/404.html", status=404)


# --------------------------------------------------------------------------- #
#  Inquiry form + live chat API
# --------------------------------------------------------------------------- #

def _clean(value, limit=2000):
    return escape(str(value or "").strip())[:limit]


@require_POST
def submit_inquiry(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        data = request.POST

    name = _clean(data.get("name"), 120)
    email = _clean(data.get("email"), 254)
    message = _clean(data.get("message"), 4000)
    if not (name and email and message):
        return JsonResponse({"ok": False, "error": "Please fill in your name, email and message."}, status=400)

    service = data.get("service", "publishing")
    if service not in dict(Inquiry.SERVICE_CHOICES):
        service = "other"

    inquiry = Inquiry.objects.create(
        name=name,
        email=email,
        phone=_clean(data.get("phone"), 40),
        service=service,
        message=message,
        page=_clean(data.get("page"), 200),
    )

    try:
        send_mail(
            subject=f"New inquiry from {inquiry.name} | Books A Nation",
            message=(
                f"Name: {inquiry.name}\nEmail: {inquiry.email}\n"
                f"Phone: {inquiry.phone or 'not given'}\nService: {inquiry.get_service_display()}\n"
                f"Page: {inquiry.page or 'not given'}\n\n{inquiry.message}"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.INQUIRY_NOTIFY_EMAIL],
            fail_silently=True,
        )
    except Exception:
        pass  # The inquiry is stored either way; email is best-effort.

    return JsonResponse({"ok": True})


@require_POST
def chat_send(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return JsonResponse({"ok": False}, status=400)

    body = _clean(data.get("body"), 2000)
    if not body:
        return JsonResponse({"ok": False, "error": "Empty message."}, status=400)

    key = _clean(data.get("session"), 64)
    session = None
    if key:
        session = ChatSession.objects.filter(session_key=key).first()
    if session is None:
        key = secrets.token_hex(16)
        session = ChatSession.objects.create(
            session_key=key,
            visitor_name=_clean(data.get("name"), 120),
            visitor_email=_clean(data.get("email"), 254),
        )
    else:
        updated = False
        if not session.visitor_name and data.get("name"):
            session.visitor_name = _clean(data.get("name"), 120)
            updated = True
        if not session.visitor_email and data.get("email"):
            session.visitor_email = _clean(data.get("email"), 254)
            updated = True
        if updated:
            session.save(update_fields=["visitor_name", "visitor_email"])

    ChatMessage.objects.create(session=session, sender="visitor", body=body)
    return JsonResponse({"ok": True, "session": key})


@require_GET
def chat_poll(request):
    key = _clean(request.GET.get("session"), 64)
    after = request.GET.get("after", "0")
    try:
        after_id = int(after)
    except ValueError:
        after_id = 0

    session = ChatSession.objects.filter(session_key=key).first()
    if session is None:
        return JsonResponse({"ok": True, "messages": []})

    messages = [
        {"id": m.id, "sender": m.sender, "body": m.body,
         "at": m.created_at.strftime("%H:%M")}
        for m in session.messages.filter(id__gt=after_id)
    ]
    return JsonResponse({"ok": True, "messages": messages})
