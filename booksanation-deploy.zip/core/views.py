import io
import json
import logging
import secrets
import time

from django.conf import settings
from django.core.mail import send_mail
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.utils import timezone
from django.http import Http404, JsonResponse
from django.core.files.base import ContentFile
from django.shortcuts import redirect, render
from django.utils.html import escape
from django.views.decorators.http import require_GET, require_POST

from .data import DRAFT_SERVICES, FAQS, GENRE_TILES, PLATFORMS, SERVICES, STUDIO_COVERS, STUDIO_PICKER, TESTIMONIALS
from .portfolio import CLIENT_COVERS, CLIENT_COVER_QUESTIONS, GENRE_LABELS, PROJECTS_BY_SLUG, STUDIO_PROJECTS
from .resources import RESOURCES, RESOURCES_BY_SLUG
from .models import ChatMessage, ChatSession, Inquiry, Testimonial

log = logging.getLogger("core")


# --------------------------------------------------------------------------- #
#  Structured data helpers
# --------------------------------------------------------------------------- #

_SMALL_WORDS = {"and", "for", "of", "the", "to", "a", "an", "in", "on", "with"}


def _title_case(text):
    words = text.split()
    return " ".join(w if (i and w.lower() in _SMALL_WORDS) else w[:1].upper() + w[1:] for i, w in enumerate(words))


def _abs(path):
    return settings.SITE_BASE_URL.rstrip("/") + path


def _breadcrumbs(items):
    """items: list of (name, path). Returns BreadcrumbList JSON-LD."""
    return json.dumps({
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "name": name, "item": _abs(path)}
            for i, (name, path) in enumerate(items)
        ],
    })


def _faq_json(faqs):
    if not faqs:
        return ""
    return json.dumps({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {"@type": "Question", "name": f["q"], "acceptedAnswer": {"@type": "Answer", "text": f["a"]}}
            for f in faqs
        ],
    })


def _service_json(slug, service):
    return json.dumps({
        "@context": "https://schema.org",
        "@type": "Service",
        "name": service["name"],
        "serviceType": service["name"],
        "description": service["short"],
        "url": _abs(f"/services/{slug}/"),
        "provider": {"@type": "Organization", "name": settings.SITE_NAME, "url": settings.SITE_BASE_URL},
    })


# --------------------------------------------------------------------------- #
#  Pages
# --------------------------------------------------------------------------- #

def home(request):
    return render(request, "core/home.html", {
        "services": SERVICES,
        "platforms": PLATFORMS,
        "covers": STUDIO_COVERS,
        "genres": GENRE_TILES,
        "meta_title": "Books A Nation | Self Publishing and Book Publishing Services for Authors",
        "meta_description": (
            "Editing, cover design, formatting and publishing for authors, on Amazon KDP, "
            "IngramSpark, Apple Books and more. You keep your rights and your royalties."
        ),
    })


def about(request):
    return render(request, "core/about.html", {
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("About", "/about/")]),
        "meta_title": "About Us | Books A Nation",
        "meta_description": (
            "Books A Nation is an independent publishing services company. We "
            "work for authors: your book, your rights, your royalties."
        ),
    })


def services_index(request):
    return render(request, "core/services.html", {
        "services": SERVICES,
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Services", "/services/")]),
        "meta_title": "Publishing Services | Books A Nation",
        "meta_description": (
            "Editing, cover design, interior formatting, publishing and book "
            "marketing. Professional services for independent authors."
        ),
    })


def _service_context(slug, service, is_draft=False):
    related_slugs = [r for r in service.get("related", []) if r in SERVICES and r != slug]
    related = {k: SERVICES[k] for k in related_slugs} or {k: v for k, v in SERVICES.items() if k != slug}
    resources = [r for r in RESOURCES if slug in r.get("related_services", [])][:3]
    return {
        "slug": slug,
        "service": service,
        "related": related,
        "resources": resources,
        "is_draft": is_draft,
        "service_json": "" if is_draft else _service_json(slug, service),
        "faq_json": "" if is_draft else _faq_json(service.get("faqs")),
        "breadcrumb_json": "" if is_draft else _breadcrumbs([("Home", "/"), ("Services", "/services/"), (service["name"], f"/services/{slug}/")]),
        "meta_title": f"{_title_case(service.get('headline', service['name']))} | Books A Nation",
        "meta_description": service["short"],
    }


def service_detail(request, slug):
    service = SERVICES.get(slug)
    if not service:
        raise Http404
    return render(request, "core/service_detail.html", _service_context(slug, service))


def draft_service(request, slug):
    """Reviewable draft of a service page that is not yet confirmed as offered."""
    service = DRAFT_SERVICES.get(slug)
    if not service:
        raise Http404
    response = render(request, "core/service_detail.html", _service_context(slug, service, is_draft=True))
    response["X-Robots-Tag"] = "noindex, nofollow"
    return response


def platforms_index(request):
    return render(request, "core/platforms.html", {
        "platforms": PLATFORMS,
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Platforms", "/platforms/")]),
        "meta_title": "Publishing Platforms | Books A Nation",
        "meta_description": (
            "We publish authors' books worldwide, on Amazon KDP, IngramSpark, "
            "Lulu, Kobo, B&N Press, Draft2Digital, Apple Books, Google Play "
            "Books and more."
        ),
    })


def platform_detail(request, slug):
    platform = PLATFORMS.get(slug)
    if not platform:
        raise Http404
    others = {k: v for k, v in PLATFORMS.items() if k != slug}
    guides = [r for r in RESOURCES if slug in r.get("related_platforms", [])]
    return render(request, "core/platform_detail.html", {
        "slug": slug,
        "platform": platform,
        "others": others,
        "guides": guides,
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Platforms", "/platforms/"), (platform["name"], f"/platforms/{slug}/")]),
        "meta_title": f"Publishing on {platform['name']} | Books A Nation",
        "meta_description": (
            f"{platform['short']} How Books A Nation sets up your book on {platform['name']}: "
            "requirements, files, pricing and royalties."
        ),
    })


def studio(request):
    return render(request, "core/studio.html", {
        "covers": STUDIO_PICKER,
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("The Studio", "/studio/")]),
        "meta_title": "The Studio | From Manuscript to Finished Book | Books A Nation",
        "meta_description": (
            "An interactive look at how a manuscript becomes a finished book: "
            "editing, cover design, formatting and the final printed copy."
        ),
    })


def contact(request):
    return render(request, "core/contact.html", {
        "services": SERVICES,
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Contact", "/contact/")]),
        "meta_title": "Contact Us | Books A Nation",
        "meta_description": (
            "Tell us about your book. Reach Books A Nation by contact form, "
            "live chat or email at support@booksanation.com."
        ),
    })


def faq(request):
    return render(request, "core/faq.html", {
        "faqs": FAQS,
        "faq_json": json.dumps({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": f["q"],
                    "acceptedAnswer": {"@type": "Answer", "text": f["a"]},
                }
                for f in FAQS
            ],
        }),
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("FAQ", "/faq/")]),
        "meta_title": "Frequently Asked Questions | Books A Nation",
        "meta_description": (
            "Answers about rights, royalties, platforms, timelines and pricing "
            "at Books A Nation."
        ),
    })


def _testimonial_entries():
    entries = []
    for t in Testimonial.objects.filter(approved=True, consent=True):
        entries.append({
            "name": t.name,
            "book": t.book_title,
            "quote": t.quote,
            "photo_url": t.photo.url if t.photo else "",
            "location": t.location,
        })
    for t in TESTIMONIALS:
        entries.append({**t, "photo_url": settings.STATIC_URL + t["photo"] if t.get("photo") else ""})
    return entries


def testimonials(request):
    return render(request, "core/testimonials.html", {
        "testimonials": _testimonial_entries(),
        "shared": request.GET.get("shared") == "1",
        "form_errors": [],
        "form_data": {},
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Author Stories", "/testimonials/")]),
        "meta_title": "Author Stories and Testimonials | Books A Nation",
        "meta_description": (
            "Hear from authors who published with Books A Nation. Real stories, "
            "shared with permission, about editing, cover design and publishing worldwide."
        ),
    })


MAX_PHOTO_BYTES = 8 * 1024 * 1024


def _process_photo(upload):
    """Validate the upload with Pillow, strip metadata, fit inside 1600px, return JPEG bytes."""
    from PIL import Image, ImageOps, UnidentifiedImageError

    if upload.size > MAX_PHOTO_BYTES:
        raise ValueError("Please choose a photo under 8 MB.")
    try:
        img = Image.open(upload)
        img.load()
    except (UnidentifiedImageError, OSError):
        raise ValueError("That file is not a photo we can read. Please use a JPG or PNG.")
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("RGB", "L"):
        img = img.convert("RGB")
    elif img.mode == "L":
        img = img.convert("RGB")
    img.thumbnail((1600, 1600), Image.LANCZOS)
    if img.width < 300 or img.height < 300:
        raise ValueError("That photo is very small. Please send one at least 300 pixels wide.")
    out = io.BytesIO()
    img.save(out, format="JPEG", quality=86, optimize=True, progressive=True)
    return out.getvalue()


@require_POST
def testimonial_submit(request):
    data = request.POST
    if data.get("website"):  # honeypot field, bots fill it in
        return redirect("/testimonials/?shared=1")

    name = _clean(data.get("name"), 120)
    email = _clean(data.get("email"), 254)
    book_title = _clean(data.get("book_title"), 200)
    location = _clean(data.get("location"), 120)
    quote = _clean(data.get("quote"), 900)
    consent = data.get("consent") == "on"

    errors = []
    if not name:
        errors.append("Please add your name.")
    if not email or "@" not in email:
        errors.append("Please add a working email address.")
    if not book_title:
        errors.append("Please add the title of your book.")
    if len(quote) < 40:
        errors.append("Please write a few sentences about your experience, at least 40 characters.")
    if not consent:
        errors.append("Please tick the permission box so we can show your story.")

    photo_bytes = None
    upload = request.FILES.get("photo")
    if upload:
        try:
            photo_bytes = _process_photo(upload)
        except ValueError as exc:
            errors.append(str(exc))

    if errors:
        return render(request, "core/testimonials.html", {
            "testimonials": _testimonial_entries(),
            "shared": False,
            "form_errors": errors,
            "form_data": {"name": name, "email": email, "book_title": book_title,
                          "location": location, "quote": quote},
            "meta_title": "Author Stories and Testimonials | Books A Nation",
            "meta_description": "Share your publishing story with Books A Nation.",
        }, status=400)

    t = Testimonial(
        name=name, email=email, book_title=book_title, location=location,
        quote=quote, consent=consent,
        submitted_ip=(request.META.get("HTTP_X_FORWARDED_FOR", "").split(",")[0].strip()
                      or request.META.get("REMOTE_ADDR")),
    )
    if photo_bytes:
        t.photo.save("photo.jpg", ContentFile(photo_bytes), save=False)
    t.save()

    try:
        send_mail(
            subject=f"New author story from {t.name} | Books A Nation",
            message=(
                f"Name: {t.name}\nEmail: {t.email}\nBook: {t.book_title}\n"
                f"Location: {t.location or 'not given'}\nPhoto: {'yes' if t.photo else 'no'}\n\n"
                f"{t.quote}\n\nApprove it in the admin panel: "
                f"{settings.SITE_BASE_URL.rstrip('/')}/admin/core/testimonial/{t.pk}/change/"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.INQUIRY_NOTIFY_EMAIL],
            fail_silently=True,
        )
    except Exception:
        pass

    return redirect("/testimonials/?shared=1")


def portfolio(request):
    genres = [(k, GENRE_LABELS[k]) for k in GENRE_LABELS if any(p["genre"] == k for p in STUDIO_PROJECTS)]
    return render(request, "core/portfolio.html", {
        "projects": STUDIO_PROJECTS,
        "client_covers": CLIENT_COVERS,
        "genres": genres,
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Portfolio", "/portfolio/")]),
        "meta_title": "Portfolio | Cover Design and Book Projects | Books A Nation",
        "meta_description": (
            "Original cover concepts from the Books A Nation studio and client covers shown "
            "with permission. Filter by genre and read how each design was approached."
        ),
    })


def portfolio_detail(request, slug):
    project = PROJECTS_BY_SLUG.get(slug)
    if not project:
        raise Http404
    others = [p for p in STUDIO_PROJECTS if p["has_page"] and p["slug"] != slug][:3]
    service_slug = project.get("service")
    return render(request, "core/portfolio_detail.html", {
        "project": project,
        "others": others,
        "service": SERVICES.get(service_slug),
        "service_slug": service_slug,
        "resource": RESOURCES_BY_SLUG.get(project.get("resource")),
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Portfolio", "/portfolio/"), (project["title"], f"/portfolio/{slug}/")]),
        "meta_title": f"{project['title']}: a {project['genre_label'].lower()} cover concept | Books A Nation",
        "meta_description": f"Studio concept: {project['subtitle']}. The brief, the design approach and what it shows about our cover design process.",
    })


def resources_index(request):
    return render(request, "core/resources.html", {
        "resources": RESOURCES,
        "platforms": PLATFORMS,
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Author Resources", "/resources/")]),
        "meta_title": "Author Resources | Self Publishing Guides | Books A Nation",
        "meta_description": (
            "Practical guides for independent authors: a self-publishing checklist, the four "
            "levels of editing, cover briefs, formatting and publishing files, ISBNs and metadata."
        ),
    })


def resource_detail(request, slug):
    article = RESOURCES_BY_SLUG.get(slug)
    if not article:
        raise Http404
    related = [RESOURCES_BY_SLUG[s] for s in article.get("related_resources", []) if s in RESOURCES_BY_SLUG]
    services = {s: SERVICES[s] for s in article.get("related_services", []) if s in SERVICES}
    platforms = {s: PLATFORMS[s] for s in article.get("related_platforms", []) if s in PLATFORMS}
    article_json = json.dumps({
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": article["title"],
        "description": article["summary"],
        "datePublished": article["published"].isoformat(),
        "dateModified": article["updated"].isoformat(),
        "author": {"@type": "Organization", "name": settings.SITE_NAME, "url": settings.SITE_BASE_URL},
        "publisher": {"@type": "Organization", "name": settings.SITE_NAME, "url": settings.SITE_BASE_URL},
        "mainEntityOfPage": _abs(f"/resources/{slug}/"),
    })
    return render(request, "core/resource_detail.html", {
        "article": article,
        "related": related,
        "services": services,
        "platforms": platforms,
        "article_json": article_json,
        "faq_json": _faq_json(article.get("faqs")),
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Author Resources", "/resources/"), (article["title"], f"/resources/{slug}/")]),
        "meta_title": f"{article['title']} | Books A Nation",
        "meta_description": article["summary"],
    })


def cookie_policy(request):
    return render(request, "core/cookie_policy.html", {
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Cookie Policy", "/cookie-policy/")]),
        "meta_title": "Cookie Policy | Books A Nation",
        "meta_description": "Which cookies and browser storage booksanation.com uses, what they do, and why no consent banner is needed.",
    })


def publishing_standards(request):
    return render(request, "core/publishing_standards.html", {
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Publishing Standards", "/publishing-standards/")]),
        "meta_title": "Publishing Standards and Author Ownership | Books A Nation",
        "meta_description": (
            "How Books A Nation works with authors: account ownership, rights and royalties, "
            "scope approval, platform independence, portfolio permission and final handoff."
        ),
    })


def refund_policy(request):
    return render(request, "core/refund_policy.html", {
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Refund and Cancellation", "/refund-and-cancellation/")]),
        "meta_title": "Refund and Cancellation Policy | Books A Nation",
        "meta_description": (
            "How cancellations and refunds work at Books A Nation: before work starts, during a "
            "project, third-party costs, revisions and how refunds are paid."
        ),
    })


def privacy(request):
    return render(request, "core/privacy.html", {
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Privacy Policy", "/privacy-policy/")]),
        "meta_title": "Privacy Policy | Books A Nation",
        "meta_description": "How Books A Nation collects, uses and protects your information.",
    })


def terms(request):
    return render(request, "core/terms.html", {
        "breadcrumb_json": _breadcrumbs([("Home", "/"), ("Terms of Service", "/terms-of-service/")]),
        "meta_title": "Terms of Service | Books A Nation",
        "meta_description": "The terms that govern use of booksanation.com and our services.",
    })


def llms_txt(request):
    """Plain text summary of the site for AI assistants and crawlers (llms.txt convention)."""
    from django.http import HttpResponse
    base = settings.SITE_BASE_URL.rstrip("/")
    lines = [
        "# Books A Nation",
        "",
        "> Books A Nation is an independent book publishing services company for authors. "
        "We edit, design, format, publish and market books, and authors keep their rights, their accounts and their royalties.",
        "",
        f"Website: {base}",
        f"Email: {settings.CONTACT_EMAIL}",
    ]
    if settings.CONTACT_PHONE:
        lines.append(f"Phone (toll free): {settings.CONTACT_PHONE_DISPLAY or settings.CONTACT_PHONE}")
    lines += ["", "## Services", ""]
    for slug, svc in SERVICES.items():
        lines.append(f"- [{svc['name']}]({base}/services/{slug}/): {svc['short']}")
    lines += ["", "## Publishing platforms we set up for authors", ""]
    for slug, plat in PLATFORMS.items():
        lines.append(f"- [{plat['name']}]({base}/platforms/{slug}/): {plat['short']}")
    lines += ["", "## Author resources (original guides)", ""]
    for r in RESOURCES:
        lines.append(f"- [{r['title']}]({base}/resources/{r['slug']}/): {r['summary']}")
    lines += [
        "", "## Key pages", "",
        f"- [Portfolio]({base}/portfolio/): studio cover concepts (fictional titles, clearly labelled) and client covers shown with permission",
        f"- [The Studio]({base}/studio/): interactive demonstration of a manuscript becoming a book",
        f"- [Author stories]({base}/testimonials/): testimonials submitted by authors in their own words",
        f"- [FAQ]({base}/faq/): rights, royalties, platforms, timelines and cost",
        f"- [Publishing standards]({base}/publishing-standards/): account ownership, rights, revisions, platform independence, handoff",
        f"- [Contact]({base}/contact/): contact form, email and live chat",
        "", "## Facts to rely on", "",
        "- Authors keep all rights to their work; Books A Nation does not acquire rights.",
        "- Books are published under the author's own platform accounts wherever possible; royalties are paid directly to the author.",
        "- Books A Nation is not affiliated with or endorsed by Amazon, Apple, Google, Kobo, Barnes and Noble, IngramSpark, Lulu or Draft2Digital; it publishes to them as independent platforms.",
        "- Studio concept covers use invented titles and author names and are not published books.",
        "- No sales, ranking or award guarantees are made.",
    ]
    return HttpResponse("\n".join(lines) + "\n", content_type="text/plain; charset=utf-8")


def google_verification(request, token):
    from django.http import HttpResponse
    filename = f"google{token}.html"
    if filename not in settings.GOOGLE_VERIFICATION_FILES:
        raise Http404
    return HttpResponse(f"google-site-verification: {filename}", content_type="text/html")


def bing_site_auth(request):
    """BingSiteAuth.xml, served when BING_SITE_VERIFICATION is set in .env."""
    from django.http import HttpResponse

    if not settings.BING_SITE_VERIFICATION:
        raise Http404
    xml = f'<?xml version="1.0"?>\n<users><user>{settings.BING_SITE_VERIFICATION}</user></users>\n'
    return HttpResponse(xml, content_type="text/xml")


def indexnow_key(request, key):
    from django.http import HttpResponse
    if key != settings.INDEXNOW_KEY:
        raise Http404
    return HttpResponse(settings.INDEXNOW_KEY, content_type="text/plain")


def robots_txt(request):
    content = (
        "User-agent: *\n"
        "Allow: /\n"
        "Disallow: /admin/\n"
        "Disallow: /api/\n"
        "Disallow: /drafts/\n"
        f"Sitemap: {settings.SITE_BASE_URL.rstrip('/')}/sitemap.xml\n"
    )
    from django.http import HttpResponse
    return HttpResponse(content, content_type="text/plain")


def handler404(request, exception=None):
    return render(request, "core/404.html", status=404)


# --------------------------------------------------------------------------- #
#  Inquiry form + live chat API
# --------------------------------------------------------------------------- #

def _clean(value, limit=2000):
    return escape(str(value or "").strip())[:limit]


def _client_ip(request):
    ip = (request.META.get("HTTP_X_FORWARDED_FOR", "").split(",")[0].strip()
          or request.META.get("REMOTE_ADDR") or "")
    return ip[:45] or None


def _looks_like_bot(data):
    """Honeypot filled, or the form was submitted faster than a person can type."""
    if data.get("website"):
        return True
    try:
        opened = float(data.get("ts") or 0)
    except (TypeError, ValueError):
        opened = 0
    return bool(opened) and (time.time() * 1000 - opened) < 3000


def send_inquiry_email(inquiry):
    """Send the notification for one inquiry. Records success or the error on the row."""
    try:
        send_mail(
            subject=f"New inquiry from {inquiry.name} | Books A Nation",
            message=(
                f"Name: {inquiry.name}\nEmail: {inquiry.email}\n"
                f"Phone: {inquiry.phone or 'not given'}\nService: {inquiry.get_service_display()}\n"
                f"Page: {inquiry.page or 'not given'}\n"
                f"Source: {inquiry.source or 'direct or unknown'}\n"
                + (f"Google Ads click ID: {inquiry.gclid}\n" if inquiry.gclid else "")
                + f"\n{inquiry.message}\n\n"
                f"Reply to the author at {inquiry.email}. "
                f"All leads: {settings.SITE_BASE_URL}/admin/core/inquiry/"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.INQUIRY_NOTIFY_EMAIL],
            fail_silently=False,
        )
        inquiry.email_sent = True
        inquiry.email_error = ""
    except Exception as exc:  # the lead is stored either way; the error is kept visible
        inquiry.email_sent = False
        inquiry.email_error = str(exc)[:200]
        log.error("Lead email failed for inquiry %s: %s", inquiry.pk, exc)
    inquiry.save(update_fields=["email_sent", "email_error"])
    return inquiry.email_sent


_ATTRIBUTION_KEYS = (
    "gclid", "gbraid", "wbraid", "msclkid", "fbclid",
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "landing", "referrer", "first_seen",
)


def _attribution(raw):
    """Keep only known ad and campaign keys from the browser, trimmed."""
    if not isinstance(raw, dict):
        return {}, "", ""
    clean = {}
    for key in _ATTRIBUTION_KEYS:
        value = raw.get(key)
        if isinstance(value, (str, int)) and str(value).strip():
            clean[key] = _clean(str(value), 300)
    gclid = clean.get("gclid", "")[:255]
    if clean.get("utm_source"):
        parts = [clean.get("utm_source"), clean.get("utm_medium"), clean.get("utm_campaign")]
        source = " / ".join(p for p in parts if p)
    elif gclid or clean.get("gbraid") or clean.get("wbraid"):
        source = "Google Ads"
    elif clean.get("msclkid"):
        source = "Microsoft Ads"
    elif clean.get("referrer"):
        source = "Referral: " + clean["referrer"]
    else:
        source = ""
    return clean, gclid, source[:200]


@require_POST
def submit_inquiry(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        data = request.POST

    name = _clean(data.get("name"), 120)
    email = _clean(data.get("email"), 254)
    message = _clean(data.get("message"), 4000)
    if not (name and email and message):
        return JsonResponse({"ok": False, "error": "Please fill in your name, email and message."}, status=400)
    try:
        validate_email(email)
    except ValidationError:
        return JsonResponse({"ok": False, "error": "That email address does not look right. Please check it."}, status=400)
    if _looks_like_bot(data):
        return JsonResponse({"ok": True})  # quietly dropped
    ip = _client_ip(request)
    if ip:
        recent = Inquiry.objects.filter(submitted_ip=ip, created_at__gte=timezone.now() - timezone.timedelta(hours=1)).count()
        if recent >= settings.INQUIRY_MAX_PER_HOUR:
            return JsonResponse({"ok": False, "error": "You have sent several messages already. We will reply to those by email."}, status=429)

    service = data.get("service", "publishing")
    if service not in dict(Inquiry.SERVICE_CHOICES):
        service = "other"

    attribution, gclid, source = _attribution(data.get("attribution"))
    inquiry = Inquiry.objects.create(
        name=name,
        email=email,
        phone=_clean(data.get("phone"), 40),
        service=service,
        message=message,
        page=_clean(data.get("page"), 200),
        gclid=gclid,
        source=source,
        attribution=attribution,
        submitted_ip=ip,
    )
    send_inquiry_email(inquiry)
    return JsonResponse({"ok": True})


@require_POST
def chat_send(request):
    try:
        data = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return JsonResponse({"ok": False}, status=400)

    body = _clean(data.get("body"), 2000)
    if not body:
        return JsonResponse({"ok": False, "error": "Empty message."}, status=400)
    if data.get("website"):
        return JsonResponse({"ok": True, "session": _clean(data.get("session"), 64) or secrets.token_hex(16)})

    key = _clean(data.get("session"), 64)
    session = None
    if key:
        session = ChatSession.objects.filter(session_key=key).first()
    if session is not None:
        recent = ChatMessage.objects.filter(
            session=session, sender="visitor", created_at__gte=timezone.now() - timezone.timedelta(hours=1)
        ).count()
        if recent >= settings.CHAT_MAX_MESSAGES_PER_HOUR:
            return JsonResponse({"ok": False, "error": "Too many messages. Please email us instead."}, status=429)
    if session is None:
        key = secrets.token_hex(16)
        session = ChatSession.objects.create(
            session_key=key,
            visitor_name=_clean(data.get("name"), 120),
            visitor_email=_clean(data.get("email"), 254),
        )
    else:
        updated = False
        if not session.visitor_name and data.get("name"):
            session.visitor_name = _clean(data.get("name"), 120)
            updated = True
        if not session.visitor_email and data.get("email"):
            session.visitor_email = _clean(data.get("email"), 254)
            updated = True
        if updated:
            session.save(update_fields=["visitor_name", "visitor_email"])

    ChatMessage.objects.create(session=session, sender="visitor", body=body)
    return JsonResponse({"ok": True, "session": key})


@require_GET
def chat_poll(request):
    key = _clean(request.GET.get("session"), 64)
    after = request.GET.get("after", "0")
    try:
        after_id = int(after)
    except ValueError:
        after_id = 0

    session = ChatSession.objects.filter(session_key=key).first()
    if session is None:
        return JsonResponse({"ok": True, "messages": []})

    messages = [
        {"id": m.id, "sender": m.sender, "body": m.body,
         "at": m.created_at.strftime("%H:%M")}
        for m in session.messages.filter(id__gt=after_id)
    ]
    return JsonResponse({"ok": True, "messages": messages})
