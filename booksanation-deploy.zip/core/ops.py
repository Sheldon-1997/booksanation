"""Private mail diagnostics for the owner's operator (no console access needed).

POST /ops/mail/ with header X-Ops-Token. Only the SHA-256 of the token is stored in the
code, so the public repository does not reveal it. Returns masked settings, delivery
counts and the last error; can test the SMTP login, send a test email to the support
inbox or one of a fixed list of company addresses, and re-send pending notifications.
"""
import hashlib
import hmac
import io
import json

from django.conf import settings
from django.core.cache import cache
from django.core.mail import EmailMessage, get_connection
from django.core.management import call_command
from django.http import Http404, JsonResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from .models import ChatMessage, Inquiry


def _mask(address):
    if not address or "@" not in address:
        return bool(address)
    local, domain = address.split("@", 1)
    return f"{local[:2]}***@{domain}"


def _authorised(request):
    expected = getattr(settings, "OPS_TOKEN_SHA256", "")
    token = request.headers.get("X-Ops-Token", "")
    return bool(expected and token) and hmac.compare_digest(
        hashlib.sha256(token.encode()).hexdigest(), expected
    )


@csrf_exempt
@require_POST
def mail(request):
    if not _authorised(request):
        raise Http404
    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
    except ValueError:
        data = {}
    month = timezone.now() - timezone.timedelta(days=30)
    last_failed = Inquiry.objects.filter(email_sent=False).order_by("-created_at").first()
    out = {
        "backend": settings.EMAIL_BACKEND.rsplit(".", 2)[-2],
        "host": settings.EMAIL_HOST, "port": settings.EMAIL_PORT,
        "ssl": settings.EMAIL_USE_SSL, "tls": settings.EMAIL_USE_TLS,
        "user": _mask(settings.EMAIL_HOST_USER), "password_set": bool(settings.EMAIL_HOST_PASSWORD),
        "from": settings.DEFAULT_FROM_EMAIL, "notify_to": settings.INQUIRY_NOTIFY_EMAIL,
        "inquiries_30d": Inquiry.objects.filter(created_at__gte=month).count(),
        "inquiries_unsent_30d": Inquiry.objects.filter(created_at__gte=month, email_sent=False).count(),
        "last_unsent_error": last_failed.email_error if last_failed else "",
        "chat_messages_unemailed": ChatMessage.objects.filter(sender="visitor", emailed=False).count(),
    }
    action = data.get("action", "")
    if action in ("login", "test", "flush") and cache.get("ops-mail-busy"):
        out["error"] = "wait 20 seconds between actions"
        return JsonResponse(out)
    cache.set("ops-mail-busy", 1, 20)
    if action == "login":
        try:
            connection = get_connection(fail_silently=False)
            connection.open()
            connection.close()
            out["login"] = "ok"
        except Exception as exc:
            out["login"] = f"failed: {exc}"[:300]
    elif action == "test":
        allowed = {settings.INQUIRY_NOTIFY_EMAIL.lower(), *[a.lower() for a in settings.OPS_TEST_RECIPIENTS]}
        to = str(data.get("to") or settings.INQUIRY_NOTIFY_EMAIL).strip().lower()
        if to not in allowed:
            out["test"] = "refused: not a company address on the list"
        else:
            stamp = timezone.localtime().strftime("%d %b %Y, %H:%M")
            try:
                EmailMessage(
                    subject=f"Test email from booksanation.com ({stamp})",
                    body=(f"This is a test from the Books A Nation website, sent {stamp}.\n\n"
                          "If it is in this inbox, website inquiries and live chat messages "
                          "will arrive here too. No reply is needed."),
                    from_email=settings.DEFAULT_FROM_EMAIL, to=[to],
                ).send(fail_silently=False)
                out["test"] = f"sent to {to}"
            except Exception as exc:
                out["test"] = f"failed: {exc}"[:300]
    elif action == "flush":
        buffer = io.StringIO()
        call_command("notify_leads", stdout=buffer)
        out["flush"] = buffer.getvalue().strip().splitlines()[-4:]
    return JsonResponse(out)
