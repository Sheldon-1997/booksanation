"""Portfolio: studio concepts and client covers for booksanation.com.

Two clearly separated kinds of work:

STUDIO CONCEPTS are original cover designs made in our studio to show what we
can do. The titles and author names on them are fictional and were created for
the concept. They are never presented as published client books.

CLIENT COVERS are real covers for real books, shown with the authors'
permission. A client cover gets a detail page only once the author credit,
Books A Nation's actual contribution and the brief have been confirmed by the
owner. Until then it appears in the gallery with an honest label and no claims.

Copy rule: plain sentences, no em dashes, en dashes, hashtags or decorative
check marks.
"""

from .data import STUDIO_COVERS

GENRE_LABELS = {
    "fiction": "Fiction",
    "thriller": "Thriller",
    "fantasy": "Fantasy",
    "children": "Children's",
    "nonfiction": "Nonfiction",
    "poetry": "Poetry",
    "education": "Education",
}

# Title and fictional author, as printed on each studio concept.
_CONCEPT_META = {
    "b1.jpg": ("Midnight Harbour", "thriller"),
    "b2.jpg": ("The Ember Crown", "fantasy"),
    "b3.jpg": ("Where the Jacarandas Bloom", "fiction"),
    "b4.jpg": ("Momo the Brave Little Fox", "children"),
    "b5.jpg": ("Letters I Never Sent", "nonfiction"),
    "b6.jpg": ("Deep Focus", "nonfiction"),
    "b7.jpg": ("The Salt Garden", "fiction"),
    "b8.jpg": ("Orbital Drift", "fiction"),
    "b9.jpg": ("The Baker of Rue Clement", "fiction"),
    "b10.jpg": ("Slow Mornings", "nonfiction"),
    "b11.jpg": ("The Lighthouse Letters", "fiction"),
    "b12.jpg": ("Static", "fiction"),
    "b13.jpg": ("The Cartographer's Daughter", "fiction"),
    "b14.jpg": ("Quiet Hours", "nonfiction"),
    "b15.jpg": ("Tiger in the Teacup", "children"),
    "b16.jpg": ("Salt and Smoke", "nonfiction"),
    "b17.jpg": ("The Ninth Door", "fiction"),
    "b18.jpg": ("Orchard Street", "nonfiction"),
    "b19.jpg": ("Ledger", "nonfiction"),
    "b20.jpg": ("Monsoon Season", "fiction"),
    "b21.jpg": ("Glass Kingdom", "fantasy"),
    "b22.jpg": ("The Long Game", "nonfiction"),
    "b23.jpg": ("Small Hours", "poetry"),
    "b24.jpg": ("Roads Less Mapped", "nonfiction"),
    "b25.jpg": ("The Harbourmaster's Wife", "fiction"),
    "b26.jpg": ("Speak Easy", "education"),
    "b27.jpg": ("Stillness Practice", "nonfiction"),
    "b28.jpg": ("Iron Bloom", "fiction"),
    "b29.jpg": ("The Sunday Table", "fiction"),
    "b30.jpg": ("Numbers That Lie", "nonfiction"),
}


def _slugify(title):
    out = "".join(ch.lower() if ch.isalnum() else "-" for ch in title)
    while "--" in out:
        out = out.replace("--", "-")
    return out.strip("-")


# Detail pages: each one is a distinct, original write-up of the concept.
CONCEPT_DETAILS = {
    "midnight-harbour": {
        "subtitle": "A detective thriller concept built around one light source",
        "brief": (
            "Design a front cover for a crime thriller set in a port city. The "
            "reader should feel the cold and the quiet of the harbour at night, "
            "and the title treatment should hold its own at thumbnail size on a phone."
        ),
        "approach": [
            "The whole image is organised around a single moon and its reflection, so the eye lands on the title and then drops to the water.",
            "A condensed sans serif in two colours lets the second word carry the genre: the red of Harbour reads as danger without a single drop of blood.",
            "The skyline is kept to pure silhouette, which prints cleanly on matte stock and avoids muddy detail at small sizes.",
            "A small series line at the foot leaves room for a sequel treatment without redesigning the cover.",
        ],
        "shows": "How a dark cover can stay legible on store pages, and how typography alone can signal a thriller.",
        "deliverables": ["Front cover concept", "Thumbnail test at 80 pixels wide", "Colour variants for a series"],
        "service": "cover-design",
        "resource": "how-to-write-a-book-cover-brief",
    },
    "the-ember-crown": {
        "subtitle": "An epic fantasy concept with a hand-built emblem",
        "brief": (
            "Create a cover for book one of a fantasy series. It needs an emblem "
            "that can carry across the series, an atmosphere of fire and night, "
            "and a title treatment that still works when book two and three sit beside it."
        ),
        "approach": [
            "A crown of flame inside a ring of light gives the series a mark that can change colour per book while staying recognisable.",
            "The palette is deep violet against gold, chosen because the two sit far apart on a store page full of blue and black fantasy covers.",
            "Title and series line are set in a wide serif with generous tracking, which reads as classic rather than gaming.",
            "Fine particle texture is kept subtle so the printed cover does not band or look noisy.",
        ],
        "shows": "Series thinking at the concept stage, so the second book does not force a redesign of the first.",
        "deliverables": ["Front cover concept", "Series emblem", "Two palette variants for later volumes"],
        "service": "cover-design",
        "resource": "how-to-write-a-book-cover-brief",
    },
    "momo-the-brave-little-fox": {
        "subtitle": "A picture book concept for readers aged three to six",
        "brief": (
            "Design a warm, simple cover for a picture book about a small fox "
            "who is scared of the dark. The character must be friendly at a glance, "
            "and the title must be readable by an adult across a room."
        ),
        "approach": [
            "The fox is drawn with a few shapes and a big expression, because young readers respond to faces before anything else.",
            "A sunset gradient gives warmth and places the story just before night without making the cover dark.",
            "The title uses a rounded hand-lettered face that matches the gentleness of the story and stays clear at board book size.",
            "Plenty of empty sky leaves room for an award sticker or a series badge without crowding the art.",
        ],
        "shows": "How much an illustrated children's book cover can say with very little, and why simplicity is a design decision, not a shortcut.",
        "deliverables": ["Front cover concept", "Character sheet for interior illustration", "Square ebook variant"],
        "service": "cover-design",
        "resource": "self-publishing-checklist-first-time-authors",
    },
    "deep-focus": {
        "subtitle": "A nonfiction concept that turns the argument into a symbol",
        "brief": (
            "Design a cover for a book about attention and distraction. It should "
            "look at home next to the big business and psychology titles, with a "
            "single graphic idea that can be used on social media and in talks."
        ),
        "approach": [
            "A ring of colour closing on one white point illustrates the idea of focus without a literal image of a brain or a phone.",
            "Black background and a heavy sans serif title follow the conventions readers expect in this category, so the book looks credible before it is opened.",
            "The subtitle is set small and plain, leaving the ring and the two-word title to do the selling.",
            "The ring works as a standalone icon for the author's website, slides and social graphics.",
        ],
        "shows": "Designing a nonfiction cover as a brand mark the author can reuse everywhere the book is discussed.",
        "deliverables": ["Front cover concept", "Icon extracted for marketing use", "Ebook cover sized for stores"],
        "service": "marketing",
        "resource": "isbn-metadata-and-publishing-files",
    },
    "the-salt-garden": {
        "subtitle": "A literary fiction concept in a single soft gradient",
        "brief": (
            "Create a quiet, elegant cover for a literary novel set on a coast. "
            "No figures, no photography. The design should feel like the book is "
            "already a modern classic."
        ),
        "approach": [
            "A pale green gradient and three slow wave lines carry the setting with almost nothing on the page.",
            "A high-contrast serif title in deep green gives the cover its weight; the italic author name below balances it.",
            "The restraint is deliberate: literary readers are suspicious of covers that shout.",
            "The same wave motif continues as the chapter opening ornament in the interior, so cover and inside feel like one object.",
        ],
        "shows": "How cover and interior design can share a visual language, which is what makes a self-published book feel professionally made.",
        "deliverables": ["Front cover concept", "Matching chapter opening ornament", "Typeset sample chapter"],
        "service": "formatting",
        "resource": "print-and-ebook-formatting-checklist",
    },
    "the-baker-of-rue-clement": {
        "subtitle": "A cosy fiction concept with an illustrated shopfront",
        "brief": (
            "Design a charming cover for a feel-good novel set in a small French "
            "bakery. It should be warm, slightly nostalgic and clearly not a thriller."
        ),
        "approach": [
            "A striped awning and a shop window are drawn flat, in the style of travel posters, which readers of the genre recognise immediately.",
            "Cream, terracotta and chocolate brown keep the palette edible and warm.",
            "The title is set in a friendly serif with a gentle arc that follows the awning, tying type and image together.",
            "Space at the top is reserved for a review quote, which cosy fiction covers commonly carry.",
        ],
        "shows": "Reading the genre's visual conventions and using them honestly, so the right reader finds the book.",
        "deliverables": ["Front cover concept", "Spot illustration for the back cover", "Instagram tile from the artwork"],
        "service": "cover-design",
        "resource": "how-to-write-a-book-cover-brief",
    },
    "the-lighthouse-letters": {
        "subtitle": "A romance concept built on light and horizon",
        "brief": (
            "Design a cover for a slow, emotional love story set over two winters "
            "on a northern shore. It should feel hopeful rather than sad, with a "
            "strong sense of place."
        ),
        "approach": [
            "A low sun, a wide sea and a single lighthouse give the cover a horizon the eye rests on.",
            "The lighthouse beam crosses the sky toward the title, a small device that quietly connects image and words.",
            "Warm oranges against deep blue read as romance from across a room and still print well on uncoated stock.",
            "The title is stacked in a classic serif so it can be large without covering the scene.",
        ],
        "shows": "Composition that leads the eye in one deliberate path: sun, beam, title, author.",
        "deliverables": ["Front cover concept", "Full wraparound layout with spine", "Ebook cover sized for stores"],
        "service": "cover-design",
        "resource": "how-to-write-a-book-cover-brief",
    },
    "static": {
        "subtitle": "A science fiction thriller concept with one word to sell",
        "brief": (
            "Create a cover for a near-future thriller about a signal that should "
            "not be answered. One-word title, high energy, no spaceships."
        ),
        "approach": [
            "A single oversized word in a tall condensed face, with a slight colour split on its edges, suggests interference without a literal illustration.",
            "A receding grid in cyan on near-black sets the near-future tone and gives the cover depth at thumbnail size.",
            "The tagline is set wide and small so it reads as a whisper under the shout of the title.",
            "Everything is vector, so the cover scales from a store thumbnail to a conference banner without loss.",
        ],
        "shows": "A typographic cover: when the title is strong enough, the design job is to get out of its way.",
        "deliverables": ["Front cover concept", "Animated title treatment for social media", "Ebook cover sized for stores"],
        "service": "marketing",
        "resource": "self-publishing-checklist-first-time-authors",
    },
    "tiger-in-the-teacup": {
        "subtitle": "A picture book concept with a character you can hold",
        "brief": (
            "Design a bright, funny cover for a picture book about a very small "
            "tiger who lives in a teacup. The character must look cuddly, not fierce."
        ),
        "approach": [
            "The tiger peeks over the rim of the cup, which creates an instant story: how did it get in, and what happens next?",
            "Thick outlines and flat colour are chosen for print reliability and for the way they look on a shelf among busier covers.",
            "The hand-lettered title has the bounce of a read-aloud, which is how most picture books are sold.",
            "A polka dot background adds play without competing with the character.",
        ],
        "shows": "Building a character simple enough to repeat across every spread of the book and on merchandise.",
        "deliverables": ["Front cover concept", "Character turnaround sheet", "Endpaper pattern from the background"],
        "service": "cover-design",
        "resource": "print-and-ebook-formatting-checklist",
    },
    "salt-and-smoke": {
        "subtitle": "A cookbook concept with the food as the hero",
        "brief": (
            "Design a cover for a cookbook about cooking over fire. It should "
            "feel premium and photographic, with a title that can stand on its "
            "own in a bookshop display."
        ),
        "approach": [
            "A single dish on a plate, lit from the side, fills the lower half; the top half is reserved for a big display serif title.",
            "Near-black background and a warm plate make the food glow, which is the whole promise of the book.",
            "The subtitle is set in an italic to soften the heavy title and hint at seasons rather than technique.",
            "The layout leaves the spine and back cover with the same black ground so the whole wraparound reads as one object.",
        ],
        "shows": "Cookbook covers live or die on one image; the design job is to make space for it and let the type frame it.",
        "deliverables": ["Front cover concept", "Interior recipe page template", "Wraparound layout with spine"],
        "service": "formatting",
        "resource": "print-and-ebook-formatting-checklist",
    },
    "the-long-game": {
        "subtitle": "A business book concept that draws its argument",
        "brief": (
            "Design a cover for a business book about building something that "
            "lasts. Clean, confident and distinct from the shouting style of "
            "most business covers."
        ),
        "approach": [
            "A dotted path winds from a small black point to a large orange one: the long game, drawn in one line.",
            "Cream paper tone and a heavy geometric sans serif make the cover feel like a well-made object rather than an advertisement.",
            "The path is placed so it never crosses the title, which keeps the cover readable at every size.",
            "The orange is the only colour, used once, so it carries all the emphasis.",
        ],
        "shows": "One idea, one colour, one line. Restraint is what makes a business cover look authoritative.",
        "deliverables": ["Front cover concept", "Diagram style for the interior", "Ebook cover sized for stores"],
        "service": "publishing",
        "resource": "isbn-metadata-and-publishing-files",
    },
    "speak-easy": {
        "subtitle": "An English learning course concept that looks friendly",
        "brief": (
            "Design a cover for a conversational English course for adult "
            "learners. It should look approachable and modern, not like a school "
            "textbook, and it needs space for a plan or level badge."
        ),
        "approach": [
            "Two speech bubbles in the brand blue and yellow show a conversation at a glance and stay readable on a small screen.",
            "The two-word title is huge and plain, because learners are often browsing in a second language and need to read it instantly.",
            "A rotated badge carries the plan length and can be swapped per edition or level.",
            "White background keeps printing costs low and makes the cover work as a workbook that is handled daily.",
        ],
        "shows": "Designing for a reader who may not be a confident reader yet: clarity first, decoration second.",
        "deliverables": ["Front cover concept", "Level badge system", "Workbook interior template"],
        "service": "formatting",
        "resource": "print-and-ebook-formatting-checklist",
    },
}

STUDIO_PROJECTS = []
for _c in STUDIO_COVERS:
    _title, _genre = _CONCEPT_META.get(_c["file"], (_c["alt"], _c.get("genre", "fiction")))
    _slug = _slugify(_title)
    _detail = CONCEPT_DETAILS.get(_slug)
    STUDIO_PROJECTS.append({
        "slug": _slug,
        "kind": "concept",
        "kind_label": "Studio concept",
        "title": _title,
        "genre": _genre,
        "genre_label": GENRE_LABELS.get(_genre, _genre.title()),
        "image": "core/img/showcase/" + _c["file"],
        "thumb": "core/img/showcase/thumbs/" + _c["file"],
        "alt": _c["alt"],
        "has_page": _detail is not None,
        **(_detail or {}),
    })

# Client covers: shown with permission. No author credits or contribution
# claims until the owner confirms them (see CLIENT_COVER_QUESTIONS).
CLIENT_COVERS = [
    {"image": "core/img/covers/fronts/13.jpg", "label": "The Hollow Man", "alt": "Client cover: The Hollow Man"},
    {"image": "core/img/covers/fronts/14.jpg", "label": "Native Wisdom", "alt": "Client cover: Native Wisdom"},
    {"image": "core/img/covers/fronts/10.jpg", "label": "The First Drift", "alt": "Client cover: The First Drift"},
    {"image": "core/img/covers/fronts/1.jpg", "label": "Memoir", "alt": "Client cover: memoir with silhouette artwork"},
    {"image": "core/img/covers/fronts/11.jpg", "label": "Epic fantasy", "alt": "Client cover: epic fantasy"},
    {"image": "core/img/covers/fronts/2.jpg", "label": "Contemporary fiction", "alt": "Client cover: contemporary fiction"},
    {"image": "core/img/covers/fronts/3.jpg", "label": "Illustrated children's story", "alt": "Client cover: illustrated children's story"},
    {"image": "core/img/covers/fronts/4.jpg", "label": "Children's story", "alt": "Client cover: children's story with fish"},
    {"image": "core/img/covers/fronts/6.jpg", "label": "Historical novel", "alt": "Client cover: historical novel"},
    {"image": "core/img/covers/fronts/7.jpg", "label": "Illustrated story collection", "alt": "Client cover: illustrated story collection"},
    {"image": "core/img/covers/fronts/9.jpg", "label": "Military memoir", "alt": "Client cover: military memoir"},
    {"image": "core/img/covers/fronts/12.jpg", "label": "Inspirational photo book", "alt": "Client cover: inspirational photo book"},
    {"image": "core/img/covers/fronts/15.jpg", "label": "Faith and technology nonfiction", "alt": "Client cover: faith and technology nonfiction"},
]
for _cc in CLIENT_COVERS:
    _cc.update({"kind": "client", "kind_label": "Client cover", "genre": "client", "genre_label": "Client work", "has_page": False})

# What the owner must confirm before any client cover gets a detail page.
CLIENT_COVER_QUESTIONS = [
    "Exact book title and the author's name as it should be credited",
    "Written permission from the author to show the cover and name them",
    "What Books A Nation actually did: cover design, interior formatting, editing, publishing setup, or a combination",
    "Whether Books A Nation handled publishing (publishing credit is only given when that is true)",
    "One or two sentences on the brief, in the owner's words",
    "Optional: approved sample spreads or a store link",
]

PROJECTS_BY_SLUG = {p["slug"]: p for p in STUDIO_PROJECTS if p["has_page"]}
