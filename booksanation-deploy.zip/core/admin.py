from django.contrib import admin

from .models import ChatMessage, ChatSession, Inquiry


@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = ("name", "email", "service", "created_at", "handled")
    list_filter = ("service", "handled", "created_at")
    search_fields = ("name", "email", "message")
    list_editable = ("handled",)


class ChatMessageInline(admin.TabularInline):
    model = ChatMessage
    extra = 1
    fields = ("sender", "body", "created_at", "read_by_staff")
    readonly_fields = ("created_at",)


@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ("__str__", "visitor_email", "created_at", "closed")
    list_filter = ("closed", "created_at")
    search_fields = ("visitor_name", "visitor_email", "session_key")
    inlines = [ChatMessageInline]


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ("session", "sender", "body", "created_at", "read_by_staff")
    list_filter = ("sender", "read_by_staff")
