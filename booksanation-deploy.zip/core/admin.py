from django.contrib import admin

from .models import ChatMessage, ChatSession, Inquiry, Testimonial


@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = ("name", "email", "service", "created_at", "handled")
    list_filter = ("service", "handled", "created_at")
    search_fields = ("name", "email", "message")
    list_editable = ("handled",)


class ChatMessageInline(admin.TabularInline):
    model = ChatMessage
    extra = 1
    fields = ("sender", "body", "created_at", "read_by_staff")
    readonly_fields = ("created_at",)


@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ("__str__", "visitor_email", "created_at", "closed")
    list_filter = ("closed", "created_at")
    search_fields = ("visitor_name", "visitor_email", "session_key")
    inlines = [ChatMessageInline]


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ("session", "sender", "body", "created_at", "read_by_staff")
    list_filter = ("sender", "read_by_staff")


@admin.action(description="Approve and show on the site")
def approve_testimonials(modeladmin, request, queryset):
    queryset.filter(consent=True).update(approved=True)


@admin.action(description="Hide from the site")
def hide_testimonials(modeladmin, request, queryset):
    queryset.update(approved=False)


@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):
    list_display = ("name", "book_title", "location", "consent", "approved", "created_at")
    list_filter = ("approved", "consent", "created_at")
    search_fields = ("name", "email", "book_title", "quote")
    list_editable = ("approved",)
    readonly_fields = ("created_at", "submitted_ip")
    actions = [approve_testimonials, hide_testimonials]
    fields = ("name", "email", "book_title", "location", "quote", "photo", "consent", "approved", "submitted_ip", "created_at")
