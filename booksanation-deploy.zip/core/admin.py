from django.contrib import admin

from django.shortcuts import redirect

from .models import ChatMessage, ChatSession, Inquiry, SiteIntegrations, SiteSettings, Testimonial


@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = ("name", "email", "service", "source", "created_at", "email_sent", "handled")
    list_filter = ("handled", "email_sent", "service", "created_at")
    search_fields = ("name", "email", "message", "source", "gclid")
    list_editable = ("handled",)
    readonly_fields = ("page", "gclid", "source", "attribution", "submitted_ip", "email_sent", "email_error", "created_at")
    actions = ["resend_email"]

    @admin.action(description="Send the notification email again")
    def resend_email(self, request, queryset):
        from .views import send_inquiry_email

        sent = sum(1 for i in queryset if send_inquiry_email(i))
        self.message_user(request, f"{sent} of {queryset.count()} emails sent. Failures show in the Email error column.")


class ChatMessageInline(admin.TabularInline):
    model = ChatMessage
    extra = 1
    fields = ("sender", "body", "created_at", "read_by_staff")
    readonly_fields = ("created_at",)


@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = ("__str__", "visitor_email", "created_at", "closed")
    list_filter = ("closed", "created_at")
    search_fields = ("visitor_name", "visitor_email", "session_key")
    inlines = [ChatMessageInline]


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ("session", "sender", "body", "created_at", "read_by_staff")
    list_filter = ("sender", "read_by_staff")


@admin.action(description="Approve and show on the site")
def approve_testimonials(modeladmin, request, queryset):
    queryset.filter(consent=True).update(approved=True)


@admin.action(description="Hide from the site")
def hide_testimonials(modeladmin, request, queryset):
    queryset.update(approved=False)


@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):
    list_display = ("name", "book_title", "location", "consent", "approved", "created_at")
    list_filter = ("approved", "consent", "created_at")
    search_fields = ("name", "email", "book_title", "quote")
    list_editable = ("approved",)
    readonly_fields = ("created_at", "submitted_ip")
    actions = [approve_testimonials, hide_testimonials]
    fields = ("name", "email", "book_title", "location", "quote", "photo", "consent", "approved", "submitted_ip", "created_at")


@admin.register(SiteIntegrations)
class SiteIntegrationsAdmin(admin.ModelAdmin):
    fieldsets = (
        ("Google (analytics and ads)", {
            "fields": ("gtm_id", "ga4_id", "google_ads_id", "google_ads_lead_label", "google_ads_call_label"),
            "description": "Leave a field empty to switch that tag off. Lead and phone click events are also sent to Tag Manager as generate_lead and phone_click.",
        }),
        ("Microsoft Ads", {"fields": ("microsoft_uet_id",)}),
        ("CallRail call tracking", {
            "fields": ("callrail_swap_url",),
            "description": "CallRail replaces the toll free number on every page with its tracking number for ad visitors.",
        }),
        ("Tawk.to live chat", {
            "fields": ("tawk_property_id", "tawk_widget_id"),
            "description": "When both are filled, the Live Agent button opens Tawk.to instead of the built in chat.",
        }),
    )

    def has_add_permission(self, request):
        return not SiteIntegrations.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False

    def changelist_view(self, request, extra_context=None):
        obj, _ = SiteIntegrations.objects.get_or_create(pk=1)
        return redirect("admin:core_siteintegrations_change", obj.pk)


@admin.register(SiteSettings)
class SiteSettingsAdmin(admin.ModelAdmin):
    fields = ("promo_enabled", "promo_text", "promo_terms", "seasonal_enabled")

    def has_add_permission(self, request):
        return not SiteSettings.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False

    def changelist_view(self, request, extra_context=None):
        obj, _ = SiteSettings.objects.get_or_create(pk=1)
        return redirect("admin:core_sitesettings_change", obj.pk)
