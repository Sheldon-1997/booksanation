from django.contrib.sitemaps import Sitemap
from django.urls import reverse

from .data import PLATFORMS, SERVICES
from .portfolio import STUDIO_PROJECTS
from .resources import RESOURCES


class StaticSitemap(Sitemap):
    protocol = "https"
    changefreq = "monthly"

    def items(self):
        pages = [
            ("home", {}, 1.0),
            ("services", {}, 0.9),
            ("platforms", {}, 0.9),
            ("studio", {}, 0.8),
            ("about", {}, 0.7),
            ("contact", {}, 0.8),
            ("faq", {}, 0.7),
            ("testimonials", {}, 0.7),
            ("portfolio", {}, 0.8),
            ("resources", {}, 0.8),
            ("publishing_standards", {}, 0.5),
            ("cookie_policy", {}, 0.3),
            ("refund_policy", {}, 0.3),
            ("privacy", {}, 0.3),
            ("terms", {}, 0.3),
        ]
        pages += [("service_detail", {"slug": s}, 0.8) for s in SERVICES]  # public services only, drafts excluded
        pages += [("platform_detail", {"slug": p}, 0.8) for p in PLATFORMS]
        pages += [("portfolio_detail", {"slug": p["slug"]}, 0.6) for p in STUDIO_PROJECTS if p["has_page"]]
        pages += [("resource_detail", {"slug": r["slug"]}, 0.7) for r in RESOURCES]
        return pages

    def location(self, item):
        name, kwargs, _ = item
        return reverse(name, kwargs=kwargs)

    def priority(self, item):
        return item[2]


SITEMAPS = {"static": StaticSitemap}
