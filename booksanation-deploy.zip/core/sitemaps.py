from django.contrib.sitemaps import Sitemap
from django.urls import reverse

from .data import PLATFORMS, SERVICES


class StaticSitemap(Sitemap):
    protocol = "https"
    changefreq = "monthly"

    def items(self):
        pages = [
            ("home", {}, 1.0),
            ("services", {}, 0.9),
            ("platforms", {}, 0.9),
            ("studio", {}, 0.8),
            ("about", {}, 0.7),
            ("contact", {}, 0.8),
            ("faq", {}, 0.7),
            ("testimonials", {}, 0.7),
            ("privacy", {}, 0.3),
            ("terms", {}, 0.3),
        ]
        pages += [("service_detail", {"slug": s}, 0.8) for s in SERVICES]
        pages += [("platform_detail", {"slug": p}, 0.8) for p in PLATFORMS]
        return pages

    def location(self, item):
        name, kwargs, _ = item
        return reverse(name, kwargs=kwargs)

    def priority(self, item):
        return item[2]


SITEMAPS = {"static": StaticSitemap}
