from datetime import timedelta

from django.db import migrations
from django.utils import timezone


def resend(apps, schema_editor):
    """Until v28 production mail went to the console backend (log only), so nothing reached the
    inbox. Mark the last 30 days of inquiries and the last 7 days of chat messages as not yet
    emailed; notify_leads then delivers them to the Titan inbox."""
    Inquiry = apps.get_model("core", "Inquiry")
    ChatMessage = apps.get_model("core", "ChatMessage")
    now = timezone.now()
    Inquiry.objects.filter(created_at__gte=now - timedelta(days=30)).update(email_sent=False, email_error="")
    ChatMessage.objects.filter(sender="visitor", created_at__gte=now - timedelta(days=7)).update(emailed=False)


class Migration(migrations.Migration):
    dependencies = [("core", "0007_chatmessage_emailed")]
    operations = [migrations.RunPython(resend, migrations.RunPython.noop)]
