"""One-time server performance tune, run by the auto-updater (as root) during migrate.

Only acts on the production server: requires root and the booksanation nginx site.
Everywhere else (development, tests) it does nothing. See deploy/server_tune.sh.
"""
import os
import subprocess
from pathlib import Path

from django.conf import settings
from django.db import migrations


def tune(apps, schema_editor):
    script = Path(settings.BASE_DIR) / "deploy" / "server_tune.sh"
    if not (hasattr(os, "geteuid") and os.geteuid() == 0):
        return
    if not Path("/etc/nginx/sites-available/booksanation").exists() or not script.exists():
        return
    try:
        subprocess.run(["bash", str(script)], timeout=60, check=False)
    except Exception:
        pass


class Migration(migrations.Migration):
    dependencies = [("core", "0003_alter_inquiry_service")]
    operations = [migrations.RunPython(tune, migrations.RunPython.noop)]
