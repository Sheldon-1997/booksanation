from datetime import timedelta

from django.db import migrations, models
from django.utils import timezone


def mark_old_messages(apps, schema_editor):
    """Messages older than a week count as handled; newer ones get emailed once."""
    ChatMessage = apps.get_model("core", "ChatMessage")
    ChatMessage.objects.filter(created_at__lt=timezone.now() - timedelta(days=7)).update(emailed=True)
    ChatMessage.objects.filter(sender="staff").update(emailed=True)


class Migration(migrations.Migration):
    dependencies = [("core", "0006_sitesettings_email_status")]

    operations = [
        migrations.AddField(
            model_name="chatmessage",
            name="emailed",
            field=models.BooleanField(default=False, help_text="Included in a notification email to the support inbox"),
        ),
        migrations.RunPython(mark_old_messages, migrations.RunPython.noop),
    ]
