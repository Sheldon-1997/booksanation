from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0008_resend_console_mail")]

    operations = [
        migrations.AddField(
            model_name="sitesettings",
            name="seasonal_enabled",
            field=models.BooleanField(
                default=True, verbose_name="Automatic holiday themes",
                help_text="Black Friday, Christmas, Easter, Fourth of July and every other US holiday: colors, decorations "
                          "and the up to 50% offer switch on and off by themselves. Untick to keep the normal look all year.",
            ),
        ),
    ]
