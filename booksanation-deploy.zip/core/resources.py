"""Author Resources: original guides written for booksanation.com.

Each guide is a dict with sections rendered by templates/core/resource_detail.html.
Dates are real publication dates. Author attribution is the Books A Nation
editorial team; we do not invent named experts or research citations.

Copy rule: plain sentences, no em dashes, en dashes, hashtags or decorative
check marks.
"""

import datetime as _dt

AUTHOR = "Books A Nation editorial team"

RESOURCES = [
    {
        "slug": "self-publishing-checklist-first-time-authors",
        "title": "The first-time author's self-publishing checklist",
        "category": "Getting started",
        "summary": (
            "A step by step checklist for publishing your first book: manuscript, "
            "editing, cover, formatting, ISBN, metadata, platforms and launch, in the right order."
        ),
        "published": _dt.date(2026, 11, 3),
        "updated": _dt.date(2026, 11, 3),
        "read_time": 9,
        "intro": (
            "Self-publishing is not hard, but it has a lot of steps, and doing "
            "them in the wrong order costs time and money. This checklist is the "
            "order we use with authors in our studio. Work through it top to "
            "bottom and you will not have to redo anything."
        ),
        "sections": [
            {
                "h": "Stage 1: Finish the manuscript properly",
                "p": [
                    "A finished draft means the whole book exists from first page to last, including any front matter you plan to write yourself, such as a dedication or an author's note. Editors can only work on what is on the page.",
                    "Before sending it anywhere, do one read-through yourself, ideally after a break of two weeks. Fix what you notice, but do not polish sentences yet. Structural problems found later are far more expensive than typos.",
                ],
                "list": [
                    "Save a dated backup of the complete draft in two places",
                    "Decide on US or UK spelling and keep it consistent",
                    "Write a one-paragraph summary of the book: it will become your description later",
                    "List any names, places or invented terms with their spellings",
                ],
            },
            {
                "h": "Stage 2: Editing, in the right order",
                "p": [
                    "Editing is several jobs, not one. Developmental editing looks at structure and pacing. Line editing works on the sentences. Copy editing checks correctness and consistency. Proofreading happens last, on the typeset pages. Our guide to the four levels of editing explains how to tell which your book needs.",
                    "The common mistake is to pay for proofreading first. If a chapter is cut later, that proofreading was wasted. Start wide, finish narrow.",
                ],
                "list": [
                    "Get a sample edit before committing to a full edit",
                    "Keep a style sheet of every spelling and formatting decision",
                    "Accept or reject tracked changes yourself so you stay in control of the voice",
                ],
            },
            {
                "h": "Stage 3: The cover and the description",
                "p": [
                    "Readers decide in seconds, and they decide from a thumbnail. A cover has to signal the genre clearly at small sizes, and the description has to confirm what the cover promised. Write the description before the cover brief; it forces you to be clear about who the book is for.",
                    "See our guide to preparing a cover brief for the exact information a designer needs. A good brief saves at least one revision round.",
                ],
                "list": [
                    "Collect five comparable books in your category and note what their covers have in common",
                    "Decide your trim size now, because the print cover depends on it",
                    "Write the back cover copy and author bio while the designer works",
                ],
            },
            {
                "h": "Stage 4: ISBN, imprint and metadata",
                "p": [
                    "An ISBN identifies one edition of your book. Paperback, hardcover and ebook each need their own. Some platforms will assign a free ISBN that can only be used on that platform; buying your own gives you one identity across every store. Our guide to publishing files, ISBNs and metadata covers the trade-offs.",
                    "Metadata is everything the stores know about your book: title, subtitle, contributors, description, categories, keywords, price and age range. It is worth an afternoon of care, because it is what search engines and store algorithms read.",
                ],
            },
            {
                "h": "Stage 5: Formatting for print and ebook",
                "p": [
                    "Print and ebook are different products. Print needs fixed pages, margins that account for the binding, and a PDF to your printer's specification. Ebooks reflow to the reader's device and need a validated EPUB. Our formatting checklist lists every item to check before you upload.",
                ],
                "list": [
                    "Proofread the typeset PDF, not the Word file",
                    "Check the EPUB on at least one phone and one e-reader",
                    "Confirm the spine width with your designer once the page count is final",
                ],
            },
            {
                "h": "Stage 6: Choose platforms and set up accounts",
                "p": [
                    "No single store reaches every reader. A common setup is Amazon KDP for Amazon's print and ebook customers, IngramSpark for bookstores and libraries, and an aggregator such as Draft2Digital for the other ebook stores. Read our platform guides before choosing; each one explains who the platform reaches and what it needs from you.",
                    "Create accounts in your own name, with your own payment and tax details. If someone sets up a platform for you, the account should still be yours.",
                ],
            },
            {
                "h": "Stage 7: Proof, publish and launch",
                "p": [
                    "Order a printed proof before you approve a print edition. Screens hide problems that paper shows. When the proof is right, set your release date, make sure every store listing matches, and run a simple launch: tell the people who already know you, ask early readers for honest reviews, and give the book a few weeks before judging anything.",
                ],
                "list": [
                    "Printed proof checked cover to cover",
                    "Price and territories set on every platform",
                    "Author page claimed on the stores that offer one",
                    "A short list of people to tell on release day",
                ],
            },
        ],
        "faqs": [
            {"q": "How long does self-publishing take from finished draft to release?", "a": "With professional editing, design and formatting, three to five months is realistic for a novel. Rushing the edit or the cover is the most common reason books need a second edition."},
            {"q": "Do I need a company or imprint name to self-publish?", "a": "No. You can publish under your own name. An imprint name is optional and mostly cosmetic unless you plan to publish other authors."},
            {"q": "What is the single most common mistake?", "a": "Formatting and proofreading a manuscript that still needs a structural edit. Do the big work first."},
        ],
        "related_services": ["editing", "cover-design", "publishing"],
        "related_platforms": ["kdp", "ingramspark", "draft2digital"],
        "related_resources": ["editing-levels-explained", "how-to-write-a-book-cover-brief", "isbn-metadata-and-publishing-files"],
    },

    {
        "slug": "editing-levels-explained",
        "title": "Developmental, line, copy editing and proofreading: what each one does",
        "category": "Editing",
        "summary": (
            "The four levels of book editing explained with examples, the order they "
            "happen in, what you receive from each, and how to tell which one your manuscript needs."
        ),
        "published": _dt.date(2026, 11, 3),
        "updated": _dt.date(2026, 11, 3),
        "read_time": 8,
        "intro": (
            "Authors are often quoted for an edit without knowing which edit they "
            "are buying. The four levels do different jobs and happen at different "
            "times. Here is each one with a worked example, so you can ask for the right thing."
        ),
        "sections": [
            {
                "h": "Developmental editing: the shape of the book",
                "p": [
                    "A developmental editor reads the whole manuscript and asks big questions. Does the story start in the right place? Does the argument build? Is the middle sagging? Are there characters or chapters doing no work? You receive an editorial letter, usually several pages, plus notes in the margins. The editor does not rewrite your sentences at this stage.",
                    "Example: a memoir opens with forty pages of childhood before the event the book is really about. The developmental edit suggests opening with the event and folding the childhood in as needed. No sentence has been touched, but the book is now a different reading experience.",
                ],
            },
            {
                "h": "Line editing: the sentences",
                "p": [
                    "Line editing works paragraph by paragraph on rhythm, clarity, word choice, repetition and tone. The goal is to make the prose do what you intend, in your voice. Everything is delivered as tracked changes so you can see and reverse any suggestion.",
                    "Example, before: \"She was feeling very tired and exhausted after the long day, which had been extremely long.\" After: \"By the end of the day she was spent.\" The meaning is the same; the sentence now earns its place.",
                ],
            },
            {
                "h": "Copy editing: correctness and consistency",
                "p": [
                    "Copy editing checks grammar, punctuation, spelling, usage and consistency. Is the character's eye colour the same in chapter two and chapter twenty? Is it \"e-mail\" or \"email\" throughout? Are dates and sequences possible? The copy editor also builds a style sheet that records every decision, which the proofreader and formatter use later.",
                    "Example: a nonfiction manuscript refers to a report as 2019 in one chapter and 2020 in another. The copy editor flags it as a query rather than guessing, because only the author knows which is right.",
                ],
            },
            {
                "h": "Proofreading: the final pages",
                "p": [
                    "Proofreading happens after the book is typeset, on the PDF or EPUB that will be published. It catches typos that survived, words dropped during layout, bad line and page breaks, and small layout faults such as a chapter heading at the bottom of a page. It is not the place to rewrite anything.",
                    "Example: a chapter title appears as \"Chaper Nine\" in the formatted file. It was correct in the manuscript; the error crept in during layout. Only a proof of the final pages catches this.",
                ],
            },
            {
                "h": "The order matters",
                "p": [
                    "Developmental first, then line, then copy, then proof. Each level assumes the previous one is finished. If you proofread before a structural edit and then cut a chapter, that proofreading is gone. If you copy edit before line editing, every rewritten sentence needs checking again.",
                    "Not every book needs every level. A clean nonfiction manuscript from an experienced writer may need only a copy edit and a proof. A first novel usually benefits from a developmental read. An honest editor will tell you which, and a sample edit will show you.",
                ],
                "list": [
                    "Ask what level a quote covers and what you will receive",
                    "Ask for a sample edit of a few pages",
                    "Ask whether a style sheet is included with copy editing",
                    "Keep the proofread for the typeset pages, not the manuscript",
                ],
            },
        ],
        "faqs": [
            {"q": "Can one editor do all four levels?", "a": "Sometimes, but not in one pass, and fresh eyes at the proofreading stage catch more. In our studio different passes are often done by different people."},
            {"q": "Is a manuscript assessment the same as a developmental edit?", "a": "An assessment is shorter: a report on strengths and weaknesses without margin notes. It is a good low-cost first step if you are unsure whether the book is ready."},
            {"q": "What does a style sheet contain?", "a": "Spelling choices, hyphenation, capitalisation, number style, character and place names, timeline notes and anything else that must stay consistent across the book."},
        ],
        "related_services": ["editing", "formatting"],
        "related_platforms": [],
        "related_resources": ["self-publishing-checklist-first-time-authors", "print-and-ebook-formatting-checklist"],
    },

    {
        "slug": "how-to-write-a-book-cover-brief",
        "title": "How to prepare a book cover brief your designer can actually use",
        "category": "Cover design",
        "summary": (
            "What to put in a cover design brief: genre, comparable titles, trim size, text, "
            "mood, must-haves and must-nots, with a template you can copy."
        ),
        "published": _dt.date(2026, 11, 3),
        "updated": _dt.date(2026, 11, 3),
        "read_time": 7,
        "intro": (
            "The best cover briefs are not long. They are specific. A designer "
            "needs to know what the book is, who it is for, what it must say on "
            "the cover and what the finished file has to be. Give them that and "
            "the first concept is usually close."
        ),
        "sections": [
            {
                "h": "Start with the reader, not the plot",
                "p": [
                    "Tell the designer who picks this book up and what they expect a book like it to look like. \"Readers of domestic thrillers, mostly women 30 to 55, who buy on their phone\" is more useful than three paragraphs of plot. The plot matters, but the category is what the cover has to signal first.",
                ],
            },
            {
                "h": "Give five comparable covers and say why",
                "p": [
                    "Find five recent covers in your category that you think work, and for each one write a line about what you like: the typography, the colour, the mood, the use of a figure. Then add one or two you dislike, with reasons. This tells the designer where the boundaries are without dictating the design.",
                ],
            },
            {
                "h": "Supply every word that goes on the cover",
                "list": [
                    "Title and subtitle, exactly as they should appear",
                    "Author name, and any series name and number",
                    "A tagline for the front, if you want one",
                    "Back cover description, usually 100 to 180 words",
                    "A short author bio and whether you want an author photo",
                    "Any endorsement you have permission to quote, with the exact attribution",
                    "ISBN and barcode requirements for the print edition",
                ],
                "p": [
                    "Final text, not placeholder text. Line lengths change the layout, so a title that gains a word later means rework.",
                ],
            },
            {
                "h": "Specify the physical book",
                "p": [
                    "A print cover is built around the trim size and the spine width, and the spine width depends on the page count and paper. Tell the designer your trim size, your estimated page count, which printer you will use and whether the book is paperback or hardcover. If you are not sure, say so and ask; it is better to decide this with the designer than to guess.",
                ],
                "list": [
                    "Trim size, for example 5.5 x 8.5 inches",
                    "Estimated final page count after formatting",
                    "Printer or platform, for example Amazon KDP or IngramSpark",
                    "Paper colour: white or cream",
                    "Ebook stores you will use, so the ebook cover is sized correctly",
                ],
            },
            {
                "h": "Mood, colour and must-nots",
                "p": [
                    "Describe the feeling in a few words: cold and precise, warm and nostalgic, loud and funny. Mention colours you love or hate and why. List anything that must not appear, such as a face, a specific symbol or a cliché of the genre you want to avoid. Short lists work better than paragraphs here.",
                ],
            },
            {
                "h": "A brief template you can copy",
                "list": [
                    "Book: title, subtitle, series, author name",
                    "Category and reader: one or two sentences",
                    "One-paragraph description of the book",
                    "Five comparable covers with a line on each",
                    "Mood in five words, colours to use or avoid",
                    "Must include, must not include",
                    "Trim size, page count, printer, paperback or hardcover",
                    "Ebook stores",
                    "All cover text, final",
                    "Deadline and anything else the designer should know",
                ],
            },
        ],
        "faqs": [
            {"q": "Should I send my own sketch or mockup?", "a": "Only if it shows something specific you want, and say clearly whether it is a requirement or just an idea. Designers can be held back by a sketch they think they must follow."},
            {"q": "How many revision rounds are normal?", "a": "Two rounds on the chosen concept is typical. A clear brief is the best way to stay within them."},
            {"q": "Who owns the cover when it is done?", "a": "You should. Check that the agreement transfers the artwork and source files to you and tells you what the licences on any stock images allow."},
        ],
        "related_services": ["cover-design", "formatting"],
        "related_platforms": ["kdp", "ingramspark"],
        "related_resources": ["print-and-ebook-formatting-checklist", "self-publishing-checklist-first-time-authors"],
    },

    {
        "slug": "print-and-ebook-formatting-checklist",
        "title": "Print and ebook formatting checklist",
        "category": "Formatting",
        "summary": (
            "Everything to check before uploading a book interior: trim size, margins, "
            "fonts, front and back matter, EPUB validation, images, page breaks and proofs."
        ),
        "published": _dt.date(2026, 11, 3),
        "updated": _dt.date(2026, 11, 3),
        "read_time": 8,
        "intro": (
            "Formatting problems are the most common reason a file is rejected or "
            "a printed proof disappoints. This checklist covers the print interior, "
            "the ebook and the final checks, in the order we do them."
        ),
        "sections": [
            {
                "h": "Before you start",
                "list": [
                    "The manuscript is fully edited; formatting a file that will change again is wasted work",
                    "Chapter breaks are marked consistently, with no manual page breaks or runs of blank lines",
                    "Headings use styles rather than bold text, so they can be found and formatted",
                    "Italics and other emphasis survived the editing stage",
                    "Images are supplied as separate files at print resolution, usually 300 dpi at the printed size",
                ],
            },
            {
                "h": "Print interior",
                "list": [
                    "Trim size matches the cover design and the printer's options",
                    "Inside margins are wider than outside margins to allow for the binding",
                    "Body text is a readable serif at 10.5 to 12 points with comfortable line spacing",
                    "Chapters start on a new page, and on the right-hand page if the design calls for it",
                    "Running heads and page numbers are present, and absent on blank and display pages",
                    "No widows or orphans, and no chapter heading stranded at the foot of a page",
                    "Front matter in order: half title, title page, copyright page, dedication, contents",
                    "Copyright page includes the ISBN, copyright line and edition information",
                    "Back matter in order: acknowledgements, about the author, also by, notes or index",
                    "PDF exported with fonts embedded, in the page size and colour mode the printer requires",
                ],
            },
            {
                "h": "Ebook",
                "list": [
                    "Built as a reflowable EPUB, not a converted print PDF",
                    "A clickable table of contents and the ebook's internal navigation both work",
                    "Headings, paragraphs and emphasis use proper styles so readers can change fonts",
                    "Images are sized for screens and have alt text",
                    "Scene breaks are visible, not just blank lines that can disappear at a page boundary",
                    "No page numbers or running heads, which do not exist in a reflowable file",
                    "Front matter is short so the reader reaches chapter one quickly in the sample",
                    "The file passes EPUB validation and the store's own checker",
                ],
            },
            {
                "h": "Final checks",
                "list": [
                    "Proofread the typeset PDF, not the manuscript",
                    "Open the EPUB on a phone, a tablet or e-reader, and in a desktop app",
                    "Check the spine width with the cover designer once the page count is final",
                    "Order a printed proof and read it cover to cover before approving",
                    "Keep the source files and note which version was uploaded where",
                ],
            },
        ],
        "faqs": [
            {"q": "Can I format my own book in Word?", "a": "For a simple novel, yes, with care. Word is weak at the finer points of typesetting, such as spacing and hyphenation, and most authors can see the difference in the finished pages."},
            {"q": "Why does my ebook look different on every device?", "a": "That is how reflowable ebooks work: the reader controls the font and size. Good formatting makes the structure survive those changes, not freeze the layout."},
            {"q": "Do I need a different print file for each platform?", "a": "Usually the same interior PDF works across platforms for the same trim size, but each printer has its own bleed and margin rules, so check their specification."},
        ],
        "related_services": ["formatting", "editing", "cover-design"],
        "related_platforms": ["kdp", "ingramspark", "lulu"],
        "related_resources": ["editing-levels-explained", "isbn-metadata-and-publishing-files"],
    },

    {
        "slug": "isbn-metadata-and-publishing-files",
        "title": "Publishing files, ISBNs and metadata: what to prepare before you upload",
        "category": "Publishing",
        "summary": (
            "The files and information every store asks for: ISBNs per edition, imprint, "
            "categories, keywords, description, pricing and the file formats each platform accepts."
        ),
        "published": _dt.date(2026, 11, 3),
        "updated": _dt.date(2026, 11, 3),
        "read_time": 9,
        "intro": (
            "Uploading a book is mostly form-filling, and the forms ask for things "
            "that are easier to prepare in advance. This guide lists what you need, "
            "explains the choices that are hard to reverse, and points you to our "
            "platform guides for the specifics of each store."
        ),
        "sections": [
            {
                "h": "ISBNs: one per edition",
                "p": [
                    "An ISBN is a 13-digit identifier for a specific edition and format of a book. A paperback, a hardcover and an ebook of the same title are three editions and need three ISBNs. A new cover with the same interior does not need a new one; a revised edition with substantial changes does.",
                    "You can buy ISBNs from the agency for your country, which registers you as the publisher of record, or accept a free ISBN from a platform that offers one. A free platform ISBN usually lists that platform as the publisher and may not be usable elsewhere. Owning your ISBNs costs more up front and gives you one identity across every store. Either choice is fine as long as you make it knowingly.",
                ],
            },
            {
                "h": "Imprint and publisher name",
                "p": [
                    "Stores ask for a publisher or imprint name. It can be your own name or a trading name you choose. It appears on the store page and in library and bookseller databases, so pick something you are happy to keep. It does not need to be a registered company for most platforms.",
                ],
            },
            {
                "h": "The metadata every store asks for",
                "list": [
                    "Title and subtitle, matching the cover exactly",
                    "Contributor names and roles: author, illustrator, translator, editor",
                    "Description: 150 to 300 words that confirm the genre and promise of the cover",
                    "Two or three categories, chosen from the store's own list",
                    "Keywords or search terms, written the way readers search",
                    "Language, page count and the date of publication",
                    "Age range and reading level for children's and YA titles",
                    "Series name and number, if the book is part of one",
                    "Price per format and the territories where it is for sale",
                ],
                "p": [
                    "Write the description once, carefully, and reuse it everywhere. Store pages that disagree with each other look careless and confuse search.",
                ],
            },
            {
                "h": "Files each platform accepts",
                "p": [
                    "Print platforms want a PDF interior with embedded fonts and a PDF cover built to their template, with bleed. Ebook stores want an EPUB; Amazon accepts EPUB and converts it. Audiobook stores have their own audio specifications. Our platform guides list what each one asks for: Amazon KDP, IngramSpark, Lulu, Kobo, Barnes and Noble Press, Draft2Digital, Apple Books and Google Play Books.",
                ],
                "list": [
                    "Interior PDF per trim size, fonts embedded",
                    "Cover PDF per printer, built from their spine width calculation",
                    "EPUB validated and checked in a reader",
                    "Ebook cover image at the size each store specifies",
                    "Author photo and bio for store author pages",
                ],
            },
            {
                "h": "Choices that are hard to reverse",
                "list": [
                    "Title and author name: changing them after publication usually means a new edition and new ISBN",
                    "Trim size: it fixes the cover and the interior, so decide it before design",
                    "Free platform ISBN versus your own: the publisher of record cannot be swapped later",
                    "Exclusive ebook programmes: read the terms on how long you are locked in",
                    "Pre-order dates: missing a pre-order deadline can carry penalties on some stores",
                ],
            },
            {
                "h": "Keep a publishing record",
                "p": [
                    "Make one document that lists every ISBN, every platform login (stored securely), the files uploaded and their version numbers, prices by territory, and the dates things went live. When you fix a typo in a year's time, this record is what tells you where to upload the new file.",
                ],
            },
        ],
        "faqs": [
            {"q": "Do I need a barcode as well as an ISBN?", "a": "Print books need the ISBN as a barcode on the back cover. Most print platforms add it for you from the ISBN you enter; otherwise your designer can generate it."},
            {"q": "Can I use the same ISBN on Amazon and IngramSpark?", "a": "Yes, if you own the ISBN. A free Amazon-assigned ISBN can only be used on Amazon."},
            {"q": "What if I entered the wrong category?", "a": "Categories and keywords can be changed at any time without a new edition. Title, author and ISBN generally cannot."},
        ],
        "related_services": ["publishing", "formatting", "marketing"],
        "related_platforms": ["kdp", "ingramspark", "draft2digital", "apple-books"],
        "related_resources": ["self-publishing-checklist-first-time-authors", "print-and-ebook-formatting-checklist"],
    },
]

RESOURCES_BY_SLUG = {r["slug"]: r for r in RESOURCES}
