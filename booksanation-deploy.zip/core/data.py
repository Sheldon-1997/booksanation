"""Single source of truth for services, platforms and portfolio covers.

Copy rule from the owner: no em dashes, no en dashes, no stylistic hyphens,
no hashtags and no decorative check marks anywhere in public website copy.
Write plain, natural sentences instead.
"""

SERVICES = {
    "editing": {
        "name": "Editing and Proofreading",
        "short": "Developmental, line and copy editing that keeps your voice intact.",
        "icon": "pen",
        "blurb": (
            "A manuscript deserves more than a spell check. Our editors work through "
            "structure, pacing, clarity and grammar in separate passes, and every "
            "suggested change stays visible so you approve the final word."
        ),
        "points": [
            "Developmental editing for structure, pacing and the flow of your story or argument",
            "Line editing for sentence rhythm, word choice and tone",
            "Copy editing and proofreading for grammar, consistency and typos",
            "A style sheet delivered with the finished manuscript",
        ],
    },
    "cover-design": {
        "name": "Cover Design and Illustration",
        "short": "Custom covers designed for your story and your shelf category.",
        "icon": "palette",
        "blurb": (
            "Readers do judge books by their covers. We design the front, spine and "
            "back as one piece, matched to your genre and built to print "
            "specification, and you own the final artwork outright."
        ),
        "points": [
            "Custom front, spine and full wraparound design",
            "Genre research so the cover sells in its category",
            "Files ready for print in every trim size you publish in",
            "Ebook cover versions sized for each store",
        ],
    },
    "formatting": {
        "name": "Interior Formatting and Typesetting",
        "short": "Clean, readable interiors for print and every major ebook format.",
        "icon": "layout",
        "blurb": (
            "Typesetting is the quiet craft that makes a book feel professional. We "
            "set your interior with proper margins, running heads and typography, "
            "then produce validated files for print and reflowable ebooks."
        ),
        "points": [
            "Print interiors for all common trim sizes",
            "EPUB files that pass store validation",
            "Chapter styling with front and back matter included",
            "A revision round after you review the proof",
        ],
    },
    "publishing": {
        "name": "Publishing and Distribution",
        "short": "Your book, published under your name, on the stores that matter.",
        "icon": "globe",
        "blurb": (
            "We set your book up across the retailers and distributors you choose, "
            "under your own accounts wherever possible, so your book, its rights "
            "and its earnings stay yours. Royalties are paid to you, always."
        ),
        "points": [
            "Account setup and metadata on each platform you choose",
            "ISBN guidance and category and keyword research",
            "Print on demand and ebook distribution setup",
            "You keep your rights and royalties go to you",
        ],
    },
    "marketing": {
        "name": "Book Marketing",
        "short": "Launch planning and promotion that fits your book and budget.",
        "icon": "megaphone",
        "blurb": (
            "A good launch is planned before release day. We help you prepare your "
            "book's description, audience targeting and promotional calendar, and "
            "set up the assets a campaign actually needs."
        ),
        "points": [
            "A launch plan and a release day checklist",
            "Store page optimisation covering description, categories and keywords",
            "Promotional graphics matched to your cover",
            "Advertising setup guidance for the channels you choose",
        ],
    },
}

PLATFORMS = {
    "kdp": {
        "name": "Amazon KDP",
        "logo": 'core/img/platforms/amazon.svg',
        "mono": None,
        "color": None,
        "full_name": "Amazon Kindle Direct Publishing",
        "short": "The largest ebook and print on demand marketplace.",
        "blurb": (
            "Kindle Direct Publishing puts your book in front of Amazon's readers as "
            "an ebook, paperback or hardcover. We prepare your files to KDP's print "
            "specifications, set up your title's metadata and categories, and walk "
            "you through pricing and royalty options so you choose with clear eyes."
        ),
        "handles": [
            "Manuscript and cover files matched to KDP print specs",
            "Title setup, categories, keywords and pricing guidance",
            "Kindle ebook conversion and preview checks",
        ],
    },
    "ingramspark": {
        "logo": None,
        "mono": 'IS',
        "color": '#1b3a6b',
        "name": "IngramSpark",
        "full_name": "IngramSpark",
        "short": "Global print distribution to bookstores and libraries.",
        "blurb": (
            "IngramSpark feeds the catalogue that bookstores and libraries order "
            "from. If you want your book available beyond Amazon, in physical "
            "stores, schools and libraries, Ingram's distribution network is how "
            "it gets there. We handle the file specs and setup."
        ),
        "handles": [
            "Print files prepared to Ingram's stricter specifications",
            "Title setup, pricing and wholesale discount guidance",
            "A release coordinated alongside your other platforms",
        ],
    },
    "lulu": {
        "logo": None,
        "mono": 'L',
        "color": '#e8730c',
        "name": "Lulu",
        "full_name": "Lulu Press",
        "short": "Flexible print options and direct sales tools.",
        "blurb": (
            "Lulu offers print formats and binding options that other platforms "
            "don't, plus tools for selling direct from your own website. For books "
            "rich in photos, for workbooks and for premium editions it is often "
            "the right choice."
        ),
        "handles": [
            "Format and binding selection for your book type",
            "Print file preparation and proof review",
            "Direct sales setup if you sell from your own site",
        ],
    },
    "kobo": {
        "logo": None,
        "mono": 'K',
        "color": '#b3000c',
        "name": "Kobo",
        "full_name": "Kobo Writing Life",
        "short": "Strong ebook reach in Canada, Europe and Asia Pacific.",
        "blurb": (
            "Kobo's reader network is strongest outside the US, which makes it a "
            "smart addition for international reach. Kobo Writing Life also offers "
            "promotional opportunities that independent authors can apply for "
            "directly."
        ),
        "handles": [
            "EPUB prepared and validated for Kobo",
            "Metadata, pricing by territory and preorder setup",
            "Guidance on Kobo's promotion applications",
        ],
    },
    "barnes-noble-press": {
        "logo": None,
        "mono": 'B&N',
        "color": '#2f5d3a',
        "name": "B&N Press",
        "full_name": "Barnes & Noble Press",
        "short": "Ebook and print for Barnes & Noble's readers.",
        "blurb": (
            "Barnes & Noble Press publishes your ebook for Nook readers and offers "
            "print on demand sold through bn.com. For authors targeting US readers "
            "it complements Amazon rather than competing with your listing there."
        ),
        "handles": [
            "Ebook and print setup on B&N Press",
            "Metadata consistent with your other store listings",
            "Pricing guidance for the B&N storefront",
        ],
    },
    "draft2digital": {
        "logo": None,
        "mono": 'D2D',
        "color": '#5a2d82',
        "name": "Draft2Digital",
        "full_name": "Draft2Digital",
        "short": "One upload reaches many stores at once.",
        "blurb": (
            "Draft2Digital distributes one upload to many ebook stores and library "
            "services at once, with consolidated reporting. If you want to publish "
            "wide without managing six dashboards, this is the practical route."
        ),
        "handles": [
            "Store selection strategy, direct or aggregated",
            "Upload, metadata and universal book links",
            "Library and subscription service choices explained",
        ],
    },
    "apple-books": {
        "logo": 'core/img/platforms/apple.svg',
        "mono": None,
        "color": None,
        "name": "Apple Books",
        "full_name": "Apple Books",
        "short": "The default reading app on every iPhone and iPad.",
        "blurb": (
            "Apple Books ships on every Apple device, and its store rewards clean, "
            "validated EPUB files. We prepare your ebook to Apple's requirements "
            "and set up your title so it looks right on the shelf."
        ),
        "handles": [
            "EPUB validation to Apple's standards",
            "Title setup, pricing and territories",
            "Series and preorder configuration",
        ],
    },
    "google-play-books": {
        "logo": 'core/img/platforms/googleplay.svg',
        "mono": None,
        "color": None,
        "name": "Google Play Books",
        "full_name": "Google Play Books",
        "short": "Reach the global base of Android readers.",
        "blurb": (
            "Google Play Books reaches readers on the world's most widely used "
            "mobile platform, and titles there also surface in Google search "
            "results. We handle the publisher center setup and file preparation."
        ),
        "handles": [
            "Publisher Center setup and verification guidance",
            "Ebook file preparation and metadata",
            "Territory pricing and currency setup",
        ],
    },
}

# Showcase covers: original sample designs created in house, one per genre,
# with invented titles. Clearly labelled on the site as studio sample designs.
# Client covers from static/core/img/covers/ stay out of the public pages at
# the owner's request, and no real published book's cover is ever used.
STUDIO_COVERS = [
    {"file": "b1.jpg",  "alt": "Studio sample cover: Midnight Harbour, a thriller", "genre": "thriller"},
    {"file": "b2.jpg",  "alt": "Studio sample cover: The Ember Crown, an epic fantasy", "genre": "fantasy"},
    {"file": "b3.jpg",  "alt": "Studio sample cover: Where the Jacarandas Bloom, a love story", "genre": "fiction"},
    {"file": "b4.jpg",  "alt": "Studio sample cover: Momo the Brave Little Fox, a children's book", "genre": "children"},
    {"file": "b5.jpg",  "alt": "Studio sample cover: Letters I Never Sent, a memoir", "genre": "nonfiction"},
    {"file": "b6.jpg",  "alt": "Studio sample cover: Deep Focus, a nonfiction title", "genre": "nonfiction"},
    {"file": "b7.jpg",  "alt": "Studio sample cover: The Salt Garden, literary fiction", "genre": "fiction"},
    {"file": "b8.jpg",  "alt": "Studio sample cover: Orbital Drift, science fiction", "genre": "fiction"},
    {"file": "b9.jpg",  "alt": "Studio sample cover: The Baker of Rue Clement, cosy fiction", "genre": "fiction"},
    {"file": "b10.jpg", "alt": "Studio sample cover: Slow Mornings, a lifestyle guide", "genre": "nonfiction"},
    {"file": "b11.jpg", "alt": "Studio sample cover: The Lighthouse Letters, a love story", "genre": "fiction"},
    {"file": "b12.jpg", "alt": "Studio sample cover: Static, a science fiction thriller", "genre": "fiction"},
    {"file": "b13.jpg", "alt": "Studio sample cover: The Cartographer's Daughter, historical fiction", "genre": "fiction"},
    {"file": "b14.jpg", "alt": "Studio sample cover: Quiet Hours, a self help guide", "genre": "nonfiction"},
    {"file": "b15.jpg", "alt": "Studio sample cover: Tiger in the Teacup, a picture book", "genre": "children"},
    {"file": "b16.jpg", "alt": "Studio sample cover: Salt and Smoke, a cookbook", "genre": "nonfiction"},
    {"file": "b17.jpg", "alt": "Studio sample cover: The Ninth Door, horror", "genre": "fiction"},
    {"file": "b18.jpg", "alt": "Studio sample cover: Orchard Street, a memoir", "genre": "nonfiction"},
    {"file": "b19.jpg", "alt": "Studio sample cover: Ledger, personal finance", "genre": "nonfiction"},
    {"file": "b20.jpg", "alt": "Studio sample cover: Monsoon Season, literary fiction", "genre": "fiction"},
    {"file": "b21.jpg", "alt": "Studio sample cover: Glass Kingdom, young adult fantasy", "genre": "fantasy"},
    {"file": "b22.jpg", "alt": "Studio sample cover: The Long Game, business", "genre": "nonfiction"},
    {"file": "b23.jpg", "alt": "Studio sample cover: Small Hours, poetry", "genre": "poetry"},
    {"file": "b24.jpg", "alt": "Studio sample cover: Roads Less Mapped, travel writing", "genre": "nonfiction"},
    {"file": "b25.jpg", "alt": "Studio sample cover: The Harbourmaster's Wife, a mystery", "genre": "fiction"},
    {"file": "b26.jpg", "alt": "Studio sample cover: Speak Easy, an English learning course", "genre": "education"},
    {"file": "b27.jpg", "alt": "Studio sample cover: Stillness Practice, mindfulness", "genre": "nonfiction"},
    {"file": "b28.jpg", "alt": "Studio sample cover: Iron Bloom, dystopian fiction", "genre": "fiction"},
    {"file": "b29.jpg", "alt": "Studio sample cover: The Sunday Table, a family saga", "genre": "fiction"},
    {"file": "b30.jpg", "alt": "Studio sample cover: Numbers That Lie, popular nonfiction", "genre": "nonfiction"},
]

# Studio picker: the owner's real client covers first (shown with permission,
# at his request), then our sample designs. Paths are relative to static/.
STUDIO_PICKER = [
    {"src": "core/img/covers/fronts/13.jpg", "alt": "Client cover: The Hollow Man"},
    {"src": "core/img/covers/fronts/14.jpg", "alt": "Client cover: Native Wisdom"},
    {"src": "core/img/covers/fronts/1.jpg",  "alt": "Client cover: memoir with silhouette artwork"},
    {"src": "core/img/covers/fronts/10.jpg", "alt": "Client cover: The First Drift"},
    {"src": "core/img/covers/fronts/11.jpg", "alt": "Client cover: epic fantasy"},
    {"src": "core/img/covers/fronts/2.jpg",  "alt": "Client cover: contemporary fiction"},
    {"src": "core/img/covers/fronts/3.jpg",  "alt": "Client cover: illustrated children's story"},
    {"src": "core/img/covers/fronts/4.jpg",  "alt": "Client cover: children's story with fish"},
    {"src": "core/img/covers/fronts/6.jpg",  "alt": "Client cover: historical novel"},
    {"src": "core/img/covers/fronts/7.jpg",  "alt": "Client cover: illustrated story collection"},
    {"src": "core/img/covers/fronts/9.jpg",  "alt": "Client cover: military memoir"},
    {"src": "core/img/covers/fronts/12.jpg", "alt": "Client cover: inspirational photo book"},
    {"src": "core/img/covers/fronts/15.jpg", "alt": "Client cover: faith and technology nonfiction"},
    {"src": "core/img/showcase/b7.jpg",  "alt": "Studio sample: The Salt Garden"},
    {"src": "core/img/showcase/b1.jpg",  "alt": "Studio sample: Midnight Harbour"},
    {"src": "core/img/showcase/b2.jpg",  "alt": "Studio sample: The Ember Crown"},
    {"src": "core/img/showcase/b4.jpg",  "alt": "Studio sample: Momo the Brave Little Fox"},
    {"src": "core/img/showcase/b6.jpg",  "alt": "Studio sample: Deep Focus"},
    {"src": "core/img/showcase/b9.jpg",  "alt": "Studio sample: The Baker of Rue Clement"},
    {"src": "core/img/showcase/b11.jpg", "alt": "Studio sample: The Lighthouse Letters"},
    {"src": "core/img/showcase/b13.jpg", "alt": "Studio sample: The Cartographer's Daughter"},
    {"src": "core/img/showcase/b15.jpg", "alt": "Studio sample: Tiger in the Teacup"},
    {"src": "core/img/showcase/b21.jpg", "alt": "Studio sample: Glass Kingdom"},
    {"src": "core/img/showcase/b22.jpg", "alt": "Studio sample: The Long Game"},
    {"src": "core/img/showcase/b26.jpg", "alt": "Studio sample: Speak Easy"},
]

GENRE_TILES = [
    {
        "name": "Fiction",
        "tint": "g-mint",
        "copy": "Novels, thrillers, romance and every story in between, edited and designed with care.",
        "covers": ["b11.jpg", "b25.jpg", "b20.jpg"],
    },
    {
        "name": "Nonfiction",
        "tint": "g-sky",
        "copy": "Memoirs, guides and big ideas, given the clarity and polish they deserve.",
        "covers": ["b22.jpg", "b16.jpg", "b18.jpg"],
    },
    {
        "name": "Children's and YA",
        "tint": "g-blush",
        "copy": "Picture books, young readers and young adult stories, built with imagination.",
        "covers": ["b15.jpg", "b21.jpg", "b4.jpg"],
    },
]

FAQS = [
    {
        "q": "Do I keep the rights to my book?",
        "a": "Yes. Your manuscript, your cover artwork and your book's rights belong "
             "to you. We work as your publishing team, not as a publisher that "
             "holds your rights. Everything we produce for your book is yours.",
    },
    {
        "q": "Who receives the royalties?",
        "a": "You do. Wherever possible we publish under your own retailer accounts, "
             "so royalties flow directly from each store to you. We never take a "
             "percentage of your book's earnings.",
    },
    {
        "q": "Which platforms can you publish my book on?",
        "a": "We regularly set books up on Amazon KDP, IngramSpark, Lulu, Kobo, "
             "Barnes & Noble Press, Draft2Digital, Apple Books and Google Play "
             "Books. Which ones make sense depends on your book and goals. We "
             "advise and you decide.",
    },
    {
        "q": "How long does the publishing process take?",
        "a": "It depends on the services your book needs. Editing is usually the "
             "longest stage, while design, formatting and store setup are quicker. "
             "Once we have seen your manuscript we give you a schedule and keep "
             "to it.",
    },
    {
        "q": "Do you work with new authors?",
        "a": "Most of our authors are publishing their first book. We explain every "
             "step in plain language, show you previews before anything is final, "
             "and you approve each stage before we move to the next.",
    },
    {
        "q": "What does it cost?",
        "a": "Pricing depends on your manuscript's length and the services you "
             "choose. Tell us about your book through the contact form or live "
             "chat and we will send you a clear, itemised quote with no "
             "obligation.",
    },
]


# Author testimonials. Only real, permissioned stories go here.
# Each: {"name", "book", "quote", "photo" (static path or None), "location"}
TESTIMONIALS = []
