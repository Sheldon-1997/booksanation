from django.db import models


class Inquiry(models.Model):
    """Contact-form submission from any page."""

    SERVICE_CHOICES = [
        ("publishing", "Publishing & Distribution"),
        ("editing", "Editing & Proofreading"),
        ("cover-design", "Cover Design & Illustration"),
        ("formatting", "Interior Formatting & Typesetting"),
        ("marketing", "Book Marketing"),
        ("ghostwriting", "Ghostwriting"),
        ("audiobook", "Audiobook Production"),
        ("author-website", "Author Website Design"),
        ("other", "Something else"),
    ]

    name = models.CharField(max_length=120)
    email = models.EmailField()
    phone = models.CharField(max_length=40, blank=True)
    service = models.CharField(max_length=30, choices=SERVICE_CHOICES, default="publishing")
    message = models.TextField()
    page = models.CharField(max_length=200, blank=True, help_text="Page the form was sent from")
    gclid = models.CharField("Google Ads click ID", max_length=255, blank=True)
    source = models.CharField(
        max_length=200, blank=True,
        help_text="Where the visitor came from: ad campaign (UTM) or referring site",
    )
    attribution = models.JSONField(default=dict, blank=True, help_text="Ad click IDs, UTM tags, landing page and referrer")
    submitted_ip = models.GenericIPAddressField(blank=True, null=True)
    email_sent = models.BooleanField(default=False, help_text="The notification email reached the mail server")
    email_error = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    handled = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Inquiries"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name} <{self.email}> — {self.get_service_display()}"


class ChatSession(models.Model):
    """A visitor conversation started from the live-chat widget."""

    visitor_name = models.CharField(max_length=120, blank=True)
    visitor_email = models.EmailField(blank=True)
    session_key = models.CharField(max_length=64, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    closed = models.BooleanField(default=False)

    def __str__(self):
        who = self.visitor_name or self.visitor_email or self.session_key[:8]
        return f"Chat with {who}"


class ChatMessage(models.Model):
    SENDER_CHOICES = [("visitor", "Visitor"), ("staff", "Staff")]

    session = models.ForeignKey(ChatSession, on_delete=models.CASCADE, related_name="messages")
    sender = models.CharField(max_length=10, choices=SENDER_CHOICES, default="visitor")
    body = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    read_by_staff = models.BooleanField(default=False)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"[{self.sender}] {self.body[:40]}"


def testimonial_photo_path(instance, filename):
    import secrets
    return f"testimonials/{secrets.token_hex(8)}.jpg"


class Testimonial(models.Model):
    """An author's own story, submitted through the Share your story form.

    Nothing is shown on the site until a staff member ticks "approved".
    """

    name = models.CharField(max_length=120)
    email = models.EmailField(help_text="Not shown on the site; used to confirm the story")
    book_title = models.CharField(max_length=200)
    location = models.CharField(max_length=120, blank=True)
    quote = models.TextField(max_length=900)
    photo = models.ImageField(upload_to=testimonial_photo_path, blank=True)
    consent = models.BooleanField(
        default=False,
        help_text="Author confirmed the book was published with Books A Nation and gave permission to show their photo, name and words",
    )
    approved = models.BooleanField(default=False, help_text="Tick to show this story on the Author Stories page")
    submitted_ip = models.GenericIPAddressField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name}, author of {self.book_title}"


class SiteSettings(models.Model):
    """Site wide text the owner may change: the announcement bar and its offer terms."""

    promo_enabled = models.BooleanField("Show the announcement bar", default=True)
    promo_text = models.CharField(
        max_length=160, default="Up to 50% off publishing packages for new authors. Get your free quote today.",
        help_text="One sentence. Put the headline figure first, for example 'Up to 50% off'.",
    )
    promo_terms = models.TextField(
        "Offer terms", blank=True,
        help_text="Plain words: who qualifies, what is included, until when. Shown under the offer wherever it appears. Google Ads expects this to match the advert.",
    )
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Announcement bar and offer"
        verbose_name_plural = "Announcement bar and offer"

    def __str__(self):
        return "Announcement bar and offer"

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)
        from django.core.cache import cache
        cache.delete("ban-sitesettings")


class SiteIntegrations(models.Model):
    """Tracking, call tracking and live chat IDs, editable in the admin.

    Paste the IDs from each service here. Empty fields switch that service off.
    There is only ever one row.
    """

    gtm_id = models.CharField(
        "Google Tag Manager container ID", max_length=20, blank=True,
        help_text="Looks like GTM-ABC1234. Use either Tag Manager or the Google IDs below, not both for the same tag.",
    )
    ga4_id = models.CharField(
        "Google Analytics 4 measurement ID", max_length=20, blank=True, help_text="Looks like G-ABC123XYZ.",
    )
    google_ads_id = models.CharField(
        "Google Ads tag ID", max_length=20, blank=True, help_text="Looks like AW-123456789.",
    )
    google_ads_lead_label = models.CharField(
        "Google Ads lead conversion label", max_length=60, blank=True,
        help_text="The part after the slash in send_to, for the form lead conversion.",
    )
    google_ads_call_label = models.CharField(
        "Google Ads phone click conversion label", max_length=60, blank=True,
        help_text="The part after the slash in send_to, for clicks on the phone number.",
    )
    microsoft_uet_id = models.CharField(
        "Microsoft Ads UET tag ID", max_length=20, blank=True, help_text="Numbers only, for Bing ads.",
    )
    callrail_swap_url = models.URLField(
        "CallRail swap.js URL", max_length=300, blank=True,
        help_text="From CallRail: Settings, Tracking code. Looks like https://cdn.callrail.com/companies/123/abc/12/swap.js",
    )
    tawk_property_id = models.CharField(
        "Tawk.to property ID", max_length=40, blank=True,
        help_text="From the Tawk.to widget code: the first part after embed.tawk.to/",
    )
    tawk_widget_id = models.CharField(
        "Tawk.to widget ID", max_length=40, blank=True,
        help_text="The second part after the property ID, often 'default' or a short code.",
    )
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Tracking and chat integrations"
        verbose_name_plural = "Tracking and chat integrations"

    def __str__(self):
        return "Tracking and chat integrations"

    def clean(self):
        import re
        from django.core.exceptions import ValidationError

        rules = {
            "gtm_id": (r"GTM-[A-Z0-9]{4,12}", "GTM-ABC1234"),
            "ga4_id": (r"G-[A-Z0-9]{4,16}", "G-ABC123XYZ"),
            "google_ads_id": (r"AW-[0-9]{6,14}", "AW-123456789"),
            "google_ads_lead_label": (r"[A-Za-z0-9_-]{4,60}", "a label like AbCdEf12GhIj"),
            "google_ads_call_label": (r"[A-Za-z0-9_-]{4,60}", "a label like AbCdEf12GhIj"),
            "microsoft_uet_id": (r"[0-9]{5,15}", "numbers only"),
            "callrail_swap_url": (r"https://cdn\.callrail\.com/[A-Za-z0-9/_.-]+\.js", "the https://cdn.callrail.com/.../swap.js link"),
            "tawk_property_id": (r"[A-Za-z0-9]{8,40}", "the property ID"),
            "tawk_widget_id": (r"[A-Za-z0-9_-]{2,40}", "the widget ID"),
        }
        errors = {}
        for field, (pattern, example) in rules.items():
            value = (getattr(self, field) or "").strip()
            setattr(self, field, value)
            if value and not re.fullmatch(pattern, value):
                errors[field] = f"This does not look right. Expected {example}."
        if bool(self.tawk_property_id) != bool(self.tawk_widget_id):
            errors["tawk_widget_id"] = "Tawk.to needs both the property ID and the widget ID."
        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)
        from django.core.cache import cache
        cache.delete("ban-integrations")
