from django.db import models


class Inquiry(models.Model):
    """Contact-form submission from any page."""

    SERVICE_CHOICES = [
        ("publishing", "Publishing & Distribution"),
        ("editing", "Editing & Proofreading"),
        ("cover-design", "Cover Design & Illustration"),
        ("formatting", "Interior Formatting & Typesetting"),
        ("marketing", "Book Marketing"),
        ("other", "Something else"),
    ]

    name = models.CharField(max_length=120)
    email = models.EmailField()
    phone = models.CharField(max_length=40, blank=True)
    service = models.CharField(max_length=30, choices=SERVICE_CHOICES, default="publishing")
    message = models.TextField()
    page = models.CharField(max_length=200, blank=True, help_text="Page the form was sent from")
    created_at = models.DateTimeField(auto_now_add=True)
    handled = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Inquiries"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name} <{self.email}> — {self.get_service_display()}"


class ChatSession(models.Model):
    """A visitor conversation started from the live-chat widget."""

    visitor_name = models.CharField(max_length=120, blank=True)
    visitor_email = models.EmailField(blank=True)
    session_key = models.CharField(max_length=64, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    closed = models.BooleanField(default=False)

    def __str__(self):
        who = self.visitor_name or self.visitor_email or self.session_key[:8]
        return f"Chat with {who}"


class ChatMessage(models.Model):
    SENDER_CHOICES = [("visitor", "Visitor"), ("staff", "Staff")]

    session = models.ForeignKey(ChatSession, on_delete=models.CASCADE, related_name="messages")
    sender = models.CharField(max_length=10, choices=SENDER_CHOICES, default="visitor")
    body = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    read_by_staff = models.BooleanField(default=False)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"[{self.sender}] {self.body[:40]}"


def testimonial_photo_path(instance, filename):
    import secrets
    return f"testimonials/{secrets.token_hex(8)}.jpg"


class Testimonial(models.Model):
    """An author's own story, submitted through the Share your story form.

    Nothing is shown on the site until a staff member ticks "approved".
    """

    name = models.CharField(max_length=120)
    email = models.EmailField(help_text="Not shown on the site; used to confirm the story")
    book_title = models.CharField(max_length=200)
    location = models.CharField(max_length=120, blank=True)
    quote = models.TextField(max_length=900)
    photo = models.ImageField(upload_to=testimonial_photo_path, blank=True)
    consent = models.BooleanField(
        default=False,
        help_text="Author confirmed the book was published with Books A Nation and gave permission to show their photo, name and words",
    )
    approved = models.BooleanField(default=False, help_text="Tick to show this story on the Author Stories page")
    submitted_ip = models.GenericIPAddressField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name}, author of {self.book_title}"
