from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("services/", views.services_index, name="services"),
    path("services/<slug:slug>/", views.service_detail, name="service_detail"),
    path("platforms/", views.platforms_index, name="platforms"),
    path("platforms/<slug:slug>/", views.platform_detail, name="platform_detail"),
    path("studio/", views.studio, name="studio"),
    path("contact/", views.contact, name="contact"),
    path("faq/", views.faq, name="faq"),
    path("privacy-policy/", views.privacy, name="privacy"),
    path("terms-of-service/", views.terms, name="terms"),
    path("robots.txt", views.robots_txt, name="robots"),
    # APIs
    path("api/inquiry/", views.submit_inquiry, name="api_inquiry"),
    path("api/chat/send/", views.chat_send, name="api_chat_send"),
    path("api/chat/poll/", views.chat_poll, name="api_chat_poll"),
]
