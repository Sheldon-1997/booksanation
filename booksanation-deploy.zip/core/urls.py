from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("services/", views.services_index, name="services"),
    path("services/<slug:slug>/", views.service_detail, name="service_detail"),
    path("platforms/", views.platforms_index, name="platforms"),
    path("platforms/<slug:slug>/", views.platform_detail, name="platform_detail"),
    path("studio/", views.studio, name="studio"),
    path("portfolio/", views.portfolio, name="portfolio"),
    path("portfolio/<slug:slug>/", views.portfolio_detail, name="portfolio_detail"),
    path("resources/", views.resources_index, name="resources"),
    path("resources/<slug:slug>/", views.resource_detail, name="resource_detail"),
    path("cookie-policy/", views.cookie_policy, name="cookie_policy"),
    path("publishing-standards/", views.publishing_standards, name="publishing_standards"),
    # Reviewable drafts: noindex, unlinked, excluded from the sitemap
    path("drafts/services/<slug:slug>/", views.draft_service, name="draft_service"),
    path("refund-and-cancellation/", views.refund_policy, name="refund_policy"),
    path("contact/", views.contact, name="contact"),
    path("faq/", views.faq, name="faq"),
    path("testimonials/", views.testimonials, name="testimonials"),
    path("testimonials/share/", views.testimonial_submit, name="testimonial_submit"),
    path("privacy-policy/", views.privacy, name="privacy"),
    path("terms-of-service/", views.terms, name="terms"),
    path("robots.txt", views.robots_txt, name="robots"),
    path("llms.txt", views.llms_txt, name="llms"),
    path("google<str:token>.html", views.google_verification, name="google_verification"),
    path("BingSiteAuth.xml", views.bing_site_auth, name="bing_site_auth"),
    path("<str:key>.txt", views.indexnow_key, name="indexnow_key"),
    # APIs
    path("api/inquiry/", views.submit_inquiry, name="api_inquiry"),
    path("api/chat/send/", views.chat_send, name="api_chat_send"),
    path("api/chat/poll/", views.chat_poll, name="api_chat_poll"),
]
