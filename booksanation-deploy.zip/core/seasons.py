"""Automatic US holiday seasons: theme colors, hanging decorations and the seasonal offer.

Nothing to maintain: every holiday date is calculated for the current year (Easter,
Thanksgiving, Black Friday, Memorial Day...), the active season is chosen from today's
date in New York, and the site shows its colors, garland and message until the season
ends. Outside every season the site looks normal.

The same file is used by Books A Nation and Publishing Core; only the wording of the
offer changes per site (see OFFER_TEXT in each site's settings).
"""
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

NEW_YORK = ZoneInfo("America/New_York")


# --------------------------------------------------------------------------- #
#  Holiday dates
# --------------------------------------------------------------------------- #

def nth_weekday(year, month, weekday, n):
    """n-th weekday (Mon=0) of a month; n=-1 means the last one."""
    if n > 0:
        first = date(year, month, 1)
        return first + timedelta(days=(weekday - first.weekday()) % 7 + 7 * (n - 1))
    nxt = date(year + (month == 12), month % 12 + 1, 1)
    last = nxt - timedelta(days=1)
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def easter(year):
    """Western Easter Sunday (anonymous Gregorian algorithm)."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = (h + l - 7 * m + 114) % 31 + 1
    return date(year, month, day)


def thanksgiving(year):
    return nth_weekday(year, 11, 3, 4)  # fourth Thursday of November


# --------------------------------------------------------------------------- #
#  Seasons: window, look and message
# --------------------------------------------------------------------------- #

PATRIOTIC = {"bg": "#0a3161", "fg": "#ffffff", "accent": "#b31942", "accent2": "#ffffff"}

SEASON_LOOKS = {
    "new_year": {"bg": "#111827", "fg": "#fde68a", "accent": "#d4af37", "accent2": "#f9fafb",
                 "items": ["star", "bauble", "star", "book"], "particles": "confetti"},
    "mlk": {"bg": "#1f2937", "fg": "#f9fafb", "accent": "#fbbf24", "accent2": "#e5e7eb",
            "items": ["star"], "particles": ""},
    "valentines": {"bg": "#9f1239", "fg": "#fff1f2", "accent": "#fb7185", "accent2": "#fecdd3",
                   "items": ["heart", "heart", "book"], "particles": "hearts"},
    "presidents": {**PATRIOTIC, "items": ["pennant", "star"], "particles": ""},
    "st_patricks": {"bg": "#14532d", "fg": "#ecfdf5", "accent": "#22c55e", "accent2": "#fde68a",
                    "items": ["shamrock", "shamrock", "book"], "particles": ""},
    "easter": {"bg": "#5b21b6", "fg": "#f5f3ff", "accent": "#f9a8d4", "accent2": "#a7f3d0",
               "items": ["egg", "flower", "egg", "book"], "particles": ""},
    "mothers_day": {"bg": "#9d174d", "fg": "#fdf2f8", "accent": "#f9a8d4", "accent2": "#fde68a",
                    "items": ["flower", "heart", "gift"], "particles": ""},
    "memorial": {**PATRIOTIC, "items": ["pennant", "star"], "particles": ""},
    "fathers_day": {"bg": "#1e3a5f", "fg": "#e0f2fe", "accent": "#38bdf8", "accent2": "#fbbf24",
                    "items": ["gift", "book", "star"], "particles": ""},
    "july4": {**PATRIOTIC, "items": ["pennant", "star", "pennant"], "particles": "confetti"},
    "labor_day": {**PATRIOTIC, "items": ["pennant", "star"], "particles": ""},
    "halloween": {"bg": "#1c1917", "fg": "#fed7aa", "accent": "#f97316", "accent2": "#a78bfa",
                  "items": ["pumpkin", "bat", "pumpkin", "book"], "particles": ""},
    "veterans": {**PATRIOTIC, "items": ["pennant", "star"], "particles": ""},
    "black_friday_early": {"bg": "#0a0a0a", "fg": "#ffffff", "accent": "#facc15", "accent2": "#ffffff",
                           "items": ["tag", "star", "bauble"], "particles": ""},
    "thanksgiving": {"bg": "#7c2d12", "fg": "#ffedd5", "accent": "#f59e0b", "accent2": "#fde68a",
                     "items": ["leaf", "leaf", "book"], "particles": "leaves"},
    "black_friday": {"bg": "#0a0a0a", "fg": "#ffffff", "accent": "#facc15", "accent2": "#ffffff",
                     "items": ["tag", "star", "tag", "bauble"], "particles": "confetti"},
    "cyber_monday": {"bg": "#0b1020", "fg": "#e0f2fe", "accent": "#22d3ee", "accent2": "#a78bfa",
                     "items": ["tag", "star", "tag"], "particles": ""},
    "christmas": {"bg": "#0f3d2e", "fg": "#fff7e6", "accent": "#c8102e", "accent2": "#d4a843",
                  "items": ["bauble", "star", "bauble", "gift"], "particles": "snow"},
}

# name: shown to people. lead: the start of the announcement. offer: whether the seasonal
# discount applies (Martin Luther King Jr. Day carries a message only).
SEASON_TEXT = {
    "new_year": ("New Year", "New year, new book", True),
    "mlk": ("Martin Luther King Jr. Day", "Honoring Dr. Martin Luther King Jr. Every voice deserves to be heard", False),
    "valentines": ("Valentine's Day", "Valentine's week: fall in love with your book again", True),
    "presidents": ("Presidents' Day", "Presidents' Day savings for authors", True),
    "st_patricks": ("St. Patrick's Day", "A lucky week for authors", True),
    "easter": ("Easter", "Easter offer for authors", True),
    "mothers_day": ("Mother's Day", "Mother's Day: celebrate the storytellers in your family", True),
    "memorial": ("Memorial Day", "Memorial Day weekend offer", True),
    "fathers_day": ("Father's Day", "Father's Day: his story, beautifully published", True),
    "july4": ("Independence Day", "Fourth of July: publish on your own terms", True),
    "labor_day": ("Labor Day", "Labor Day weekend offer", True),
    "halloween": ("Halloween", "Halloween week: no tricks, just great books", True),
    "veterans": ("Veterans Day", "Thank you to every veteran. Veterans Day offer", True),
    "black_friday_early": ("Black Friday Early Access", "Black Friday early access", True),
    "thanksgiving": ("Thanksgiving", "Thankful for every author we work with", True),
    "black_friday": ("Black Friday", "Black Friday", True),
    "cyber_monday": ("Cyber Monday", "Cyber Monday", True),
    "christmas": ("Christmas", "Christmas offer: the perfect time to publish", True),
}


def _windows(year):
    """(key, first day, last day) for every season starting in `year`, in priority order."""
    tg = thanksgiving(year)
    es = easter(year)
    mlk = nth_weekday(year, 1, 0, 3)
    pres = nth_weekday(year, 2, 0, 3)
    mem = nth_weekday(year, 5, 0, -1)
    labor = nth_weekday(year, 9, 0, 1)
    moms = nth_weekday(year, 5, 6, 2)
    dads = nth_weekday(year, 6, 6, 3)
    return [
        ("cyber_monday", tg + timedelta(days=4), tg + timedelta(days=5)),
        ("black_friday", tg + timedelta(days=1), tg + timedelta(days=3)),
        ("thanksgiving", tg - timedelta(days=3), tg),
        ("black_friday_early", date(year, 11, 12), tg - timedelta(days=4)),
        ("veterans", date(year, 11, 9), date(year, 11, 11)),
        ("halloween", date(year, 10, 24), date(year, 10, 31)),
        ("labor_day", labor - timedelta(days=3), labor),
        ("july4", date(year, 6, 28), date(year, 7, 5)),
        ("fathers_day", dads - timedelta(days=6), dads),
        ("memorial", mem - timedelta(days=3), mem),
        ("mothers_day", moms - timedelta(days=6), moms),
        ("easter", es - timedelta(days=7), es + timedelta(days=1)),
        ("st_patricks", date(year, 3, 14), date(year, 3, 17)),
        ("valentines", date(year, 2, 7), date(year, 2, 14)),
        ("presidents", pres - timedelta(days=2), pres),
        ("mlk", mlk - timedelta(days=2), mlk),
        ("christmas", date(year, 12, 1), date(year, 12, 26)),
        ("new_year", date(year, 12, 27), date(year + 1, 1, 5)),
    ]


def season_key_for(day):
    """The season key active on `day`, with its last day, or (None, None)."""
    for year in (day.year, day.year - 1):  # New Year runs from late December into January
        for key, start, end in _windows(year):
            if start <= day <= end:
                return key, end
    return None, None


def today_in_new_york(now=None):
    return (now or datetime.now(tz=NEW_YORK)).astimezone(NEW_YORK).date()


def _ends_text(day, end):
    if end == day:
        return "Ends today"
    if end == day + timedelta(days=1):
        return "Ends tomorrow"
    return f"Ends {end.strftime('%B')} {end.day}"


def build_season(key, day=None, end=None, offer_phrase="up to 50% off publishing packages", on_dark=False):
    """Everything a template needs for one season."""
    look = SEASON_LOOKS[key]
    name, lead, has_offer = SEASON_TEXT[key]
    day = day or today_in_new_york()
    if end is None:
        end = next((e for k, s, e in _windows(day.year) if k == key), day)
    if has_offer:
        offer = offer_phrase[0].upper() + offer_phrase[1:]
        message = f"{lead}. {offer}." if ":" in lead else f"{lead}: {offer_phrase}."
        short = f"{name}: {offer_phrase.split(' off')[0]} off"
    else:
        message = f"{lead}."
        short = name
    return {
        "key": key, "name": name, "message": message, "short": short, "offer": has_offer,
        "offer_phrase": offer_phrase, "ends": _ends_text(day, end) if has_offer else "",
        "end_date": end, "bg": look["bg"], "fg": look["fg"], "accent": look["accent"],
        "accent2": look["accent2"], "accent_fg": "#111111" if _is_light(look["accent"]) else "#ffffff",
        "particles": look["particles"],
        "garland": garland_svg(look, on_dark=on_dark), "garland_dark": garland_svg(look, on_dark=True),
        "css_class": f"season-{key.replace('_', '-')}",
    }


def current_season(request=None, offer_phrase="up to 50% off publishing packages", enabled=True, on_dark=False):
    """Active season for today (New York), or a preview chosen with ?season=<key>.

    ?season=none shows the site without a season. Returns None outside every season.
    """
    preview = request.GET.get("season", "") if request is not None else ""
    if preview == "none":
        return None
    if preview in SEASON_LOOKS:
        return build_season(preview, offer_phrase=offer_phrase, on_dark=on_dark)
    if not enabled:
        return None
    day = today_in_new_york()
    key, end = season_key_for(day)
    return build_season(key, day, end, offer_phrase, on_dark) if key else None


def season_terms(season, brand, scope="publishing packages"):
    """Plain offer terms for the active season (shown on the contact page and in the forms)."""
    if not season or not season["offer"]:
        return ""
    end = season["end_date"]
    return (f"{season['name']} offer: up to 50% off selected {scope} for new projects confirmed by "
            f"{end.strftime('%B')} {end.day}, {end.year}. The discount applies to {brand} service fees, "
            "not to printing, retailer or platform charges. Your final price is confirmed in your "
            "written quote before any work begins.")


# --------------------------------------------------------------------------- #
#  Hanging garland (inline SVG, no external files)
# --------------------------------------------------------------------------- #

def _shape(kind, fill, fill2):
    """One hanging ornament drawn around (0, 0); the string attaches at the top (0, -12)."""
    if kind == "bauble":
        return (f'<rect x="-3.5" y="-15" width="7" height="5" rx="1.2" fill="{fill2}"/>'
                f'<circle r="11" fill="{fill}"/><circle cx="-3.5" cy="-3.5" r="3" fill="#fff" opacity=".45"/>')
    if kind == "star":
        return (f'<path d="M0-13l3.6 7.6 8.3 1.1-6.1 5.8 1.5 8.2L0 5.8-7.3 9.7l1.5-8.2-6.1-5.8 8.3-1.1z" '
                f'fill="{fill}" stroke="{fill2}" stroke-width=".8"/>')
    if kind == "heart":
        return f'<path d="M0 11C-14 1-12-10-5.5-10.5-2.6-10.7-1-8.5 0-7c1-1.5 2.6-3.7 5.5-3.5C12-10 14 1 0 11z" fill="{fill}"/>'
    if kind == "egg":
        return (f'<ellipse cy="1" rx="9" ry="12" fill="{fill}"/>'
                f'<path d="M-8.6-1q4.3 3 8.6 0t8.6 0" stroke="{fill2}" stroke-width="2.4" fill="none"/>')
    if kind == "flower":
        petals = "".join(f'<circle cx="{dx}" cy="{dy}" r="5" fill="{fill}"/>'
                         for dx, dy in ((0, -7), (6.7, -2.2), (4.1, 5.7), (-4.1, 5.7), (-6.7, -2.2)))
        return petals + f'<circle r="3.6" fill="{fill2}"/>'
    if kind == "pumpkin":
        return (f'<rect x="-1.6" y="-15" width="3.2" height="5" rx="1" fill="#4d7c0f"/>'
                f'<ellipse cx="-5" rx="6.5" ry="9.5" fill="{fill}"/><ellipse cx="5" rx="6.5" ry="9.5" fill="{fill}"/>'
                f'<ellipse rx="6" ry="10" fill="{fill}" stroke="#7c2d12" stroke-opacity=".35"/>')
    if kind == "bat":
        return (f'<path d="M0-4c2-3 3-5 3-5l1 3c4-3 9-2 12 1-3 0-5 2-5 5-2-2-4-2-6 0-1-2-3-3-5-3s-4 1-5 3c-2-2-4-2-6 0 '
                f'0-3-2-5-5-5 3-3 8-4 12-1l1-3s1 2 3 5z" fill="{fill2}"/>')
    if kind == "leaf":
        return (f'<path d="M0-13C9-8 11 3 0 13-11 3-9-8 0-13z" fill="{fill}"/>'
                f'<path d="M0-11V12" stroke="{fill2}" stroke-width="1.2"/>')
    if kind == "shamrock":
        return (f'<circle cx="0" cy="-6" r="5.5" fill="{fill}"/><circle cx="-5.5" cy="2" r="5.5" fill="{fill}"/>'
                f'<circle cx="5.5" cy="2" r="5.5" fill="{fill}"/><path d="M0 2q1 7 4 11" stroke="{fill}" stroke-width="2" fill="none"/>')
    if kind == "pennant":
        return (f'<path d="M-11-12h22L0 13z" fill="{fill}"/>'
                f'<path d="M0-6.5l1.6 3.2 3.5.5-2.6 2.5.6 3.5L0 1.6-3.1 3.2l.6-3.5-2.6-2.5 3.5-.5z" fill="{fill2}"/>')
    if kind == "gift":
        return (f'<rect x="-10" y="-9" width="20" height="18" rx="2" fill="{fill}"/>'
                f'<rect x="-2" y="-9" width="4" height="18" fill="{fill2}"/><rect x="-10" y="-2" width="20" height="4" fill="{fill2}"/>'
                f'<path d="M0-9c-4-6-9-3-5 0M0-9c4-6 9-3 5 0" stroke="{fill2}" stroke-width="2" fill="none"/>')
    if kind == "tag":
        return (f'<path d="M-12-9h17l8 9-8 9h-17z" fill="{fill}"/><circle cx="7" cy="0" r="2" fill="#0a0a0a"/>'
                f'<text x="-4" y="3.6" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" '
                f'font-size="8.5" font-weight="700" fill="#0a0a0a">SALE</text>')
    if kind == "book":
        return (f'<rect x="-9" y="-11" width="18" height="22" rx="2" fill="{fill}"/>'
                f'<rect x="-9" y="-11" width="4" height="22" rx="1" fill="{fill2}" opacity=".85"/>'
                f'<path d="M-2-5h8M-2-1h8" stroke="#fff" stroke-opacity=".7" stroke-width="1.4"/>')
    return ""


def _is_light(hex_colour):
    h = hex_colour.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (0.299 * r + 0.587 * g + 0.114 * b) > 170


def garland_svg(look, width=2400, height=66, on_dark=False):
    """A sagging string across the top with ornaments hanging at varied lengths.

    on_dark: the garland hangs over a dark area (light ornaments read well); otherwise
    light ornaments are swapped for the season's deep colour so they stay visible.
    """
    items = look["items"]
    if on_dark:
        colours = [look["accent"], look["accent2"], look["fg"]]
    else:
        colours = [look["accent"] if not _is_light(look["accent"]) else look["bg"],
                   look["bg"] if _is_light(look["accent2"]) else look["accent2"], look["accent"]]
    string = look["accent"] if (on_dark or not _is_light(look["accent"])) else look["bg"]
    span = 160  # one sag of the string
    parts = [f'<svg class="season-garland" xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
             f'viewBox="0 0 {width} {height}" aria-hidden="true" focusable="false">']
    path = "M0 2 " + " ".join(f"Q{x + span / 2:.0f} 22 {x + span:.0f} 2" for x in range(0, width, span))
    parts.append(f'<path d="{path}" fill="none" stroke="{string}" stroke-width="2" stroke-opacity=".9"/>')
    n = 0
    for x in range(0, width, span):
        for frac, drop in ((0.25, 14), (0.5, 26), (0.75, 14)):
            cx = x + span * frac
            top = 2 + 20 * (1 - (2 * frac - 1) ** 2)  # point on the sagging curve
            cy = top + drop
            kind = items[n % len(items)]
            fill = colours[n % 2]
            fill2 = colours[(n + 1) % 3]
            if kind == "tag":  # dark "SALE" lettering needs the light accent behind it
                fill = look["accent"]
            if kind == "pennant":
                fill = colours[0] if n % 3 else (look["accent2"] if on_dark else look["bg"])
                fill2 = "#ffffff" if fill != "#ffffff" else look["bg"]
            parts.append(f'<path d="M{cx:.1f} {top:.1f}V{cy - 12:.1f}" stroke="{string}" stroke-opacity=".7" stroke-width="1"/>')
            parts.append(f'<g transform="translate({cx:.1f} {cy:.1f})"><g class="season-orn">{_shape(kind, fill, fill2)}</g></g>')
            n += 1
    parts.append("</svg>")
    return "".join(parts)
