"""Detailed service content for Books A Nation.

Merged into SERVICES in data.py. Each entry adds the sections a service page
needs: the author's problem, deliverables, process, required inputs,
ownership and handoff, FAQs and related services.

Entries marked draft=True are NOT public. They render only at
/drafts/services/<slug>/ with a noindex header and a review banner. The
ghostwriting, audiobook and author website services were approved by the
owner on 3 November 2026 and are public.

Copy rule: plain sentences, no em dashes, en dashes, hashtags or decorative
check marks.
"""

SERVICE_DETAILS = {
    "editing": {
        "headline": "Book editing and proofreading services",
        "problem": (
            "Most manuscripts are read by their author so many times that the "
            "author stops seeing them. A good edit brings a trained outside eye "
            "to the structure, the sentences and the details, in that order, "
            "so the book reads the way you meant it to."
        ),
        "levels": [
            {
                "name": "Developmental editing",
                "what": "The big picture: structure, pacing, character or argument, chapter order and what is missing.",
                "when": "Early, once a full draft exists and before any sentence-level polish.",
                "get": "An editorial letter with specific recommendations, plus margin notes in the manuscript.",
            },
            {
                "name": "Line editing",
                "what": "The sentences: rhythm, word choice, tone, repetition and clarity, paragraph by paragraph.",
                "when": "After the structure is settled.",
                "get": "A tracked-changes manuscript with every suggested rewrite visible and explained where needed.",
            },
            {
                "name": "Copy editing",
                "what": "Correctness and consistency: grammar, punctuation, spelling, usage, continuity, names, dates and facts you have provided.",
                "when": "After line editing, before typesetting.",
                "get": "A tracked-changes manuscript and a style sheet listing every decision, so the book stays consistent.",
            },
            {
                "name": "Proofreading",
                "what": "The last pass on the typeset pages: typos, bad line breaks, missing words, layout slips.",
                "when": "After formatting, on the final PDF or EPUB.",
                "get": "A marked proof with corrections, ready for the formatter to apply.",
            },
        ],
        "deliverables": [
            "An editorial letter for developmental work, or tracked changes for line and copy editing",
            "A style sheet recording spelling, hyphenation, capitalisation and naming decisions",
            "A short query list where we need your decision rather than guessing",
            "One review round in which we answer your questions about the edit",
        ],
        "process": [
            {"step": "Sample edit", "text": "We edit a short sample of your manuscript so you can see our approach before committing."},
            {"step": "Scope and quote", "text": "We confirm which level of editing the book needs, the schedule and the fee in writing."},
            {"step": "The edit", "text": "We work through the manuscript in passes. Every change stays visible as a tracked change or a comment."},
            {"step": "Your review", "text": "You accept, reject or discuss changes. Nothing is final until you say so."},
            {"step": "Handoff", "text": "You receive the clean and tracked versions plus the style sheet, ready for formatting."},
        ],
        "inputs": [
            "The complete manuscript as a Word document or Google Doc",
            "Your genre and the readers you are writing for",
            "Any house rules you already follow, such as UK or US spelling",
            "A note on anything you do not want changed, such as dialect in dialogue",
        ],
        "ownership": (
            "Your manuscript stays yours at every stage. Our edits are suggestions "
            "until you accept them, and the finished files are delivered to you "
            "without any claim on your work."
        ),
        "faqs": [
            {"q": "Which level of editing does my book need?", "a": "Send us the manuscript and we will tell you honestly. Many books need a developmental read first and a copy edit later, but some only need a careful copy edit and a proof."},
            {"q": "Will you change my voice?", "a": "No. Line editing works with your voice, not over it. Where a sentence could be read two ways, we ask rather than assume."},
            {"q": "Do you edit in US and UK English?", "a": "Yes. Tell us which convention your book follows and we keep it consistent throughout."},
            {"q": "Can I see a sample before I decide?", "a": "Yes. A sample edit is part of how we quote, so you know what you are getting before any fee is agreed."},
        ],
        "related": ["formatting", "cover-design", "publishing"],
    },

    "cover-design": {
        "headline": "Book cover design services",
        "problem": (
            "A cover has one job: to make the right reader stop and look. It has "
            "to signal the genre at thumbnail size on a phone and still hold up "
            "as a printed object in someone's hands. That takes research, not "
            "just taste."
        ),
        "deliverables": [
            "Two or three concept directions to choose from, based on your brief",
            "A finished front cover, developed from the chosen concept",
            "A full print wraparound with spine and back cover text, sized to your trim size and page count",
            "Ebook cover files sized for each store you publish on",
            "Print-ready PDF with bleed, plus editable source files once the fee is paid",
        ],
        "process": [
            {"step": "Brief", "text": "We ask about the book, the reader, comparable titles and anything you already have in mind."},
            {"step": "Concepts", "text": "You receive two or three distinct directions as front cover mockups."},
            {"step": "Development", "text": "We refine the chosen direction: typography, imagery, colour and the back cover."},
            {"step": "Revisions", "text": "Two revision rounds are included. Further rounds are quoted before any work starts."},
            {"step": "Final files", "text": "We deliver files to the exact specification of your printer and stores, and check the first proof with you."},
        ],
        "inputs": [
            "Title, subtitle, author name and back cover copy",
            "Genre and a few comparable books you admire",
            "Trim size and approximate page count, or we will advise on both",
            "Any artwork, photography or brand elements you own and want used",
        ],
        "ownership": (
            "You own the final cover artwork outright once the fee is paid, "
            "including the source files. Stock imagery and fonts are licensed "
            "for your use and we tell you exactly what each licence allows."
        ),
        "faqs": [
            {"q": "Do you use stock images or AI images?", "a": "We use licensed stock photography, original illustration or typography, depending on the brief. We tell you where every element comes from and what its licence covers."},
            {"q": "What if I do not like any of the concepts?", "a": "We go back to the brief and try again. The concept stage exists so that nothing is developed until you are happy with the direction."},
            {"q": "Can you redesign an existing cover?", "a": "Yes, as long as you own the rights to the existing artwork or we replace the elements you do not own."},
            {"q": "Do you design series covers?", "a": "Yes. We build a series look that stays consistent across books while giving each its own identity."},
        ],
        "related": ["formatting", "publishing", "marketing"],
    },

    "formatting": {
        "headline": "Book formatting and typesetting for print and ebook",
        "problem": (
            "Readers notice bad typesetting without knowing why: uneven spacing, "
            "orphan lines, chapters that start in the wrong place, ebooks that "
            "fall apart on a different device. Good formatting is invisible, and "
            "that is the point."
        ),
        "deliverables": [
            "Print-ready interior PDF for each trim size you publish in",
            "A reflowable EPUB that passes store validation",
            "A Kindle-ready file prepared from the same source",
            "Front matter and back matter set up: title page, copyright page, contents, dedication, about the author",
            "One revision round after you review the proof",
        ],
        "process": [
            {"step": "File check", "text": "We review your edited manuscript for anything that will cause layout problems and fix it with you."},
            {"step": "Design", "text": "We choose typefaces, margins, running heads and chapter openings suited to the genre and trim size."},
            {"step": "Proof", "text": "You receive a full PDF proof and an EPUB to check on your own devices."},
            {"step": "Corrections", "text": "We apply your corrections and run a final check for widows, orphans and spacing."},
            {"step": "Validation", "text": "The EPUB is validated and the print PDF is checked against your printer's specification before delivery."},
        ],
        "inputs": [
            "The final edited manuscript, with chapter breaks marked",
            "Trim size and your print platform, or we will recommend both",
            "Images or diagrams at print resolution, if your book has them",
            "Your cover files, so the spine width matches the final page count",
        ],
        "ownership": (
            "The formatted files are yours. We deliver print and ebook files you "
            "can upload to any platform, and we keep the project on file so "
            "later corrections are quick."
        ),
        "faqs": [
            {"q": "Which trim sizes do you support?", "a": "All common sizes for paperbacks and hardcovers, including 5 x 8, 5.5 x 8.5 and 6 x 9 inches, plus A5 and custom sizes your printer accepts."},
            {"q": "Will my ebook look the same on every device?", "a": "Reflowable ebooks adapt to the reader's screen and settings, so the text moves. We design so the structure, headings and images stay correct however the reader sets their font."},
            {"q": "Can you format a book with many images or tables?", "a": "Yes. Image-heavy and nonfiction books take more care and we quote them separately after seeing the files."},
            {"q": "What if I find a typo after delivery?", "a": "Small corrections after delivery are quick and we quote them at a fixed rate, so you are never stuck with an error."},
        ],
        "related": ["editing", "cover-design", "publishing"],
    },

    "publishing": {
        "headline": "Book publishing and distribution setup",
        "problem": (
            "Setting a book up on the retail platforms is where many authors "
            "lose weeks: metadata fields, categories, pricing by territory, "
            "ISBNs, file rejections. We handle the setup properly, on accounts "
            "that belong to you."
        ),
        "deliverables": [
            "Platform accounts created in your name, or your existing accounts configured",
            "Metadata written and entered: description, categories, keywords, series data and contributor details",
            "ISBN guidance, and ISBN assignment through your own registration where you choose to own them",
            "Print and ebook files uploaded, checked and approved on each platform",
            "A handover sheet listing every account, setting and price we set up for you",
        ],
        "process": [
            {"step": "Distribution plan", "text": "We recommend which stores and distributors suit your book and explain the trade-offs."},
            {"step": "Accounts", "text": "You create or share access to your accounts. Payment and tax details are always entered by you."},
            {"step": "Setup", "text": "We enter metadata, upload files and set territory pricing on each platform."},
            {"step": "Proofs", "text": "We order or review printed proofs with you where the platform offers them."},
            {"step": "Go live", "text": "Your book is published on your chosen release date and we confirm each listing is correct."},
        ],
        "inputs": [
            "Final print and ebook files, or we prepare them as part of formatting",
            "Your book description, author bio and keywords, or notes for us to write them",
            "Pricing decisions for each format and main territory",
            "Access to your platform accounts for the setup period",
        ],
        "ownership": (
            "Your book is published under your own accounts wherever the platform "
            "allows, so rights, royalties and control stay with you. We never "
            "list your book under our name without your written agreement."
        ),
        "faqs": [
            {"q": "Whose name is the book published under?", "a": "Yours, under your own accounts. Royalties are paid by the platforms directly to you."},
            {"q": "Do I need my own ISBN?", "a": "Not always. Some platforms provide a free ISBN for use on that platform only. Owning your ISBN gives you more control across stores, and we explain both options before you decide."},
            {"q": "Can you publish on platforms I already use?", "a": "Yes. We work inside your existing accounts and leave everything documented for you."},
            {"q": "Which platforms do you set up?", "a": "Amazon KDP, IngramSpark, Lulu, Kobo, Barnes and Noble Press, Draft2Digital, Apple Books and Google Play Books, plus others on request. See our platform guides for details on each."},
        ],
        "related": ["formatting", "marketing", "cover-design"],
    },

    "marketing": {
        "headline": "Book marketing and launch planning",
        "problem": (
            "Publishing a book is not the same as launching one. Without a plan, "
            "most books go live quietly and stay quiet. A launch plan gives your "
            "book its best chance in the weeks that matter most."
        ),
        "deliverables": [
            "A written launch plan with a timeline from pre-order to the first month after release",
            "Store page optimisation: description, categories and keyword research",
            "A set of promotional graphics matched to your cover for social media and email",
            "Advertising setup guidance for the channels you choose, with suggested starting budgets",
            "A release day checklist you can follow yourself",
        ],
        "process": [
            {"step": "Goals", "text": "We agree what a good launch looks like for this book and this budget."},
            {"step": "Positioning", "text": "We research the category and write or sharpen the description and keywords."},
            {"step": "Assets", "text": "We produce the graphics and copy the plan calls for."},
            {"step": "Launch", "text": "You run the plan with our checklist, or we support you through release week."},
            {"step": "Review", "text": "After the first month we look at what worked and suggest the next step."},
        ],
        "inputs": [
            "Your final cover and book description",
            "Any existing audience: mailing list, social accounts, reader groups",
            "A realistic budget for advertising, which can be zero",
            "Your launch date, or a window you are aiming for",
        ],
        "ownership": (
            "All graphics, copy and plans are yours to keep and reuse. Advertising "
            "accounts are set up in your name and billed to you directly."
        ),
        "faqs": [
            {"q": "Can you guarantee sales or rankings?", "a": "No, and nobody honest can. We can give your book a professional launch and show you exactly what we did and why."},
            {"q": "Do you run the ads for me?", "a": "We set up and explain the campaigns in your own advertising accounts. Ongoing management is quoted separately if you want it."},
            {"q": "Is marketing worth it for a first book?", "a": "A modest, well-planned launch is worth it. We will tell you if a larger spend does not make sense for your book."},
        ],
        "related": ["publishing", "cover-design", "editing"],
    },

    # ------------------------------------------------------------------ #
    #  DRAFT SERVICES: not public until the owner confirms them.
    # ------------------------------------------------------------------ #
    "ghostwriting": {
        "name": "Ghostwriting",
        "headline": "Ghostwriting services for authors",
        "short": "Book ghostwriting services: your ideas, interviews and story written into a manuscript in your voice, credited to you.",
        "icon": "pen",
        "blurb": (
            "Some books exist as expertise, interviews or a life story long before "
            "they exist as a manuscript. Ghostwriting turns what you know and "
            "what you have lived into a book written in your voice, credited to you."
        ),
        "problem": (
            "You have the material and the authority, but not the months of "
            "writing time, or writing is simply not the part you enjoy. A "
            "ghostwriter builds the manuscript with you, from your ideas, your "
            "notes and your recorded conversations."
        ),
        "deliverables": [
            "A chapter outline agreed with you before writing begins",
            "A complete manuscript written in your voice, delivered in stages",
            "Interview recordings and transcripts, which remain yours",
            "Revision rounds at each stage so the book never drifts from your intent",
            "A manuscript ready for editing, formatting and publishing under your name",
        ],
        "process": [
            {"step": "Discovery", "text": "We talk through the book's purpose, reader and structure, and agree an outline."},
            {"step": "Interviews", "text": "Regular recorded conversations capture your material and your way of speaking."},
            {"step": "Drafting", "text": "Chapters are written and sent to you in batches for comments."},
            {"step": "Revision", "text": "Each batch is revised from your notes before the next is written."},
            {"step": "Completion", "text": "The full manuscript is assembled, read through as a whole and handed over."},
        ],
        "inputs": [
            "Your availability for regular interviews, usually one or two hours a week",
            "Existing notes, talks, articles or recordings you want drawn on",
            "A clear sense of who the book is for and what it should achieve",
            "Honest feedback on early chapters, which is what makes the voice right",
        ],
        "ownership": (
            "You are the author. The manuscript, the recordings and the "
            "copyright are yours, and the writer's involvement stays confidential "
            "unless you choose to credit them."
        ),
        "faqs": [
            {"q": "Will the book sound like me?", "a": "That is the whole job. The voice comes from your interviews and your feedback on early chapters, not from a template."},
            {"q": "Is ghostwriting confidential?", "a": "Yes. A confidentiality clause is part of the agreement and the writer is never credited unless you decide to."},
            {"q": "How long does a ghostwritten book take?", "a": "It depends on length and how quickly interviews can happen. The schedule is agreed in writing before work starts."},
        ],
        "related": ["editing", "publishing", "marketing"],
    },

    "audiobook": {
        "name": "Audiobook Production",
        "headline": "Audiobook production and narration",
        "short": "Audiobook production services: narrator casting, recording, editing and mastering to the standards audiobook stores require.",
        "icon": "mic",
        "blurb": (
            "Audiobooks reach readers who listen on the commute, at the gym and "
            "in the kitchen. Production covers narrator casting, recording, "
            "editing and mastering to the specifications the audiobook stores require."
        ),
        "problem": (
            "Recording an audiobook well is a technical job as much as a "
            "performance: consistent sound, correct pacing, clean edits and files "
            "that pass the stores' checks. Most rejections happen on the technical "
            "side, not the reading."
        ),
        "deliverables": [
            "Narrator casting with audition samples for you to choose from",
            "A fully recorded, edited and mastered audiobook",
            "Chapter files named and ordered to the specification of each store",
            "Opening and closing credits, plus a retail sample",
            "Cover artwork adapted to the square format audiobook stores require",
        ],
        "process": [
            {"step": "Preparation", "text": "We prepare the manuscript for narration, with a pronunciation guide for names and terms."},
            {"step": "Casting", "text": "You hear audition samples and choose the narrator."},
            {"step": "Recording", "text": "The book is recorded in sessions, with a first chapter sent to you for approval."},
            {"step": "Editing and mastering", "text": "Breaths, noise and mistakes are removed and the audio is mastered to store standards."},
            {"step": "Review and delivery", "text": "You listen to the full book, corrections are made, and files are delivered or uploaded to your accounts."},
        ],
        "inputs": [
            "The final, edited manuscript",
            "A pronunciation guide for unusual names, places and terms",
            "Your preference for narrator voice and style, or a few audiobooks you like",
            "Your cover files for the square audiobook artwork",
        ],
        "ownership": (
            "The finished recording and the rights to distribute it are yours. "
            "Narrator agreements are written so you can sell the audiobook on any "
            "platform you choose."
        ),
        "faqs": [
            {"q": "Can I narrate my own book?", "a": "Often yes, especially for memoir and nonfiction. We can direct and produce an author-read recording, or record it with you remotely."},
            {"q": "Which stores can the audiobook be sold on?", "a": "The files are produced to the common technical standards, so they can be distributed to the major audiobook stores and libraries through the channels you choose."},
            {"q": "How long does production take?", "a": "A typical novel takes several weeks from casting to delivery. The schedule is agreed before recording starts."},
        ],
        "related": ["editing", "publishing", "marketing"],
    },

    "author-website": {
        "name": "Author Website Design",
        "headline": "Author website design",
        "short": "Author website design: a fast, simple site with book pages, store links and a mailing list signup, registered in your name.",
        "icon": "layout",
        "blurb": (
            "An author website is the one place online that you control. It "
            "needs to do a few things very well: present you and your books, "
            "link to every store, and give readers a reason to leave their email."
        ),
        "problem": (
            "Social platforms change their rules and store pages belong to the "
            "store. A website of your own is where readers, journalists and "
            "booksellers can always find you, and where your mailing list lives."
        ),
        "deliverables": [
            "A responsive website with home, about, books and contact pages",
            "A page for each book with store links, description, sample and reviews you supply",
            "A mailing list signup connected to the email service you choose",
            "Basic search engine setup: titles, descriptions, sitemap and clean addresses",
            "A short training session so you can update the site yourself",
        ],
        "process": [
            {"step": "Plan", "text": "We agree the pages, the content you will supply and the domain name."},
            {"step": "Design", "text": "You see a design matched to your books and brand before anything is built."},
            {"step": "Build", "text": "The site is built, tested on phones and desktops, and connected to your domain."},
            {"step": "Content", "text": "Your text, images and store links go in, and your mailing list signup is tested."},
            {"step": "Launch and handover", "text": "The site goes live on your own hosting and domain, with the login details handed to you."},
        ],
        "inputs": [
            "Your author photo, bio and book covers",
            "Store links for each book",
            "A domain name, or we help you register one in your name",
            "Your choice of mailing list service, or we recommend one",
        ],
        "ownership": (
            "The domain, hosting and site are registered in your name and remain "
            "yours. You receive all logins at handover and can move the site "
            "anywhere later."
        ),
        "faqs": [
            {"q": "Which platform is the site built on?", "a": "We choose a platform you can maintain yourself without a developer, and we explain the ongoing hosting cost before we start."},
            {"q": "Can I update the site myself?", "a": "Yes. That is part of the point. We include a training session and short written notes."},
            {"q": "Do you provide ongoing maintenance?", "a": "Optional. We can quote a small monthly fee for updates and backups, or hand the site over completely."},
        ],
        "related": ["marketing", "publishing", "cover-design"],
    },
}
