# Books A Nation website: v11 and v12 handover (3 November 2026)

Live site: https://booksanation.com (auto-deploys from the public GitHub repo within a few minutes of a new VERSION).

## What changed in v11

### New public pages (21)
- /portfolio/ with accessible filters (All, Studio concepts, Client covers, and genres) plus 12 studio concept detail pages:
  /portfolio/midnight-harbour/, the-ember-crown, momo-the-brave-little-fox, deep-focus, the-salt-garden,
  the-baker-of-rue-clement, the-lighthouse-letters, static, tiger-in-the-teacup, salt-and-smoke, the-long-game, speak-easy
- /resources/ with 5 original guides:
  self-publishing-checklist-first-time-authors, editing-levels-explained, how-to-write-a-book-cover-brief,
  print-and-ebook-formatting-checklist, isbn-metadata-and-publishing-files
- /cookie-policy/ (accurate to the actual implementation: essential cookies only, no banner needed)
- /publishing-standards/ (author ownership, rights and royalties, scope and revisions, platform independence, portfolio permission, handoff)

### Reviewable drafts (noindex, unlinked, not in the sitemap)
- /drafts/services/ghostwriting/
- /drafts/services/audiobook/
- /drafts/services/author-website/
- /drafts/refund-and-cancellation/
Each draft shows the exact questions that must be answered before it goes live. To publish a service draft, set draft to False in core/services_content.py (it then appears at /services/<slug>/, in the services grid, the contact dropdown and the sitemap).

### Existing pages improved
- All 5 service pages now have: the author's problem, deliverables, a numbered process, required inputs, ownership and handoff, FAQs (with FAQ schema), Service schema, related services and related guides. The editing page explains developmental, line, copy editing and proofreading side by side.
- Platform guides link to the relevant resources.
- Contact page and footer show the toll free number 1 (866) 324-2109 (tel:+18663242109), and will show the address and social profiles as soon as they are configured.
- Navigation: Services, Portfolio, The Studio, Platforms, Resources, About, Authors, Contact. Footer Company column lists Portfolio, Author resources, Publishing standards. Footer bottom links to Cookie Policy.
- Structured data: Organization (with logo, telephone, sameAs), WebSite, BreadcrumbList on every page, Service on service pages, FAQPage on service, FAQ and resource pages, Article on resources. No Review or AggregateRating schema.
- Mobile: footer keeps clear of the floating Call and Live chat buttons.

### Files added or changed
core/services_content.py (new), core/resources.py (new), core/portfolio.py (new), core/data.py, core/views.py, core/urls.py,
core/sitemaps.py, core/context_processors.py, config/settings.py, .env.example,
templates/base.html, templates/core/service_detail.html, portfolio.html (new), portfolio_detail.html (new), resources.html (new),
resource_detail.html (new), cookie_policy.html (new), publishing_standards.html (new), refund_policy_draft.html (new),
_social_icon.html (new), contact.html, platform_detail.html, static/core/css/main.css.

## Verified public page count
44 public pages return 200 and are in the sitemap (23 before, 21 new). 4 drafts return 200 with noindex and are excluded.

## Checks that passed (local build, then live)
- Every public route 200; unknown slugs and draft slugs on public paths return 404.
- Unique titles, one H1 per page, canonical equals the page URL, descriptions 150 to 165 characters.
- Internal link crawl from the home page reaches all 44 pages; no broken links; every referenced static asset loads.
- JSON-LD on every page parses; drafts carry noindex meta and X-Robots-Tag.
- Portfolio filters work with mouse and keyboard, update aria-pressed and a live status line, and are reflected in the URL hash.
- Reduced motion: content is visible with no reveal animation.
- Contact form validation, author story form (with photo resize), live chat panel open all work.
- Desktop and mobile layouts checked by screenshot, including the mobile navigation drawer.

## Reported separately: message delivery
The contact form, quote popup and author story form store every submission in the database and are visible in the admin panel.
Email notifications to support@booksanation.com go out only if SMTP is configured on the server in /srv/booksanation/.env:
EMAIL_HOST=smtp.titan.email, EMAIL_PORT=587, EMAIL_USE_TLS=true, EMAIL_HOST_USER=support@booksanation.com, EMAIL_HOST_PASSWORD=<your mailbox password>.
The password must be entered by the owner; it is never typed by the assistant. No test messages were sent to real customers.

## Business information still needed from the owner
1. Confirmation that ghostwriting, audiobook production and author website design are offered, plus the answers listed on each draft page.
2. Refund and cancellation decisions (deposit, cancellation terms, third-party costs, refund timing, governing law).
3. Business address, if it should be shown (CONTACT_ADDRESS in .env, lines separated by " | ").
4. Official social profile URLs (SOCIAL_FACEBOOK, SOCIAL_INSTAGRAM, SOCIAL_LINKEDIN, SOCIAL_X, SOCIAL_YOUTUBE, SOCIAL_TIKTOK in .env). Nothing is shown until set.
5. For each client cover in the portfolio: title, author credit, written permission, what Books A Nation did, whether it handled publishing. Only then does a client cover get a detail page.
6. Real author testimonials through the Share your story form (approve in admin), and an admin superuser login so they can be approved.
7. Titan mailbox password in the server .env for email notifications.

## v12 (same day, after owner approval)
- Ghostwriting, Audiobook Production and Author Website Design are now PUBLIC at /services/ghostwriting/, /services/audiobook/ and /services/author-website/ (approved by the owner). Keyword-focused H1s and titles on all 8 service pages. Contact form dropdown and footer list the new services.
- Refund and Cancellation Policy is PUBLIC at /refund-and-cancellation/ (principles only: full refund before work starts less third-party costs, completed stages retained, unused prepaid fees refunded, refunds to the original payment method). No invented percentages or day counts.
- Search and AI visibility: robots meta (max-snippet:-1, max-image-preview:large), Open Graph and Twitter card image (static/core/img/brand/og-card.jpg), Organization schema with contactPoint, areaServed and knowsAbout, /llms.txt summary for AI assistants, robots.txt disallows /admin/, /api/ and /drafts/.
- Public page count: 48, all in the sitemap.

## v13 and v14: search engine setup (3 November 2026)
- Google Search Console: property https://booksanation.com/ verified (HTML file method, served by Django at /google1d2ec52342b3c51d.html; keep it, removing it loses verification). Verified under bookpublishersink-02@explendidstudios.com.
- Sitemap https://booksanation.com/sitemap.xml submitted: status Success, 48 pages discovered.
- Indexing requested (URL Inspection) for 9 pages: home, /services/, /services/ghostwriting/, /services/audiobook/, /services/author-website/, /portfolio/, /resources/, the self-publishing checklist and the editing levels guide. Google's daily limit was reached; the other pages are picked up from the sitemap.
- IndexNow: key served at /2801e0d633fa96015c0c6f8ef5b267d7.txt; all 48 URLs submitted (Bing, Yandex, Seznam, Naver and other IndexNow engines).
- Bing Webmaster Tools is not set up: it needs the owner to sign in with a Microsoft or Google account (use "Import from Google Search Console" for a one-click setup).
- Nothing here guarantees rankings, indexing speed or AI Overview placement; these steps make the site fully discoverable and readable by Google, Bing and AI assistants.
