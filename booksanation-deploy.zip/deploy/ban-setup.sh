#!/usr/bin/env bash
# Books A Nation: one-time setup of the mailbox and admin passwords.
# Installed as /usr/local/bin/ban-setup by deploy/server_tune.sh.
# The owner runs:  sudo ban-setup   and answers four short questions.
# Passwords are typed hidden and go only into /srv/booksanation/.env.
set -u
[ "$(id -u)" = "0" ] || exec sudo bash "$0" "$@"
APP=/srv/booksanation
ENV="$APP/.env"
[ -d "$APP" ] || { echo "ban-setup: $APP not found"; exit 1; }
touch "$ENV"

echo
echo "Books A Nation setup. Type each answer and press Enter. Passwords stay hidden while typing."
echo
read -rp "1/4  Mailbox address [support@booksanation.com]: " MAIL
MAIL=${MAIL:-support@booksanation.com}
while :; do
  read -rsp "2/4  Password for $MAIL: " P2; echo
  [ -n "$P2" ] && break
  echo "     Nothing typed, try again."
done
read -rp "3/4  Admin username [sheldon]: " U
U=${U:-sheldon}
while :; do
  read -rsp "4/4  Admin password (at least 10 characters): " P1; echo
  [ ${#P1} -ge 10 ] && break
  echo "     Too short, try again."
done

# replace any old values, then append the new ones
sed -i '/^\(EMAIL_HOST_USER\|EMAIL_HOST_PASSWORD\|DJANGO_SUPERUSER_USERNAME\|DJANGO_SUPERUSER_PASSWORD\|DJANGO_SUPERUSER_EMAIL\)=/d' "$ENV"
printf '\nEMAIL_HOST_USER=%s\nEMAIL_HOST_PASSWORD=%s\nDJANGO_SUPERUSER_USERNAME=%s\nDJANGO_SUPERUSER_PASSWORD=%s\nDJANGO_SUPERUSER_EMAIL=%s\n' \
  "$MAIL" "$P2" "$U" "$P1" "$MAIL" >> "$ENV"
chmod 600 "$ENV"
chown www-data:www-data "$ENV" 2>/dev/null || true

echo
echo "Saving and restarting the site..."
systemctl restart booksanation
cd "$APP" || exit 1
./venv/bin/python manage.py ensure_admin 2>&1 | tail -1
./venv/bin/python manage.py notify_leads 2>&1 | tail -2
echo
echo "Done."
echo "  Admin panel: https://booksanation.com/admin/  (username: $U)"
echo "  Lead emails go to $MAIL. If a line above says 'still waiting', the mailbox password was not accepted: run  sudo ban-setup  again."
