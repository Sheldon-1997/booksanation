#!/usr/bin/env bash
# Books A Nation hourly maintenance (installed as ban-maintain.timer by server_tune.sh).
# 1. Create or update the admin sign-in from DJANGO_SUPERUSER_* in .env.
# 2. Re-send lead notification emails that did not go out.
# 3. Once a day: back up the database and uploaded files to /srv/backups (14 days kept).
set -u
APP=/srv/booksanation
BACKUPS=/srv/backups
LOG=/srv/ban-maintain.log
cd "$APP" || exit 0
exec >> "$LOG" 2>&1
echo "$(date '+%F %T') maintain start"

./venv/bin/python manage.py ensure_admin 2>&1 | tail -1
./venv/bin/python manage.py notify_leads 2>&1 | tail -1

TODAY=$(date +%F)
mkdir -p "$BACKUPS" && chmod 700 "$BACKUPS"
if [ ! -s "$BACKUPS/db-$TODAY.sql.gz" ]; then
  DBNAME=$(grep -E '^(POSTGRES_DB|DB_NAME)=' .env 2>/dev/null | head -1 | cut -d= -f2- | tr -d '"' )
  [ -n "$DBNAME" ] || DBNAME=booksanation
  if command -v pg_dump >/dev/null 2>&1 && su postgres -c "psql -lqt" 2>/dev/null | cut -d'|' -f1 | grep -qw "$DBNAME"; then
    su postgres -c "pg_dump --no-owner '$DBNAME'" | gzip > "$BACKUPS/db-$TODAY.sql.gz.part" \
      && mv "$BACKUPS/db-$TODAY.sql.gz.part" "$BACKUPS/db-$TODAY.sql.gz" \
      && echo "backup: database saved ($(du -h "$BACKUPS/db-$TODAY.sql.gz" | cut -f1))"
  elif [ -f db.sqlite3 ]; then
    gzip -c db.sqlite3 > "$BACKUPS/db-$TODAY.sql.gz" && echo "backup: sqlite saved"
  else
    echo "backup: no database found"
  fi
  [ -d media ] && tar -czf "$BACKUPS/media-$TODAY.tar.gz" media 2>/dev/null && echo "backup: media saved"
  find "$BACKUPS" -type f -mtime +14 -delete
fi
# keep the log small
tail -n 500 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
echo "$(date '+%F %T') maintain done"
