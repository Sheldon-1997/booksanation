#!/usr/bin/env bash
# Books A Nation: one-time server performance tune. Safe to run repeatedly.
# 1. Compress CSS, JS, SVG, JSON and text with gzip (nginx only compressed HTML before).
# 2. Teach the auto-updater to run deploy/post_update.sh after each update, so future
#    server tweaks ship with the code instead of needing the console.
# Every nginx change is checked with `nginx -t` and rolled back if the check fails.
set -u
CONF=/etc/nginx/conf.d/booksanation-perf.conf
[ "$(id -u)" = "0" ] || { echo "server_tune: not root, skipping"; exit 0; }
[ -d /etc/nginx/conf.d ] || { echo "server_tune: no nginx, skipping"; exit 0; }

cat > "$CONF.new" <<'NGX'
# Added by Books A Nation server_tune.sh: compress text assets.
gzip_vary on;
gzip_proxied any;
gzip_comp_level 6;
gzip_min_length 512;
gzip_types text/plain text/css text/xml text/javascript application/javascript application/json application/ld+json application/xml image/svg+xml;
NGX
[ -f "$CONF" ] && cp "$CONF" "$CONF.bak"
mv "$CONF.new" "$CONF"
if nginx -t >/dev/null 2>&1; then
  systemctl reload nginx && echo "server_tune: gzip enabled"
else
  echo "server_tune: nginx -t failed, rolling back"
  if [ -f "$CONF.bak" ]; then mv "$CONF.bak" "$CONF"; else rm -f "$CONF"; fi
  nginx -t >/dev/null 2>&1 && systemctl reload nginx
fi

UPD=/usr/local/bin/ban-update.sh
if [ -f "$UPD" ] && ! grep -q "post_update.sh" "$UPD"; then
  awk '{print} /manage.py collectstatic --noinput/ {print "[ -f deploy/post_update.sh ] && bash deploy/post_update.sh || true"}' "$UPD" > "$UPD.new"
  if bash -n "$UPD.new" && grep -q "post_update.sh" "$UPD.new"; then
    chmod +x "$UPD.new" && mv "$UPD.new" "$UPD" && echo "server_tune: updater now runs deploy/post_update.sh"
  else
    rm -f "$UPD.new"; echo "server_tune: updater left unchanged"
  fi
fi
exit 0
