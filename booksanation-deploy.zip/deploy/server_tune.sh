#!/usr/bin/env bash
# Books A Nation: one-time server performance tune. Safe to run repeatedly.
# 1. Compress CSS, JS, SVG, JSON and text with gzip (nginx only compressed HTML before).
# 2. Teach the auto-updater to run deploy/post_update.sh after each update, so future
#    server tweaks ship with the code instead of needing the console.
# 4. Hourly maintenance timer (admin from .env, lead email retry, daily backups).
# 5. Graceful gunicorn reload so updates do not drop visitors.
# Every nginx change is checked with `nginx -t` and rolled back if the check fails.
set -u
CONF=/etc/nginx/conf.d/booksanation-perf.conf
[ "$(id -u)" = "0" ] || { echo "server_tune: not root, skipping"; exit 0; }
[ -d /etc/nginx/conf.d ] || { echo "server_tune: no nginx, skipping"; exit 0; }

cat > "$CONF.new" <<'NGX'
# Added by Books A Nation server_tune.sh: compress text assets.
gzip_vary on;
gzip_proxied any;
gzip_comp_level 6;
gzip_min_length 512;
gzip_types text/plain text/css text/xml text/javascript application/javascript application/json application/ld+json application/xml image/svg+xml;
NGX
[ -f "$CONF" ] && cp "$CONF" "$CONF.bak"
mv "$CONF.new" "$CONF"
if nginx -t >/dev/null 2>&1; then
  systemctl reload nginx && echo "server_tune: gzip enabled"
else
  echo "server_tune: nginx -t failed, rolling back"
  if [ -f "$CONF.bak" ]; then mv "$CONF.bak" "$CONF"; else rm -f "$CONF"; fi
  nginx -t >/dev/null 2>&1 && systemctl reload nginx
fi

UPD=/usr/local/bin/ban-update.sh
# 3. Safer updater (v2): copy new images, CSS and JS into place BEFORE the new pages
#    go live, and reload nginx instead of restarting it, so a visitor loading a page
#    during an update never sees broken images. Only replaces the known updater.
if [ -f "$UPD" ] && ! grep -q "ban-update.log" "$UPD" \
   && grep -q "python3 -m zipfile -e booksanation-deploy.zip booksanation" "$UPD" \
   && grep -q "manage.py collectstatic --noinput" "$UPD" \
   && grep -q "systemctl restart booksanation" "$UPD"; then
  RAWLINE=$(grep -m1 '^RAW=' "$UPD")
  [ -n "$RAWLINE" ] || RAWLINE='RAW="https://raw.githubusercontent.com/sheldon-1997/booksanation/main"'
  {
    echo '#!/usr/bin/env bash'
    echo '# Books A Nation auto-updater v2 (installed by deploy/server_tune.sh)'
    echo 'set -e'
    echo "$RAWLINE"
    cat <<'UPDV2'
cd /srv
NEW=$(wget -q -O- "$RAW/VERSION" 2>/dev/null || echo "")
OLD=$(cat /srv/.ban-version 2>/dev/null || echo "none")
[ -z "$NEW" ] && exit 0
[ "$NEW" = "$OLD" ] && exit 0
exec >> /srv/ban-update.log 2>&1
echo "$(date) updating $OLD -> $NEW"
wget -q -O booksanation-deploy.zip "$RAW/booksanation-deploy.zip"
# 1. New static files first (additive), so new pages never point at a missing file.
python3 - <<'PY' || true
import zipfile
z = zipfile.ZipFile("/srv/booksanation-deploy.zip")
z.extractall("/srv/booksanation", [m for m in z.namelist() if m.startswith("static/")])
PY
(cd booksanation && ./venv/bin/python manage.py collectstatic --noinput >/dev/null 2>&1) || true
# 2. Then the code.
python3 -m zipfile -e booksanation-deploy.zip booksanation
cd booksanation
./venv/bin/pip install -q -r requirements.txt || true
./venv/bin/python manage.py migrate --noinput || echo "MIGRATE FAILED for $NEW, check above"
./venv/bin/python manage.py collectstatic --noinput
[ -f deploy/post_update.sh ] && bash deploy/post_update.sh || true
chown -R www-data:www-data /srv/booksanation
# graceful: gunicorn swaps workers one by one; falls back to a restart
systemctl reload booksanation 2>/dev/null || systemctl restart booksanation
# reload keeps visitors' open connections (restart cut off images mid-load)
systemctl reload nginx || systemctl restart nginx
echo "$NEW" > /srv/.ban-version
echo "$(date) updated to $NEW"
UPDV2
  } > "$UPD.new"
  if bash -n "$UPD.new" && grep -q "auto-updater v2" "$UPD.new" && grep -q "post_update.sh" "$UPD.new" && grep -q "ban-update.log" "$UPD.new"; then
    chmod +x "$UPD.new" && cp "$UPD" "$UPD.prev.bak" && mv "$UPD.new" "$UPD" && echo "server_tune: updater upgraded to v2"
  else
    rm -f "$UPD.new"; echo "server_tune: updater v2 check failed, left unchanged"
  fi
elif [ -f "$UPD" ] && ! grep -q "post_update.sh" "$UPD"; then
  awk '{print} /manage.py collectstatic --noinput/ {print "[ -f deploy/post_update.sh ] && bash deploy/post_update.sh || true"}' "$UPD" > "$UPD.new"
  if bash -n "$UPD.new" && grep -q "post_update.sh" "$UPD.new"; then
    chmod +x "$UPD.new" && mv "$UPD.new" "$UPD" && echo "server_tune: updater now runs deploy/post_update.sh"
  else
    rm -f "$UPD.new"; echo "server_tune: updater left unchanged"
  fi
fi
# 4. Hourly maintenance timer
APPDIR=$(cd "$(dirname "$0")/.." && pwd)
if [ -f "$APPDIR/deploy/maintain.sh" ] && [ -d /etc/systemd/system ]; then
  cat > /etc/systemd/system/ban-maintain.service <<'UNIT'
[Unit]
Description=Books A Nation maintenance (admin from .env, lead email retry, daily backup)
After=network-online.target postgresql.service
[Service]
Type=oneshot
ExecStart=/bin/bash /srv/booksanation/deploy/maintain.sh
UNIT
  cat > /etc/systemd/system/ban-maintain.timer <<'UNIT'
[Unit]
Description=Books A Nation maintenance every hour
[Timer]
OnBootSec=5min
OnUnitActiveSec=1h
[Install]
WantedBy=timers.target
UNIT
  systemctl daemon-reload
  systemctl enable --now ban-maintain.timer >/dev/null 2>&1 && echo "server_tune: maintenance timer active"
  # first run right away so the admin account and backup exist today
  systemctl start ban-maintain.service >/dev/null 2>&1 || true
fi

# 6. Owner's one-time password setup command: sudo ban-setup
[ -f "$APPDIR/deploy/ban-setup.sh" ] && install -m 755 "$APPDIR/deploy/ban-setup.sh" /usr/local/bin/ban-setup && echo "server_tune: ban-setup installed"

# 5. Graceful reload for gunicorn (HUP swaps workers without dropping requests)
if [ -f /etc/systemd/system/booksanation.service ] && ! grep -q "ExecReload" /etc/systemd/system/booksanation.service \
   && [ ! -f /etc/systemd/system/booksanation.service.d/reload.conf ]; then
  mkdir -p /etc/systemd/system/booksanation.service.d
  printf '[Service]\nExecReload=/bin/kill -s HUP $MAINPID\n' > /etc/systemd/system/booksanation.service.d/reload.conf
  systemctl daemon-reload && echo "server_tune: gunicorn graceful reload enabled"
fi
exit 0
