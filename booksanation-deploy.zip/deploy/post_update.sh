#!/usr/bin/env bash
# Runs as root after every auto-update (once server_tune.sh has upgraded the updater).
# Keep it idempotent and quick. Re-applies the nginx performance settings.
cd "$(dirname "$0")/.." || exit 0
bash deploy/server_tune.sh || true
