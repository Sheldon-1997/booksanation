#!/usr/bin/env bash
# Books A Nation - one-shot VPS setup for booksanation.com
# Target: Ubuntu 24.04 (GoDaddy VPS, shared with Publishing Core).
# Safe to re-run. Creates ONLY booksanation-specific files:
#   /srv/booksanation            app code + venv
#   /etc/systemd/system/booksanation.service
#   /etc/nginx/sites-available/booksanation
# Does NOT touch any existing site, service, or nginx config.
set -euo pipefail

DOMAIN="booksanation.com"
APP_DIR="/srv/booksanation"
REPO_URL="${REPO_URL:-https://github.com/Sheldon-1997/booksanation.git}"
DB_NAME="booksanation"
DB_USER="booksanation"

echo "== [1/9] System packages =="
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y python3-venv python3-pip postgresql postgresql-contrib nginx git certbot python3-certbot-nginx

echo "== [2/9] Code =="
if [ -d "$APP_DIR/.git" ]; then
  git -C "$APP_DIR" pull --ff-only
elif [ -d "$APP_DIR/manage.py" ] || [ -f "$APP_DIR/manage.py" ]; then
  echo "Code already present at $APP_DIR (no git). Leaving as is."
else
  git clone "$REPO_URL" "$APP_DIR"
fi
cd "$APP_DIR"

echo "== [3/9] Python venv =="
if [ ! -d venv ]; then python3 -m venv venv; fi
./venv/bin/pip install --upgrade pip wheel >/dev/null
./venv/bin/pip install -r requirements.txt
./venv/bin/pip install gunicorn psycopg2-binary

echo "== [4/9] PostgreSQL =="
DB_PASS_FILE="/root/.booksanation_db_pass"
if [ ! -f "$DB_PASS_FILE" ]; then
  openssl rand -hex 24 > "$DB_PASS_FILE"; chmod 600 "$DB_PASS_FILE"
fi
DB_PASS="$(cat "$DB_PASS_FILE")"
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1 || \
  sudo -u postgres psql -c "CREATE ROLE $DB_USER LOGIN PASSWORD '$DB_PASS';"
sudo -u postgres psql -c "ALTER ROLE $DB_USER WITH PASSWORD '$DB_PASS';"
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1 || \
  sudo -u postgres createdb -O "$DB_USER" "$DB_NAME"

echo "== [5/9] .env =="
if [ ! -f .env ]; then
  SECRET_KEY="$(./venv/bin/python -c 'from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())')"
  cat > .env <<EOF
DJANGO_DEBUG=0
DJANGO_SECRET_KEY=$SECRET_KEY
DJANGO_ALLOWED_HOSTS=$DOMAIN,www.$DOMAIN,160.153.175.65
DJANGO_CSRF_TRUSTED_ORIGINS=https://$DOMAIN,https://www.$DOMAIN
POSTGRES_DB=$DB_NAME
POSTGRES_USER=$DB_USER
POSTGRES_PASSWORD=$DB_PASS
POSTGRES_HOST=127.0.0.1
POSTGRES_PORT=5432
# Email (fill when Titan mailbox is ready)
DJANGO_EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend
# EMAIL_HOST=smtp.titan.email
# EMAIL_HOST_USER=support@booksanation.com
# EMAIL_HOST_PASSWORD=
# EMAIL_PORT=587
# DEFAULT_FROM_EMAIL=Books A Nation <support@booksanation.com>
# CONTACT_PHONE=
EOF
  chmod 600 .env
else
  echo ".env exists, leaving as is."
fi

echo "== [6/9] Django migrate + collectstatic =="
./venv/bin/python manage.py migrate --noinput
./venv/bin/python manage.py collectstatic --noinput
./venv/bin/python manage.py check --deploy || true

echo "== [7/9] Gunicorn systemd unit =="
cat > /etc/systemd/system/booksanation.service <<'EOF'
[Unit]
Description=Books A Nation (Gunicorn)
After=network.target postgresql.service

[Service]
WorkingDirectory=/srv/booksanation
ExecStart=/srv/booksanation/venv/bin/gunicorn config.wsgi:application \
  --bind unix:/run/booksanation.sock --workers 3 --timeout 60
Restart=always
RuntimeDirectory=booksanation
User=www-data
Group=www-data

[Install]
WantedBy=multi-user.target
EOF
chown -R www-data:www-data "$APP_DIR"
systemctl daemon-reload
systemctl enable --now booksanation
systemctl restart booksanation

echo "== [8/9] Nginx site =="
cat > /etc/nginx/sites-available/booksanation <<EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;

    client_max_body_size 20M;

    location /static/ {
        alias $APP_DIR/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    location /media/ {
        alias $APP_DIR/media/;
        expires 7d;
    }
    location / {
        proxy_pass http://unix:/run/booksanation.sock;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF
ln -sf /etc/nginx/sites-available/booksanation /etc/nginx/sites-enabled/booksanation
nginx -t
systemctl reload nginx

echo "== [9/9] Status =="
systemctl --no-pager --lines=5 status booksanation || true
curl -s -o /dev/null -w "Local HTTP check: %{http_code}\n" -H "Host: $DOMAIN" http://127.0.0.1/ || true

echo
echo "DONE. Next steps:"
echo "  1. Point DNS A record @ -> this server IP (160.153.175.65), keep www CNAME -> $DOMAIN"
echo "  2. After DNS resolves: certbot --nginx -d $DOMAIN -d www.$DOMAIN --redirect -m support@$DOMAIN --agree-tos --no-eff-email"
echo "  3. Create admin: cd $APP_DIR && sudo -u www-data ./venv/bin/python manage.py createsuperuser"
