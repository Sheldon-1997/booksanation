#!/usr/bin/env bash
# Publishing Core auto-updater (installed to /usr/local/bin/pc-update.sh, run by pc-update.timer as root).
# Transport: the public booksanation repo carries publishingcore/VERSION and publishingcore/pc-deploy.zip
# (the Publishing Core source repo is private, so the server cannot pull it directly).
# The zip holds code, templates and changed static files only; it is extracted over
# /srv/publishingcore/app, which keeps the ownership rules from deploy/README.md there
# (root:pcsite, dirs 750, files 640). Private runtime, database, venv and media are untouched.
set -u
RAW="https://raw.githubusercontent.com/sheldon-1997/booksanation/main/publishingcore"
APP=/srv/publishingcore/app
VENV=/srv/publishingcore/venv
LOG=/srv/pc-update.log
LOCK=/run/pc-update.lock
[ -d "$APP" ] || exit 0
exec 9>"$LOCK"; flock -n 9 || exit 0
NEW=$(wget -q -O- "$RAW/VERSION" 2>/dev/null | tr -d '[:space:]')
OLD=$(cat /srv/.pc-version 2>/dev/null || echo none)
[ -n "$NEW" ] || exit 0
[ "$NEW" = "$OLD" ] && exit 0
exec >> "$LOG" 2>&1
echo "$(date '+%F %T') pc-update: $OLD -> $NEW"
ZIP=/srv/pc-deploy.zip
STAGE=/srv/pc-stage
wget -q -O "$ZIP.part" "$RAW/pc-deploy.zip" && mv "$ZIP.part" "$ZIP" || { echo "download failed"; exit 1; }
rm -rf "$STAGE"; mkdir -p "$STAGE"
python3 -m zipfile -e "$ZIP" "$STAGE" || { echo "unzip failed"; exit 1; }
[ -f "$STAGE/manage.py" ] || { echo "zip has no manage.py, refusing"; exit 1; }
# Keep a copy of the previous code for a quick rollback.
rm -rf /srv/pc-previous && cp -a "$APP" /srv/pc-previous
# 1. New static files first, so pages never reference a file that is not there yet.
if [ -d "$STAGE/static" ]; then
  cp -a "$STAGE/static/." "$APP/static/"
  chown -R root:pcsite "$APP/static"
fi
# 2. Then the code.
cp -a "$STAGE/." "$APP/"
chown -R root:pcsite "$APP"
find "$APP" -type d -exec chmod 750 {} +
find "$APP" -type f -exec chmod 640 {} +
rm -rf "$STAGE"
cd "$APP" || exit 1
# 3. Dependencies, schema, static (as the app user, like deploy/README.md says).
sudo -u pcsite "$VENV/bin/python" -m pip install -q -r requirements-production.txt || echo "pip install reported a problem"
rollback() {
  echo "$1, restoring previous code"
  rm -rf "$APP" && mv /srv/pc-previous "$APP" && cd "$APP" || exit 1
  sudo -u pcsite bash deploy/manage-production.sh collectstatic --noinput >/dev/null
  systemctl restart publishingcore && echo "rollback ok"
  exit 1
}
sudo -u pcsite bash deploy/manage-production.sh migrate --noinput || echo "MIGRATE FAILED for $NEW (continuing; check above)"
sudo -u pcsite bash deploy/manage-production.sh collectstatic --noinput >/dev/null || rollback "COLLECTSTATIC FAILED for $NEW"
# 4. Nginx patches (cache rules for hashed files, CSP), checked with nginx -t and rolled back on failure.
SITE=/etc/nginx/sites-available/publishingcore
if [ -f deploy/patch-nginx.py ] && [ -f "$SITE" ]; then
  if python3 deploy/patch-nginx.py "$SITE"; then
    cp -a "$SITE" "$SITE.pc-backup"
    mv "$SITE.pc-new" "$SITE"
    if nginx -t >/dev/null 2>&1; then systemctl reload nginx && echo "nginx patched"; else mv "$SITE.pc-backup" "$SITE"; echo "nginx patch rejected by nginx -t, rolled back"; fi
  fi
fi
# 5. Restart the app (ExecStartPre runs Django's deployment check first).
if systemctl restart publishingcore; then
  echo "$NEW" > /srv/.pc-version
  echo "$(date '+%F %T') pc-update: now $NEW"
else
  rollback "RESTART FAILED for $NEW"
fi
tail -n 400 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
