#!/usr/bin/env bash
# Publishing Core auto-updater v2 (installed to /usr/local/bin/pc-update.sh, run by pc-update.timer as root).
# Transport: the PRIVATE source repo, read with a read-only SSH deploy key that the server generated itself
# (/etc/publishingcore/deploy-key; its public half is added under the repo's Settings > Deploy keys).
# Releases live in the repo at release/VERSION + release/pc-deploy.zip (built by scripts/build_deploy_zip.py).
# The zip holds code, templates and changed static files only; it is extracted over
# /srv/publishingcore/app, which keeps the ownership rules from deploy/README.md there
# (root:pcsite, dirs 750, files 640). Private runtime, database, venv and media are untouched.
set -u
REPO="git@github.com:Sheldon-1997/custom-django-website.git"
KEY=/etc/publishingcore/deploy-key
HOSTS=/etc/publishingcore/github-known-hosts
APP=/srv/publishingcore/app
VENV=/srv/publishingcore/venv
LOG=/srv/pc-update.log
LOCK=/run/pc-update.lock
SRC=/srv/pc-src
[ -d "$APP" ] || exit 0
[ -f "$KEY" ] || exit 0
exec 9>"$LOCK"; flock -n 9 || exit 0
export GIT_SSH_COMMAND="ssh -i $KEY -o IdentitiesOnly=yes -o BatchMode=yes -o UserKnownHostsFile=$HOSTS -o StrictHostKeyChecking=yes -o ConnectTimeout=20"
export GIT_TERMINAL_PROMPT=0
# 0. Cheap check: has the main branch moved since the last run?
HEAD=$(timeout 60 git ls-remote -q "$REPO" refs/heads/main 2>>"$LOG.ssh" | cut -c1-40)
[ -n "$HEAD" ] || exit 0  # key not added yet, or GitHub unreachable; the .ssh log says why
OLDHEAD=$(cat /srv/.pc-commit 2>/dev/null || echo none)
[ "$HEAD" = "$OLDHEAD" ] && exit 0
# 1. Fetch only release/ (partial, sparse clone: no 70 MB of cover artwork).
rm -rf "$SRC"
if ! timeout 300 git clone -q --depth 1 --filter=blob:none --sparse --branch main "$REPO" "$SRC" >>"$LOG.ssh" 2>&1 \
   || ! git -C "$SRC" sparse-checkout set release >>"$LOG.ssh" 2>&1; then
  echo "$(date '+%F %T') pc-update: clone failed (see $LOG.ssh)" >> "$LOG"; exit 1
fi
NEW=$(tr -d '[:space:]' < "$SRC/release/VERSION" 2>/dev/null)
OLD=$(cat /srv/.pc-version 2>/dev/null || echo none)
FAILED=$(cat /srv/.pc-failed 2>/dev/null || echo none)
if [ -z "$NEW" ] || [ "$NEW" = "$OLD" ] || [ "$NEW" = "$FAILED" ] || [ ! -f "$SRC/release/pc-deploy.zip" ]; then
  echo "$HEAD" > /srv/.pc-commit; rm -rf "$SRC"; exit 0  # source moved, no new (or an already failed) release
fi
exec >> "$LOG" 2>&1
echo "$(date '+%F %T') pc-update: $OLD -> $NEW (commit ${HEAD:0:10})"
ZIP=/srv/pc-deploy.zip
STAGE=/srv/pc-stage
cp "$SRC/release/pc-deploy.zip" "$ZIP"; rm -rf "$SRC"
rm -rf "$STAGE"; mkdir -p "$STAGE"
python3 -m zipfile -e "$ZIP" "$STAGE" || { echo "unzip failed"; exit 1; }
[ -f "$STAGE/manage.py" ] || { echo "zip has no manage.py, refusing"; exit 1; }
# Keep a copy of the previous code for a quick rollback.
rm -rf /srv/pc-previous && cp -a "$APP" /srv/pc-previous
# 2. New static files first, so pages never reference a file that is not there yet.
if [ -d "$STAGE/static" ]; then
  cp -a "$STAGE/static/." "$APP/static/"
  chown -R root:pcsite "$APP/static"
fi
# 3. Then the code.
cp -a "$STAGE/." "$APP/"
chown -R root:pcsite "$APP"
find "$APP" -type d -exec chmod 750 {} +
find "$APP" -type f -exec chmod 640 {} +
rm -rf "$STAGE"
cd "$APP" || exit 1
# 4. Dependencies, schema, static (as the app user, like deploy/README.md says).
sudo -u pcsite "$VENV/bin/python" -m pip install -q -r requirements-production.txt || echo "pip install reported a problem"
rollback() {
  echo "$1, restoring previous code"
  echo "$NEW" > /srv/.pc-failed  # do not retry this release every 3 minutes; the next version clears it
  rm -rf "$APP" && mv /srv/pc-previous "$APP" && cd "$APP" || exit 1
  sudo -u pcsite bash deploy/manage-production.sh collectstatic --noinput >/dev/null
  systemctl restart publishingcore && echo "rollback ok"
  exit 1
}
sudo -u pcsite bash deploy/manage-production.sh migrate --noinput || echo "MIGRATE FAILED for $NEW (continuing; check above)"
sudo -u pcsite bash deploy/manage-production.sh collectstatic --noinput >/dev/null || rollback "COLLECTSTATIC FAILED for $NEW"
# 5. Nginx patches (cache rules for hashed files, CSP), checked with nginx -t and rolled back on failure.
SITE=/etc/nginx/sites-available/publishingcore
if [ -f deploy/patch-nginx.py ] && [ -f "$SITE" ]; then
  if python3 deploy/patch-nginx.py "$SITE"; then
    cp -a "$SITE" "$SITE.pc-backup"
    mv "$SITE.pc-new" "$SITE"
    if nginx -t >/dev/null 2>&1; then systemctl reload nginx && echo "nginx patched"; else mv "$SITE.pc-backup" "$SITE"; echo "nginx patch rejected by nginx -t, rolled back"; fi
  fi
fi
# 6. Restart the app (ExecStartPre runs Django's deployment check first).
if systemctl restart publishingcore; then
  echo "$NEW" > /srv/.pc-version
  echo "$HEAD" > /srv/.pc-commit
  echo "$(date '+%F %T') pc-update: now $NEW"
else
  rollback "RESTART FAILED for $NEW"
fi
tail -n 400 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
