# Deploying booksanation.com (GoDaddy VPS)

Same pattern as Publishing Core: Ubuntu 24.04, Python 3.12, PostgreSQL 16,
Gunicorn behind Nginx, HTTPS via Let's Encrypt. All commands run on the VPS
as a sudo user.

## 1. System packages

```bash
sudo apt update && sudo apt install -y python3-venv python3-dev \
  postgresql postgresql-contrib nginx certbot python3-certbot-nginx git
```

## 2. Database

```bash
sudo -u postgres psql -c "CREATE USER booksanation WITH PASSWORD 'CHOOSE-A-PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE booksanation OWNER booksanation;"
```

## 3. Application

```bash
sudo mkdir -p /srv/booksanation && sudo chown $USER /srv/booksanation
cd /srv/booksanation
# copy the project here (git clone once the GitHub repo exists, or rsync/sftp)
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env && nano .env   # fill: secret key, DB password, Titan SMTP
python manage.py migrate
python manage.py collectstatic --noinput
python manage.py createsuperuser    # admin login for inquiries + live chat replies
```

Generate a secret key:
`python -c "import secrets; print(secrets.token_urlsafe(64))"`

## 4. Gunicorn (systemd)

`/etc/systemd/system/booksanation.service`:

```ini
[Unit]
Description=Books A Nation (Gunicorn)
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/srv/booksanation
Environment=PATH=/srv/booksanation/.venv/bin
ExecStart=/srv/booksanation/.venv/bin/gunicorn config.wsgi:application \
  --workers 3 --bind unix:/run/booksanation.sock
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo chown -R www-data:www-data /srv/booksanation
sudo systemctl enable --now booksanation
```

## 5. Nginx

`/etc/nginx/sites-available/booksanation.com`:

```nginx
server {
    listen 80;
    server_name booksanation.com www.booksanation.com;

    client_max_body_size 25M;

    location /static/ { alias /srv/booksanation/staticfiles/; expires 30d; }
    location /media/  { alias /srv/booksanation/media/; expires 30d; }

    location / {
        proxy_pass http://unix:/run/booksanation.sock;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/booksanation.com /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

## 6. DNS + HTTPS

1. GoDaddy DNS for booksanation.com: `A @ -> VPS IP`, `CNAME www -> @`.
2. After DNS propagates:
   `sudo certbot --nginx -d booksanation.com -d www.booksanation.com`
   (auto-renewal is installed by certbot.)

## 7. Titan email

In `.env`, set `EMAIL_HOST_USER=support@booksanation.com` and the Titan
password once the mailbox exists. Inquiry notifications then arrive at
support@booksanation.com. Form submissions are stored in the admin either
way, so nothing is lost before SMTP is configured.

## 8. After launch (SEO)

1. Google Search Console → add property booksanation.com (DNS verification
   through GoDaddy is easiest).
2. Submit `https://booksanation.com/sitemap.xml`.
3. Request indexing for the homepage and key pages.

## Live chat replies

Staff reply from `/admin/` → Chat sessions → open a session → add a message
with sender "Staff". The visitor's widget picks it up automatically while
they are on the site.

## Updating the site

```bash
cd /srv/booksanation && source .venv/bin/activate
# pull/copy new code, then:
python manage.py migrate && python manage.py collectstatic --noinput
sudo systemctl restart booksanation
```
