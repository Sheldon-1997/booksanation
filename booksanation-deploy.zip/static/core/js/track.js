/* Books A Nation: optional integrations (consent, CallRail, Microsoft Ads, Tawk.to).
   Loaded only when at least one service is switched on in the admin. */
(function () {
  "use strict";
  var T = window.BAN_TRACK || {};
  var states = window.BAN_CONSENT_STATES || {};

  /* ---------- Microsoft Ads UET ---------- */
  function loadUET() {
    if (!T.uet || window.__banUET) return;
    window.__banUET = true;
    (function (w, d, t, r, u) {
      var f, n, i;
      w[u] = w[u] || [];
      f = function () { var o = { ti: T.uet, enableAutoSpaTracking: true }; o.q = w[u]; w[u] = new UET(o); w[u].push("pageLoad"); };
      n = d.createElement(t); n.src = r; n.async = 1;
      n.onload = n.onreadystatechange = function () {
        var s = this.readyState;
        if (!s || s === "loaded" || s === "complete") { f(); n.onload = n.onreadystatechange = null; }
      };
      i = d.getElementsByTagName(t)[0]; i.parentNode.insertBefore(n, i);
    })(window, document, "script", "https://bat.bing.com/bat.js", "uetq");
  }

  function startMarketing() {
    if (window.banLoadCallRail) window.banLoadCallRail();
    loadUET();
  }

  /* ---------- Consent banner (Europe and on request) ---------- */
  var banner = document.getElementById("consent");
  function setConsent(value) {
    try { localStorage.setItem("ban-consent", value); } catch (e) {}
    window.BAN_CONSENT = value;
    if (typeof gtag === "function") gtag("consent", "update", value === "granted" ? states.on : states.off);
    if (window.uetq) window.uetq.push("consent", "update", { ad_storage: value === "granted" ? "granted" : "denied" });
    if (banner) banner.hidden = true;
    if (value === "granted") { startMarketing(); startTawkSoon(); }
  }
  if (banner) {
    banner.querySelector("[data-consent-yes]").addEventListener("click", function () { setConsent("granted"); });
    banner.querySelector("[data-consent-no]").addEventListener("click", function () { setConsent("denied"); });
    document.querySelectorAll("[data-cookie-settings]").forEach(function (el) {
      el.addEventListener("click", function (e) { e.preventDefault(); banner.hidden = false; });
    });
    if (window.BAN_CONSENT === "pending") banner.hidden = false;
  }
  if (window.BAN_CONSENT === "granted") loadUET();

  /* ---------- Tawk.to behind our own Live Agent button ---------- */
  if (!T.tawk) return;
  var Tawk = (window.Tawk_API = window.Tawk_API || {});
  window.Tawk_LoadStart = new Date();
  var requested = false, ready = false, wantOpen = false, fallbackTimer = null;

  function attrs() {
    var a = null;
    try { a = JSON.parse(localStorage.getItem("ban-attr") || sessionStorage.getItem("ban-attr") || "null"); } catch (e) {}
    if (!a) return;
    var out = {};
    ["gclid", "utm_source", "utm_medium", "utm_campaign", "utm_term", "landing"].forEach(function (k) {
      if (a[k]) out[k.replace(/_/g, "-")] = String(a[k]).slice(0, 250);
    });
    try { Tawk.setAttributes(out, function () {}); } catch (e) {}
  }
  function openNow() {
    clearTimeout(fallbackTimer);
    try { Tawk.showWidget(); Tawk.maximize(); } catch (e) {}
  }
  Tawk.onLoad = function () {
    ready = true;
    attrs();
    if (wantOpen) openNow(); else { try { Tawk.hideWidget(); } catch (e) {} }
  };
  Tawk.onChatMinimized = function () { wantOpen = false; try { Tawk.hideWidget(); } catch (e) {} };
  Tawk.onChatStarted = function () { if (window.banTrack) window.banTrack("chat_start", { chat_provider: "tawk" }); };
  Tawk.onChatMessageAgent = function () {
    var badge = document.querySelector("#chat-fab .chat-badge");
    var open = false;
    try { open = Tawk.isChatMaximized(); } catch (e) {}
    if (badge && !open) badge.classList.remove("hide");
  };

  function load() {
    if (requested) return;
    requested = true;
    var s = document.createElement("script");
    s.async = true;
    s.src = "https://embed.tawk.to/" + T.tawk;
    s.charset = "UTF-8";
    s.setAttribute("crossorigin", "*");
    document.head.appendChild(s);
  }

  /* Called by the Live Agent button. Falls back to the built in chat if Tawk.to cannot load. */
  window.banOpenLiveAgent = function () {
    wantOpen = true;
    if (ready) { openNow(); return; }
    load();
    clearTimeout(fallbackTimer);
    fallbackTimer = setTimeout(function () {
      if (!ready && window.banOpenBuiltInChat) { wantOpen = false; window.banOpenBuiltInChat(); }
    }, 8000);
  };

  /* Load quietly after the page has settled so the team can see visitors arrive. */
  var timerSet = false;
  function startTawkSoon() {
    if (timerSet || window.BAN_CONSENT !== "granted") return;
    timerSet = true;
    var go = function () { setTimeout(load, 2500); };
    var afterLoad = function () { document.readyState === "complete" ? go() : window.addEventListener("load", go, { once: true }); };
    if (document.prerendering) document.addEventListener("prerenderingchange", afterLoad, { once: true });
    else afterLoad();
  }
  startTawkSoon();
})();
