/* Books A Nation: cursor and page effects.
   Custom cursor with trailing ring and ember particles, magnetic buttons,
   and an orange page sweep between internal pages. Desktop pointer only,
   fully disabled for touch devices and reduced motion. No layout thrash:
   transforms and a single canvas, all on requestAnimationFrame. */

(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;

  /* ===================== Page veil (enter + exit sweep) ===================== */

  var veil = document.createElement("div");
  veil.id = "page-veil";
  document.body.appendChild(veil);

  if (!reduceMotion) {
    /* reveal on load */
    veil.classList.add("veil-cover");
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { veil.classList.add("veil-out"); });
    });
    veil.addEventListener("transitionend", function () {
      if (veil.classList.contains("veil-out")) veil.classList.remove("veil-cover", "veil-out");
    });
    window.addEventListener("pageshow", function (e) {
      if (e.persisted) veil.classList.remove("veil-cover", "veil-in", "veil-out");
    });

    /* sweep on internal navigation */
    document.addEventListener("click", function (e) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var a = e.target.closest ? e.target.closest("a[href]") : null;
      if (!a) return;
      if (a.hasAttribute("data-open-chat") || a.target === "_blank" || a.hasAttribute("download")) return;
      var href = a.getAttribute("href");
      if (!href || href.charAt(0) === "#" || href.indexOf("mailto:") === 0 || href.indexOf("tel:") === 0) return;
      var url = new URL(a.href, location.href);
      if (url.origin !== location.origin) return;
      if (url.pathname === location.pathname && url.hash) return;
      e.preventDefault();
      veil.classList.add("veil-in");
      setTimeout(function () { location.href = a.href; }, 300);
    });
  }

  if (!finePointer || reduceMotion) return;

  /* ===================== Custom cursor ===================== */

  document.documentElement.classList.add("fx-cursor");

  var dot = document.createElement("div");
  dot.id = "cursor-dot";
  var ring = document.createElement("div");
  ring.id = "cursor-ring";
  document.body.appendChild(ring);
  document.body.appendChild(dot);

  var trail = document.createElement("canvas");
  trail.id = "cursor-trail";
  document.body.appendChild(trail);
  var ctx = trail.getContext("2d");
  var TW = 0, TH = 0;
  function sizeTrail() {
    TW = trail.width = window.innerWidth;
    TH = trail.height = window.innerHeight;
  }
  sizeTrail();
  window.addEventListener("resize", sizeTrail);

  var mx = -100, my = -100;        /* actual pointer */
  var rx = -100, ry = -100;        /* lagging ring */
  var visible = false;
  var pressed = false;
  var hoverMode = false;

  var parts = [];
  var MAXP = 90;
  var lastSpawnX = 0, lastSpawnY = 0;

  function spawn(x, y, n) {
    for (var i = 0; i < n; i++) {
      if (parts.length >= MAXP) parts.shift();
      var a = Math.random() * Math.PI * 2;
      var sp = 0.2 + Math.random() * 0.7;
      parts.push({
        x: x + (Math.random() - 0.5) * 6,
        y: y + (Math.random() - 0.5) * 6,
        vx: Math.cos(a) * sp * 0.4,
        vy: Math.sin(a) * sp * 0.4 - 0.25,
        life: 1,
        decay: 0.02 + Math.random() * 0.025,
        r: 1 + Math.random() * 2.2,
        warm: Math.random() < 0.8
      });
    }
  }

  document.addEventListener("pointermove", function (e) {
    mx = e.clientX; my = e.clientY;
    if (!visible) { visible = true; rx = mx; ry = my; document.body.classList.add("cursor-on"); }
    var dx = mx - lastSpawnX, dy = my - lastSpawnY;
    if (dx * dx + dy * dy > 140) {
      spawn(mx, my, 2);
      lastSpawnX = mx; lastSpawnY = my;
    }
  }, { passive: true });

  document.addEventListener("pointerdown", function () {
    pressed = true;
    spawn(mx, my, 10);
  });
  document.addEventListener("pointerup", function () { pressed = false; });
  document.addEventListener("pointerleave", function () {
    visible = false;
    document.body.classList.remove("cursor-on");
  });

  /* hover states: links, buttons, covers, tiles */
  var HOVER_SEL = "a, button, .shelf-book, .tile, .picker-thumb, .stage-btn, summary, input, select, textarea";
  document.addEventListener("pointerover", function (e) {
    var t = e.target.closest ? e.target.closest(HOVER_SEL) : null;
    hoverMode = !!t && !(t.matches && t.matches("input, select, textarea"));
    var native = !!t && t.matches && t.matches("input, select, textarea");
    document.body.classList.toggle("cursor-hover", hoverMode);
    document.body.classList.toggle("cursor-native", native);
  }, { passive: true });

  /* magnetic buttons */
  var magnets = [];
  function collectMagnets() {
    magnets = Array.prototype.slice.call(document.querySelectorAll(".btn, .chat-fab, .shelf-nav"));
  }
  collectMagnets();

  document.addEventListener("pointermove", function (e) {
    for (var i = 0; i < magnets.length; i++) {
      var el = magnets[i];
      var r = el.getBoundingClientRect();
      if (r.width === 0) continue;
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      var dx = e.clientX - cx, dy = e.clientY - cy;
      var dist = Math.sqrt(dx * dx + dy * dy);
      var range = Math.max(r.width, r.height) * 0.9;
      if (dist < range) {
        var pull = (1 - dist / range) * 7;
        el.style.setProperty("--magx", (dx / dist || 0) * pull + "px");
        el.style.setProperty("--magy", (dy / dist || 0) * pull + "px");
        el.classList.add("magnet-on");
      } else if (el.classList.contains("magnet-on")) {
        el.classList.remove("magnet-on");
        el.style.setProperty("--magx", "0px");
        el.style.setProperty("--magy", "0px");
      }
    }
  }, { passive: true });

  /* ===================== rAF loop ===================== */

  var hidden = false;
  document.addEventListener("visibilitychange", function () { hidden = document.hidden; });

  (function loop() {
    requestAnimationFrame(loop);
    if (hidden) return;

    rx += (mx - rx) * 0.16;
    ry += (my - ry) * 0.16;

    dot.style.transform = "translate(" + (mx - 4) + "px," + (my - 4) + "px) scale(" + (pressed ? 0.6 : 1) + ")";
    var rs = hoverMode ? 1.7 : (pressed ? 0.8 : 1);
    ring.style.transform = "translate(" + (rx - 19) + "px," + (ry - 19) + "px) scale(" + rs + ")";

    ctx.clearRect(0, 0, TW, TH);
    for (var i = parts.length - 1; i >= 0; i--) {
      var p = parts[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy -= 0.004;
      p.life -= p.decay;
      if (p.life <= 0) { parts.splice(i, 1); continue; }
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
      ctx.fillStyle = p.warm
        ? "rgba(240, 91, 36," + (0.5 * p.life) + ")"
        : "rgba(24, 22, 17," + (0.35 * p.life) + ")";
      ctx.fill();
    }
  })();
})();
