/* Books A Nation — Studio demo
   A single lightweight Three.js scene: manuscript → editing → cover → finished book.
   No shadows, capped DPR, one book mesh — built for zero lag. */

import * as THREE from "three";

const canvas = document.getElementById("studio-canvas");
if (canvas) init(canvas);

function init(canvas) {
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Renderer / scene / camera ---------- */
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();

  const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 60);
  camera.position.set(0, 1.1, 7.4);
  camera.lookAt(0, 0.1, 0);

  /* ---------- Lights (warm studio key + cool fill) ---------- */
  scene.add(new THREE.AmbientLight(0xf3e2c8, 0.55));
  const key = new THREE.DirectionalLight(0xffe9c4, 1.5);
  key.position.set(3.4, 4.2, 4.6);
  scene.add(key);
  const fill = new THREE.DirectionalLight(0x9db4d8, 0.35);
  fill.position.set(-4, 1.5, -2.5);
  scene.add(fill);
  const rim = new THREE.DirectionalLight(0xd4af63, 0.7);
  rim.position.set(-2.5, 3, -4);
  scene.add(rim);

  /* ---------- Ground glow (cheap contact shadow) ---------- */
  const groundTex = makeRadialTexture();
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(10, 10),
    new THREE.MeshBasicMaterial({ map: groundTex, transparent: true, depthWrite: false })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -1.62;
  scene.add(ground);

  /* ---------- Book dimensions (6x9-ish, in scene units) ---------- */
  const BW = 2.0, BH = 3.0, BD = 0.5;

  const bookGroup = new THREE.Group();
  scene.add(bookGroup);

  /* Pages block — canvas striation texture on the three paper edges */
  const pagesTex = makePagesTexture();
  const paperMat = new THREE.MeshStandardMaterial({ map: pagesTex, roughness: 0.9, metalness: 0 });
  const paperPlainMat = new THREE.MeshStandardMaterial({ color: 0xf1e8d4, roughness: 0.95 });
  const pages = new THREE.Mesh(
    new THREE.BoxGeometry(BW * 0.965, BH * 0.975, BD * 0.86),
    [paperMat, paperMat, paperMat, paperMat, paperPlainMat, paperPlainMat]
  );
  bookGroup.add(pages);

  /* Cover boards: front, back, spine — one group so it can fade in */
  const coverGroup = new THREE.Group();
  bookGroup.add(coverGroup);

  const boardT = 0.045;
  const texLoader = new THREE.TextureLoader();

  const coverMat = new THREE.MeshStandardMaterial({ roughness: 0.52, metalness: 0.04, transparent: true });
  const coverBackMat = new THREE.MeshStandardMaterial({ color: 0x3a2029, roughness: 0.6, transparent: true });
  const spineMat = new THREE.MeshStandardMaterial({ color: 0x2e1019, roughness: 0.55, transparent: true });
  const boardEdgeMat = new THREE.MeshStandardMaterial({ color: 0x241318, roughness: 0.7, transparent: true });

  const frontBoard = new THREE.Mesh(
    new THREE.BoxGeometry(BW, BH, boardT),
    [boardEdgeMat, boardEdgeMat, boardEdgeMat, boardEdgeMat, coverMat, boardEdgeMat]
  );
  frontBoard.position.z = BD / 2 - boardT / 2 + 0.028;
  coverGroup.add(frontBoard);

  const backBoard = new THREE.Mesh(
    new THREE.BoxGeometry(BW, BH, boardT),
    [boardEdgeMat, boardEdgeMat, boardEdgeMat, boardEdgeMat, boardEdgeMat, coverBackMat]
  );
  backBoard.position.z = -BD / 2 + boardT / 2 - 0.028;
  coverGroup.add(backBoard);

  const spine = new THREE.Mesh(
    new THREE.BoxGeometry(boardT, BH, BD + 0.056),
    [spineMat, boardEdgeMat, boardEdgeMat, boardEdgeMat, boardEdgeMat, boardEdgeMat]
  );
  spine.position.x = -BW / 2 - boardT / 2 + 0.002;
  coverGroup.add(spine);

  /* Title page + edit-marks overlays (manuscript/editing stages) */
  const titleTex = makeTitlePageTexture();
  const titlePage = new THREE.Mesh(
    new THREE.PlaneGeometry(BW * 0.94, BH * 0.95),
    new THREE.MeshBasicMaterial({ map: titleTex, transparent: true })
  );
  titlePage.position.z = BD * 0.43 + 0.012;
  bookGroup.add(titlePage);

  const editsTex = makeEditMarksTexture();
  const editsPage = new THREE.Mesh(
    new THREE.PlaneGeometry(BW * 0.94, BH * 0.95),
    new THREE.MeshBasicMaterial({ map: editsTex, transparent: true, opacity: 0 })
  );
  editsPage.position.z = BD * 0.43 + 0.016;
  bookGroup.add(editsPage);

  /* Loose manuscript sheets that float in stage 0/1 */
  const sheets = [];
  for (let i = 0; i < 3; i++) {
    const s = new THREE.Mesh(
      new THREE.PlaneGeometry(BW * 0.9, BH * 0.92),
      new THREE.MeshBasicMaterial({ map: makeSheetTexture(i), transparent: true, side: THREE.DoubleSide })
    );
    s.position.set(0, 0, BD * 0.5 + 0.1 + i * 0.1);
    s.rotation.z = (i - 1) * 0.045;
    sheets.push(s);
    bookGroup.add(s);
  }

  /* ---------- Cover texture loading ---------- */
  let currentCoverURL = null;
  function setCover(url) {
    if (url === currentCoverURL) return;
    currentCoverURL = url;
    texLoader.load(url, (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);
      coverMat.map = tex;
      coverMat.color = new THREE.Color(0xffffff);
      coverMat.needsUpdate = true;
      /* derive spine + back colors from the image's average tone */
      averageColor(tex.image).then(({ dark, darker }) => {
        spineMat.color = dark;
        coverBackMat.color = dark;
        boardEdgeMat.color = darker;
      });
    });
  }

  const firstThumb = document.querySelector(".picker-thumb");
  if (firstThumb) setCover(firstThumb.dataset.cover);

  document.querySelectorAll(".picker-thumb").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".picker-thumb").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      setCover(btn.dataset.cover);
      if (stage < 2) goStage(2);
    });
  });

  /* ---------- Stage system ---------- */
  /* targets: coverOpacity, titleOpacity, editsOpacity, sheetsOpacity, baseRotY, float */
  const STAGES = [
    { cover: 0, title: 1, edits: 0, sheets: 1, rotY: 0.0,  lift: 0 },     // manuscript
    { cover: 0, title: 1, edits: 1, sheets: 0.85, rotY: 0.06, lift: 0 }, // editing
    { cover: 1, title: 0, edits: 0, sheets: 0, rotY: -0.5, lift: 0 },    // cover design
    { cover: 1, title: 0, edits: 0, sheets: 0, rotY: -0.42, lift: 0.1 }, // finished
  ];

  let stage = 0;
  const cur = { cover: 0, title: 1, edits: 0, sheets: 1, rotY: 0, lift: 0 };

  const stageBtns = document.querySelectorAll(".stage-btn");
  function goStage(n) {
    stage = n;
    stageBtns.forEach((b, i) => {
      b.classList.toggle("active", i === n);
      b.setAttribute("aria-selected", i === n ? "true" : "false");
    });
  }
  stageBtns.forEach((b) => b.addEventListener("click", () => goStage(parseInt(b.dataset.stage, 10))));

  /* ---------- Drag to rotate ---------- */
  let dragging = false, dragX = 0, dragY = 0, userRotY = 0, userRotX = 0, velY = 0;

  canvas.addEventListener("pointerdown", (e) => {
    dragging = true;
    canvas.classList.add("dragging");
    dragX = e.clientX; dragY = e.clientY;
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!dragging) return;
    const dx = e.clientX - dragX, dy = e.clientY - dragY;
    dragX = e.clientX; dragY = e.clientY;
    userRotY += dx * 0.011;
    velY = dx * 0.011;
    userRotX = clamp(userRotX + dy * 0.006, -0.5, 0.5);
  });
  function endDrag() { dragging = false; canvas.classList.remove("dragging"); }
  canvas.addEventListener("pointerup", endDrag);
  canvas.addEventListener("pointercancel", endDrag);

  /* ---------- Resize ---------- */
  function resize() {
    const r = canvas.parentElement.getBoundingClientRect();
    renderer.setSize(r.width, r.height, false);
    camera.aspect = r.width / r.height;
    camera.updateProjectionMatrix();
  }
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(canvas.parentElement);

  /* ---------- Animation loop ---------- */
  const clock = new THREE.Clock();
  let visible = true;
  const vio = new IntersectionObserver((en) => { visible = en[0].isIntersecting; }, { threshold: 0 });
  vio.observe(canvas);

  function tick() {
    requestAnimationFrame(tick);
    if (!visible) return;

    const t = clock.getElapsedTime();
    const target = STAGES[stage];
    const k = reduceMotion ? 1 : 0.06;

    cur.cover += (target.cover - cur.cover) * k;
    cur.title += (target.title - cur.title) * k;
    cur.edits += (target.edits - cur.edits) * k;
    cur.sheets += (target.sheets - cur.sheets) * k;
    cur.rotY += (target.rotY - cur.rotY) * k;
    cur.lift += (target.lift - cur.lift) * k;

    coverMat.opacity = cur.cover;
    coverBackMat.opacity = cur.cover;
    spineMat.opacity = cur.cover;
    boardEdgeMat.opacity = cur.cover;
    coverGroup.visible = cur.cover > 0.02;

    titlePage.material.opacity = cur.title * (1 - cur.cover);
    editsPage.material.opacity = cur.edits * (1 - cur.cover);
    titlePage.visible = titlePage.material.opacity > 0.02;
    editsPage.visible = editsPage.material.opacity > 0.02;

    sheets.forEach((s, i) => {
      s.material.opacity = cur.sheets * 0.92;
      s.visible = s.material.opacity > 0.02;
      if (!reduceMotion) {
        s.position.y = Math.sin(t * 0.9 + i * 1.7) * 0.05 * cur.sheets;
        s.position.z = BD * 0.5 + 0.1 + i * 0.1 + Math.sin(t * 0.7 + i) * 0.02 * cur.sheets;
      }
    });

    if (!dragging) {
      userRotY += velY;
      velY *= 0.95;
      userRotX *= 0.97;
      if (stage === 3 && !reduceMotion) userRotY += 0.0022; /* slow turntable when finished */
    }

    bookGroup.rotation.y = cur.rotY + userRotY;
    bookGroup.rotation.x = userRotX * 0.6;
    const floatY = reduceMotion ? 0 : Math.sin(t * 1.1) * 0.045;
    bookGroup.position.y = cur.lift + floatY;

    renderer.render(scene, camera);
  }
  tick();

  /* ---------- Texture helpers (all generated — no fabricated client content) ---------- */

  function makeRadialTexture() {
    const c = document.createElement("canvas");
    c.width = c.height = 256;
    const g = c.getContext("2d");
    const grad = g.createRadialGradient(128, 128, 10, 128, 128, 128);
    grad.addColorStop(0, "rgba(0,0,0,0.45)");
    grad.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = grad;
    g.fillRect(0, 0, 256, 256);
    const tex = new THREE.CanvasTexture(c);
    return tex;
  }

  function makePagesTexture() {
    const c = document.createElement("canvas");
    c.width = 64; c.height = 256;
    const g = c.getContext("2d");
    g.fillStyle = "#f1e8d4";
    g.fillRect(0, 0, 64, 256);
    for (let y = 0; y < 256; y += 2) {
      g.fillStyle = Math.random() > 0.5 ? "#e4d8bf" : "#ece1cb";
      g.fillRect(0, y, 64, 1);
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    return tex;
  }

  function wrapText(g, text, x, y, maxWidth, lineHeight) {
    const words = text.split(" ");
    let line = "";
    for (let n = 0; n < words.length; n++) {
      const test = line + words[n] + " ";
      if (g.measureText(test).width > maxWidth && n > 0) {
        g.fillText(line.trimEnd(), x, y);
        line = words[n] + " ";
        y += lineHeight;
      } else {
        line = test;
      }
    }
    g.fillText(line.trimEnd(), x, y);
    return y + lineHeight;
  }

  function typesetPage(opts) {
    /* Original demo manuscript written in house for this studio. It belongs to
     our fictional sample title The Salt Garden and is not any client's text. */
    const MANUSCRIPT = [
      "The tide came in early that morning, the way it always did when the wind turned north.",
      "Edie stood at the end of the garden with her boots sinking into the wet sand and counted the rows of samphire her grandmother had planted the summer before the lighthouse closed.",
      "Nothing about the place had changed, and everything had. The gate still leaned on its one good hinge. The kettle still whistled a half note flat.",
      "But the chair by the window was empty now, and the garden, stubborn and green and rimed with salt, had become hers whether she wanted it or not.",
      "She set down her bag, rolled up her sleeves, and began to pull the weeds from the first row, because that was what you did with a morning like this one.",
      "You began.",
      "By noon the baskets were full and her hands smelled of brine and bruised leaves. The ferry sounded twice out in the channel, once for the crossing and once, she liked to think, for her.",
      "There would be letters to answer and accounts to settle and a roof that wanted mending before the storms came back.",
      "All of that could wait an hour. She sat on the low wall with her grandmother's notebook open on her knees and read the first entry again, the one that started with the same four words she now said out loud to the empty, shining garden.",
      "Plant what you love."
  ];

    const c = document.createElement("canvas");
    c.width = 640; c.height = 900;
    const g = c.getContext("2d");
    g.fillStyle = "#f8f3e6";
    g.fillRect(0, 0, 640, 900);
    /* faint paper grain */
    g.fillStyle = "rgba(140, 118, 92, 0.05)";
    for (let i = 0; i < 260; i++) {
      g.fillRect(Math.random() * 640, Math.random() * 900, 1.4, 1.4);
    }

    const M = 84;
    let y = 120;
    g.fillStyle = "#3f362c";
    g.textAlign = "center";

    if (opts.title) {
      g.fillStyle = "#8a7a64";
      g.font = "600 15px Georgia, serif";
      g.fillText("A  NOVEL", 320, 300);
      g.fillStyle = "#33291f";
      g.font = "600 44px Georgia, serif";
      g.fillText("The Salt Garden", 320, 370);
      g.fillStyle = "#8a7a64";
      g.font = "italic 400 19px Georgia, serif";
      g.fillText("by Ines Calloway", 320, 420);
      g.font = "400 14px Georgia, serif";
      g.fillText("First draft", 320, 700);
    } else {
      if (opts.chapter) {
        g.fillStyle = "#8a7a64";
        g.font = "600 16px Georgia, serif";
        g.fillText("C H A P T E R   O N E", 320, y);
        y += 64;
      } else {
        y = 96;
      }
      g.textAlign = "left";
      g.fillStyle = "#453a2e";
      g.font = "400 19px Georgia, serif";
      const paras = MANUSCRIPT.slice(opts.from, opts.to);
      for (const p of paras) {
        y = wrapText(g, p, M, y, 640 - M * 2, 30) + 14;
        if (y > 790) break;
      }
      g.textAlign = "center";
      g.fillStyle = "#9a8a74";
      g.font = "400 14px Georgia, serif";
      g.fillText(String(opts.pageNo || 1), 320, 848);
    }

    const tex = new THREE.CanvasTexture(c);
    tex.anisotropy = 8;
    return tex;
  }

  function makeTitlePageTexture() {
    return typesetPage({ title: true });
  }

  function makeSheetTexture(seed) {
    if (seed === 0) return typesetPage({ chapter: true, from: 0, to: 6, pageNo: 1 });
    if (seed === 1) return typesetPage({ from: 6, to: 10, pageNo: 2 });
    return typesetPage({ from: 2, to: 8, pageNo: 3 });
  }

  function makeEditMarksTexture() {
    const c = document.createElement("canvas");
    c.width = 512; c.height = 768;
    const g = c.getContext("2d");
    /* transparent background; just marks */
    g.strokeStyle = "rgba(164,38,38,0.85)";
    g.lineWidth = 3;
    /* circled word */
    g.beginPath(); g.ellipse(180, 452, 58, 16, -0.05, 0, Math.PI * 2); g.stroke();
    /* strike-through */
    g.beginPath(); g.moveTo(240, 520); g.lineTo(390, 516); g.stroke();
    /* caret + margin note squiggle */
    g.beginPath(); g.moveTo(300, 568); g.lineTo(312, 552); g.lineTo(324, 568); g.stroke();
    g.beginPath();
    g.moveTo(398, 430);
    for (let x = 0; x <= 70; x += 7) g.lineTo(398 + x, 430 + ((x / 7) % 2 ? 6 : -6));
    g.stroke();
    /* gold approval tick */
    g.strokeStyle = "rgba(184,145,74,0.95)";
    g.lineWidth = 5;
    g.beginPath(); g.moveTo(96, 640); g.lineTo(116, 662); g.lineTo(156, 610); g.stroke();
    return new THREE.CanvasTexture(c);
  }

  function averageColor(img) {
    return new Promise((resolve) => {
      try {
        const c = document.createElement("canvas");
        c.width = c.height = 8;
        const g = c.getContext("2d");
        g.drawImage(img, 0, 0, 8, 8);
        const d = g.getImageData(0, 0, 8, 8).data;
        let r = 0, gg = 0, b = 0;
        for (let i = 0; i < d.length; i += 4) { r += d[i]; gg += d[i + 1]; b += d[i + 2]; }
        const n = d.length / 4;
        const col = new THREE.Color(r / n / 255, gg / n / 255, b / n / 255);
        const dark = col.clone().multiplyScalar(0.55);
        const darker = col.clone().multiplyScalar(0.3);
        resolve({ dark, darker });
      } catch (e) {
        resolve({ dark: new THREE.Color(0x3a2029), darker: new THREE.Color(0x241318) });
      }
    });
  }

  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
}
