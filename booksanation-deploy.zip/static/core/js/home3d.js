/* Books A Nation: the publishing globe on the home page.
   Real coastlines (Natural Earth land mask) drawn as a dense dot matrix on a
   deep navy ocean, day/night shading, a soft atmosphere, and animated routes
   between real publishing hubs. Lazy init, DPR capped, paused when offscreen,
   drag to spin, reduced motion safe. */

/* three.js (about 170 KB compressed) is fetched only when the globe is about to scroll into view. */
let THREE = null;

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const canvas = document.getElementById("globe-canvas");

const R = 1.78;
let ORANGE, GOLD, LAND_DARK;
const OCEAN = 0x11284a;

const HUBS = [
  ["New York", 40.71, -74.0], ["Los Angeles", 34.05, -118.24], ["Toronto", 43.65, -79.38],
  ["Mexico City", 19.43, -99.13], ["Sao Paulo", -23.55, -46.63], ["London", 51.5, -0.12],
  ["Paris", 48.85, 2.35], ["Berlin", 52.52, 13.4], ["Lagos", 6.45, 3.39],
  ["Nairobi", -1.29, 36.82], ["Johannesburg", -26.2, 28.04], ["Dubai", 25.2, 55.27],
  ["Karachi", 24.86, 67.0], ["Mumbai", 19.08, 72.88], ["Delhi", 28.6, 77.2],
  ["Singapore", 1.35, 103.8], ["Tokyo", 35.68, 139.69], ["Sydney", -33.87, 151.2],
];
const ROUTES = [
  [5, 0], [0, 1], [5, 14], [14, 15], [15, 17], [0, 4], [8, 0], [11, 13], [16, 1],
  [7, 2], [10, 4], [12, 11], [6, 9], [3, 2], [16, 15], [13, 14], [5, 11], [17, 16],
];

function latLon(lat, lon, r = R) {
  const phi = (90 - lat) * Math.PI / 180;
  const theta = (lon + 180) * Math.PI / 180;
  return new THREE.Vector3(
    -r * Math.sin(phi) * Math.cos(theta),
    r * Math.cos(phi),
    r * Math.sin(phi) * Math.sin(theta)
  );
}

function softDot(inner, outer) {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d");
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, inner);
  grad.addColorStop(0.45, outer);
  grad.addColorStop(1, "rgba(240,91,36,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function ringSprite() {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d");
  g.strokeStyle = "rgba(255,150,100,1)";
  g.lineWidth = 3;
  g.beginPath(); g.arc(32, 32, 26, 0, Math.PI * 2); g.stroke();
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

if (canvas) {
  let started = false;
  const io = new IntersectionObserver((en) => {
    if (en[0].isIntersecting && !started) {
      started = true;
      import("three").then((mod) => {
        THREE = mod;
        ORANGE = new THREE.Color(0xf05b24);
        GOLD = new THREE.Color(0xefd3a3);
        LAND_DARK = new THREE.Color(0x5a4a33);
        build();
      }).catch(() => {});
    }
  }, { threshold: 0, rootMargin: "400px 0px" });
  io.observe(canvas);

  function build() {
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 60);
    const camBase = new THREE.Vector3(0, 0.3, 7.5);
    camera.position.copy(camBase);
    camera.lookAt(0, 0, 0);

    const fit = () => {
      const el = canvas.parentElement;
      renderer.setSize(el.clientWidth, el.clientHeight, false);
      camera.aspect = el.clientWidth / el.clientHeight;
      camera.updateProjectionMatrix();
      const narrow = el.clientWidth < 560;
      camBase.z = narrow ? 8.6 : 7.5;
    };
    fit();
    new ResizeObserver(fit).observe(canvas.parentElement);

    /* lights: a warm sun from the upper left, cool fill from the right */
    const sun = new THREE.DirectionalLight(0xfff1dd, 1.15);
    sun.position.set(-4, 2.5, 5);
    scene.add(sun);
    scene.add(new THREE.HemisphereLight(0x9fb3d6, 0x1a2238, 0.7));
    const sunDir = sun.position.clone().normalize();

    /* stars, far behind the globe */
    {
      const N = 420;
      const sp = new Float32Array(N * 3);
      for (let i = 0; i < N; i++) {
        sp[i * 3] = (Math.random() - 0.5) * 30;
        sp[i * 3 + 1] = (Math.random() - 0.5) * 18;
        sp[i * 3 + 2] = -8 - Math.random() * 12;
      }
      const sg = new THREE.BufferGeometry();
      sg.setAttribute("position", new THREE.BufferAttribute(sp, 3));
      scene.add(new THREE.Points(sg, new THREE.PointsMaterial({
        size: 0.05, color: 0xdfe6f5, transparent: true, opacity: 0.55, depthWrite: false, sizeAttenuation: true
      })));
    }

    const tilt = new THREE.Group();
    tilt.rotation.z = -0.38; /* axial tilt, leaning toward the viewer's left */
    tilt.rotation.x = 0.2;
    scene.add(tilt);
    const g = new THREE.Group();
    g.rotation.y = 4.1;
    tilt.add(g);

    /* ocean */
    const ocean = new THREE.Mesh(
      new THREE.SphereGeometry(R * 0.993, 96, 96),
      new THREE.MeshPhongMaterial({
        color: OCEAN, specular: 0x000000, shininess: 1, emissive: 0x07132a
      })
    );
    g.add(ocean);

    /* thin, slow cloud veil (procedural noise, very subtle) */
    {
      const CW = 512, CH = 256;
      const cc = document.createElement("canvas");
      cc.width = CW; cc.height = CH;
      const cg = cc.getContext("2d");
      const im = cg.createImageData(CW, CH);
      const rnd = new Float32Array(64 * 32);
      for (let i = 0; i < rnd.length; i++) rnd[i] = Math.random();
      const val = (x, y, f) => {
        const gx = (x / CW) * 64 * f, gy = (y / CH) * 32 * f;
        const x0 = Math.floor(gx) % 64, y0 = Math.floor(gy) % 32;
        const x1 = (x0 + 1) % 64, y1 = (y0 + 1) % 32;
        const tx = gx - Math.floor(gx), ty = gy - Math.floor(gy);
        const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
        const a = rnd[y0 * 64 + x0], b = rnd[y0 * 64 + x1], c = rnd[y1 * 64 + x0], d = rnd[y1 * 64 + x1];
        return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy;
      };
      for (let y = 0; y < CH; y++) for (let x = 0; x < CW; x++) {
        let n = 0.5 * val(x, y, 0.25) + 0.3 * val(x, y, 0.6) + 0.2 * val(x, y, 1.4);
        const lat = Math.abs(y / CH - 0.5) * 2;
        n = Math.max(0, (n - 0.52) * 2.6) * (0.6 + 0.4 * lat);
        const i = (y * CW + x) * 4;
        im.data[i] = im.data[i + 1] = im.data[i + 2] = 255;
        im.data[i + 3] = Math.min(255, n * 255);
      }
      cg.putImageData(im, 0, 0);
      const ct = new THREE.CanvasTexture(cc);
      ct.wrapS = THREE.RepeatWrapping;
      const clouds = new THREE.Mesh(
        new THREE.SphereGeometry(R * 1.018, 64, 64),
        new THREE.MeshLambertMaterial({ map: ct, transparent: true, opacity: 0.16, depthWrite: false })
      );
      g.add(clouds);
      clouds.userData.spin = true;
      g.userData.clouds = clouds;
    }

    /* thin bright rim on the sphere itself */
    const rim = new THREE.Mesh(
      new THREE.SphereGeometry(R * 1.004, 96, 96),
      new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        uniforms: { uColor: { value: new THREE.Color(0xffc9a6) } },
        vertexShader: `
          varying vec3 vN; varying vec3 vV;
          void main() {
            vec4 mv = modelViewMatrix * vec4(position, 1.0);
            vN = normalize(normalMatrix * normal);
            vV = normalize(-mv.xyz);
            gl_Position = projectionMatrix * mv;
          }`,
        fragmentShader: `
          uniform vec3 uColor; varying vec3 vN; varying vec3 vV;
          void main() {
            float f = pow(1.0 - max(dot(vN, vV), 0.0), 4.2);
            gl_FragColor = vec4(uColor, 1.0) * f * 0.55;
          }`
      })
    );
    g.add(rim);

    /* atmosphere halo */
    const halo = new THREE.Mesh(
      new THREE.SphereGeometry(R * 1.26, 80, 80),
      new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, side: THREE.BackSide, blending: THREE.AdditiveBlending,
        uniforms: { uColor: { value: new THREE.Color(0xe8733f) } },
        vertexShader: `
          varying vec3 vN;
          void main() {
            vN = normalize(normalMatrix * normal);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }`,
        fragmentShader: `
          uniform vec3 uColor; varying vec3 vN;
          void main() {
            float f = pow(0.62 - dot(vN, vec3(0.0, 0.0, 1.0)), 3.6);
            gl_FragColor = vec4(uColor, 1.0) * clamp(f, 0.0, 1.0) * 0.5;
          }`
      })
    );
    scene.add(halo);

    /* land: a dot matrix built from the real coastline mask */
    const landMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: {
        uLight: { value: sunDir },
        uLit: { value: GOLD },
        uDark: { value: LAND_DARK },
        uSize: { value: 1.5 * Math.min(window.devicePixelRatio, 1.75) },
        uReveal: { value: 0 },
      },
      vertexShader: `
        attribute float aSize; attribute float aSeed;
        uniform vec3 uLight; uniform float uSize; uniform float uReveal;
        varying float vShade; varying float vAlpha;
        void main() {
          vec3 n = normalize(mat3(modelMatrix) * normalize(position));
          float d = dot(n, normalize(uLight));
          vShade = 0.28 + 0.72 * smoothstep(-0.25, 0.55, d);
          vAlpha = smoothstep(aSeed - 0.08, aSeed, uReveal);
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = uSize * aSize * (7.5 / -mv.z);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        uniform vec3 uLit; uniform vec3 uDark;
        varying float vShade; varying float vAlpha;
        void main() {
          float r = length(gl_PointCoord - 0.5);
          float a = smoothstep(0.5, 0.3, r) * vAlpha;
          if (a < 0.02) discard;
          vec3 c = mix(uDark, uLit, vShade);
          gl_FragColor = vec4(c, a);
        }`
    });
    let land = null;

    const img = new Image();
    img.onload = () => {
      const W = 1024, H = 512;
      const c = document.createElement("canvas");
      c.width = W; c.height = H;
      const ctx = c.getContext("2d", { willReadFrequently: true });
      ctx.drawImage(img, 0, 0, W, H);
      const px = ctx.getImageData(0, 0, W, H).data;
      const isLand = (lat, lon) => {
        const x = Math.min(W - 1, Math.max(0, Math.floor((lon + 180) / 360 * W)));
        const y = Math.min(H - 1, Math.max(0, Math.floor((90 - lat) / 180 * H)));
        return px[(y * W + x) * 4] > 128;
      };
      const N = 92000;
      const phiG = Math.PI * (3 - Math.sqrt(5));
      const pos = [], sizes = [], seeds = [];
      for (let i = 0; i < N; i++) {
        const y = 1 - (i / (N - 1)) * 2;
        const rad = Math.sqrt(1 - y * y);
        const th = phiG * i;
        const x = Math.cos(th) * rad, z = Math.sin(th) * rad;
        const lat = Math.asin(y) * 180 / Math.PI;
        let lon = Math.atan2(z, -x) * 180 / Math.PI - 180;
        if (lon < -180) lon += 360;
        if (!isLand(lat, lon)) continue;
        /* a touch of coastline softness: thin out dots right at the edge */
        const edge = !isLand(lat + 0.35, lon) || !isLand(lat - 0.35, lon) || !isLand(lat, lon + 0.35) || !isLand(lat, lon - 0.35);
        if (edge && Math.random() < 0.25) continue;
        pos.push(x * R, y * R, z * R);
        sizes.push((edge ? 0.75 : 0.9) + Math.random() * 0.35);
        seeds.push(Math.random());
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
      geo.setAttribute("aSize", new THREE.Float32BufferAttribute(sizes, 1));
      geo.setAttribute("aSeed", new THREE.Float32BufferAttribute(seeds, 1));
      land = new THREE.Points(geo, landMat);
      g.add(land);
    };
    img.src = canvas.dataset.mask;

    /* hubs: a bright core plus an expanding pulse ring */
    const coreTex = softDot("rgba(255,236,220,1)", "rgba(240,91,36,0.85)");
    const ringTex = ringSprite();
    const hubs = HUBS.map(([name, lat, lon], i) => {
      const p = latLon(lat, lon, R * 1.012);
      const core = new THREE.Sprite(new THREE.SpriteMaterial({ map: coreTex, transparent: true, depthWrite: false, depthTest: true }));
      core.position.copy(p);
      core.scale.setScalar(0.11);
      g.add(core);
      const ring = new THREE.Sprite(new THREE.SpriteMaterial({ map: ringTex, transparent: true, depthWrite: false, opacity: 0, color: 0xff9a6a }));
      ring.position.copy(p);
      ring.scale.setScalar(0.1);
      g.add(ring);
      return { name, p, core, ring, t0: (i * 0.37) % 3 };
    });

    /* routes: tubes that grow along a lifted great circle, with a travelling light */
    const tubeMat = new THREE.MeshBasicMaterial({ color: 0xff8f5a, transparent: true, opacity: 0.0, blending: THREE.AdditiveBlending, depthWrite: false });
    const headTex = softDot("rgba(255,245,235,1)", "rgba(255,150,100,0.8)");
    const routes = ROUTES.map(([a, b], i) => {
      const pa = hubs[a].p, pb = hubs[b].p;
      const dist = pa.distanceTo(pb);
      const lift = R * (0.18 + dist * 0.22);
      const m1 = pa.clone().lerp(pb, 0.3).normalize().multiplyScalar(R + lift);
      const m2 = pa.clone().lerp(pb, 0.7).normalize().multiplyScalar(R + lift);
      const curve = new THREE.CubicBezierCurve3(pa, m1, m2, pb);
      const SEG = 72;
      const geo = new THREE.TubeGeometry(curve, SEG, 0.0075, 6, false);
      const mesh = new THREE.Mesh(geo, tubeMat.clone());
      geo.setDrawRange(0, 0);
      g.add(mesh);
      const head = new THREE.Sprite(new THREE.SpriteMaterial({ map: headTex, transparent: true, depthWrite: false, opacity: 0 }));
      head.scale.setScalar(0.16);
      g.add(head);
      const idxPerSeg = geo.index.count / SEG;
      return { curve, mesh, head, SEG, idxPerSeg, t0: i * 0.9, period: 8 + (i % 4) * 0.5, from: hubs[a], to: hubs[b] };
    });

    canvas.__dbg = { ocean, rim, halo, clouds: g.userData.clouds, sun };

    /* drag to spin, hover for a little parallax */
    let dragging = false, px = 0, vel = 0, hoverX = 0, hoverY = 0;
    canvas.addEventListener("pointerdown", (e) => { dragging = true; px = e.clientX; canvas.setPointerCapture(e.pointerId); });
    canvas.addEventListener("pointermove", (e) => {
      const rect = canvas.getBoundingClientRect();
      hoverX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      hoverY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
      if (!dragging) return;
      const dx = e.clientX - px; px = e.clientX;
      g.rotation.y += dx * 0.005;
      vel = dx * 0.005;
    });
    const stop = () => { dragging = false; };
    canvas.addEventListener("pointerup", stop);
    canvas.addEventListener("pointercancel", stop);
    canvas.addEventListener("pointerleave", () => { hoverX = 0; hoverY = 0; });

    let visible = true;
    new IntersectionObserver((en) => { visible = en[0].isIntersecting; }, { threshold: 0 }).observe(canvas);

    const clock = new THREE.Clock();
    const easeOut = (u) => 1 - Math.pow(1 - u, 3);
    let last = 0;

    (function tick() {
      requestAnimationFrame(tick);
      if (!visible) return;
      const t = clock.getElapsedTime();
      const dt = Math.min(0.05, t - last); last = t;

      /* entrance */
      const intro = easeOut(Math.min(1, t / 1.6));
      tilt.scale.setScalar(0.92 + 0.08 * intro);
      landMat.uniforms.uReveal.value = Math.min(1, Math.max(0, (t - 0.2) / 1.6));

      if (!dragging) {
        vel *= 0.95;
        g.rotation.y += (reduceMotion ? 0 : 0.085 * dt) + vel;
      }
      if (!reduceMotion) g.userData.clouds.rotation.y += 0.012 * dt;

      /* camera parallax */
      const tx = camBase.x + hoverX * 0.25, ty = camBase.y - hoverY * 0.18;
      camera.position.x += (tx - camera.position.x) * 0.05;
      camera.position.y += (ty - camera.position.y) * 0.05;
      camera.position.z += (camBase.z - camera.position.z) * 0.08;
      camera.lookAt(0, 0, 0);

      if (!reduceMotion) {
        for (const h of hubs) {
          const u = ((t + h.t0) % 3) / 3;
          h.ring.scale.setScalar(0.1 + u * 0.42);
          h.ring.material.opacity = (1 - u) * 0.75;
          h.core.scale.setScalar(0.10 + Math.sin(t * 3 + h.t0 * 7) * 0.012);
        }
        for (const r of routes) {
          const lt = (t + r.t0) % r.period;
          const grow = 1.5, hold = 1.2, fade = 0.7;
          if (lt > grow + hold + fade) { r.mesh.material.opacity = 0; r.head.material.opacity = 0; r.mesh.geometry.setDrawRange(0, 0); continue; }
          let frac, op;
          if (lt < grow) { frac = easeOut(lt / grow); op = 0.9; }
          else if (lt < grow + hold) { frac = 1; op = 0.9; }
          else { frac = 1; op = 0.9 * (1 - (lt - grow - hold) / fade); }
          r.mesh.geometry.setDrawRange(0, Math.floor(frac * r.SEG) * r.idxPerSeg);
          r.mesh.material.opacity = op;
          r.head.position.copy(r.curve.getPoint(frac));
          r.head.material.opacity = lt < grow ? 1 : op * 0.6;
        }
      } else {
        for (const r of routes) {
          r.mesh.geometry.setDrawRange(0, Infinity);
          r.mesh.material.opacity = 0.55;
          r.head.material.opacity = 0;
        }
        for (const h of hubs) h.ring.material.opacity = 0;
      }

      renderer.render(scene, camera);
    })();
  }
}
