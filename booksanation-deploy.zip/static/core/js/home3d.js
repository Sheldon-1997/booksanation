/* Books A Nation: 3D publishing globe for the home page.
   Ink points on a light stage, flame orange arcs. Lazy init, DPR capped,
   paused when offscreen, reduced motion safe. */

import * as THREE from "three";

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

const INK = 0x2a2620;
const ORANGE = 0xf05b24;
const ORANGE_SOFT = 0xf4855c;

function moteTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d");
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, "rgba(240,91,36,1)");
  grad.addColorStop(0.4, "rgba(240,91,36,0.6)");
  grad.addColorStop(1, "rgba(240,91,36,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

const canvas = document.getElementById("globe-canvas");
if (canvas) {
  let started = false;
  const io = new IntersectionObserver((en) => {
    if (en[0].isIntersecting && !started) { started = true; build(); }
  }, { threshold: 0.1 });
  io.observe(canvas);

  function build() {
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 50);
    camera.position.set(0, 0.4, 5.4);
    camera.lookAt(0, 0, 0);

    const fit = () => {
      const el = canvas.parentElement;
      renderer.setSize(el.clientWidth, el.clientHeight, false);
      camera.aspect = el.clientWidth / el.clientHeight;
      camera.updateProjectionMatrix();
    };
    fit();
    new ResizeObserver(fit).observe(canvas.parentElement);

    const g = new THREE.Group();
    g.rotation.z = 0.2;
    scene.add(g);

    const R = 1.72;

    /* Fibonacci sphere of ink points */
    const COUNT = 1500;
    const pos = new Float32Array(COUNT * 3);
    const phi = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < COUNT; i++) {
      const y = 1 - (i / (COUNT - 1)) * 2;
      const rad = Math.sqrt(1 - y * y);
      const th = phi * i;
      pos[i * 3] = Math.cos(th) * rad * R;
      pos[i * 3 + 1] = y * R;
      pos[i * 3 + 2] = Math.sin(th) * rad * R;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.add(new THREE.Points(geo, new THREE.PointsMaterial({
      size: 0.022, color: INK, transparent: true, opacity: 0.55, depthWrite: false
    })));

    /* Faint graticule rings */
    const ringMat = new THREE.LineBasicMaterial({ color: INK, transparent: true, opacity: 0.12 });
    for (let k = -2; k <= 2; k++) {
      const lat = k * 0.5;
      const rr = Math.cos(lat) * R, yy = Math.sin(lat) * R;
      const cps = [];
      for (let i = 0; i <= 72; i++) {
        const a = (i / 72) * Math.PI * 2;
        cps.push(new THREE.Vector3(Math.cos(a) * rr, yy, Math.sin(a) * rr));
      }
      g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(cps), ringMat));
    }

    /* Animated arcs */
    function surfacePoint() {
      const u = Math.random(), v = Math.random();
      const th = 2 * Math.PI * u, ph = Math.acos(2 * v - 1);
      return new THREE.Vector3(
        R * Math.sin(ph) * Math.cos(th),
        R * Math.cos(ph) * 0.85,
        R * Math.sin(ph) * Math.sin(th)
      );
    }

    const arcs = [];
    for (let i = 0; i < 9; i++) {
      const a = surfacePoint(), b = surfacePoint();
      const mid = a.clone().add(b).multiplyScalar(0.5).normalize().multiplyScalar(R * (1.35 + Math.random() * 0.35));
      const curve = new THREE.QuadraticBezierCurve3(a, mid, b);
      const ageo = new THREE.BufferGeometry().setFromPoints(curve.getPoints(60));
      const amat = new THREE.LineBasicMaterial({ color: ORANGE, transparent: true, opacity: 0 });
      const line = new THREE.Line(ageo, amat);
      ageo.setDrawRange(0, 0);
      g.add(line);

      const dot = new THREE.Sprite(new THREE.SpriteMaterial({
        map: moteTexture(), color: ORANGE_SOFT, transparent: true, depthWrite: false
      }));
      dot.scale.setScalar(0.15);
      g.add(dot);

      arcs.push({ curve, line, dot, t0: Math.random() * 6, dur: 2.6 + Math.random() * 1.6 });
    }

    /* Drag to spin */
    let dragging = false, px = 0, vel = 0;
    canvas.addEventListener("pointerdown", (e) => { dragging = true; px = e.clientX; canvas.setPointerCapture(e.pointerId); });
    canvas.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - px; px = e.clientX;
      g.rotation.y += dx * 0.005;
      vel = dx * 0.005;
    });
    const stop = () => { dragging = false; };
    canvas.addEventListener("pointerup", stop);
    canvas.addEventListener("pointercancel", stop);

    let visible = true;
    new IntersectionObserver((en) => { visible = en[0].isIntersecting; }, { threshold: 0 }).observe(canvas);

    const clock = new THREE.Clock();

    (function tick() {
      requestAnimationFrame(tick);
      if (!visible) return;
      const t = clock.getElapsedTime();

      if (!dragging) {
        vel *= 0.95;
        g.rotation.y += reduceMotion ? 0 : 0.0021 + vel;
      }

      if (!reduceMotion) {
        for (const a of arcs) {
          const lt = ((t + a.t0) % 6) / a.dur;
          if (lt > 1.35) { a.line.material.opacity = 0; a.dot.material.opacity = 0; continue; }
          const grow = Math.min(1, lt);
          a.line.geometry.setDrawRange(0, Math.floor(grow * 60));
          a.line.material.opacity = lt < 1 ? 0.7 : Math.max(0, 0.7 * (1 - (lt - 1) / 0.35));
          const p = a.curve.getPoint(Math.min(1, grow));
          a.dot.position.copy(p);
          a.dot.material.opacity = a.line.material.opacity;
        }
      } else {
        for (const a of arcs) {
          a.line.geometry.setDrawRange(0, 60);
          a.line.material.opacity = 0.45;
          a.dot.material.opacity = 0;
        }
      }

      renderer.render(scene, camera);
    })();
  }
}
