/* Books A Nation — site behaviour (no external dependencies) */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Mobile nav ---------- */
  var navToggle = document.querySelector(".nav-toggle");
  var mainNav = document.querySelector(".main-nav");
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", function () {
      var open = mainNav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    mainNav.addEventListener("click", function (e) {
      if (e.target.tagName === "A") mainNav.classList.remove("open");
    });
  }

  /* ---------- Active nav link ---------- */
  var path = location.pathname;
  document.querySelectorAll(".main-nav a[href]").forEach(function (a) {
    var href = a.getAttribute("href");
    if (href === "/" ? path === "/" : path.indexOf(href) === 0) a.classList.add("active");
  });

  /* ---------- Images: retry once if a load fails (network blip, server update) ---------- */
  document.addEventListener("error", function (e) {
    var img = e.target;
    if (!img || img.tagName !== "IMG" || img.dataset.retried) return;
    var src = img.getAttribute("src") || "";
    if (src.indexOf("/static/") !== 0 && src.indexOf("/media/") !== 0) return;
    img.dataset.retried = "1";
    setTimeout(function () { img.src = src + (src.indexOf("?") < 0 ? "?" : "&") + "r=" + Date.now(); }, 1500);
  }, true);
  /* images that already failed before this script ran */
  document.querySelectorAll("img").forEach(function (img) {
    if (img.complete && img.naturalWidth === 0 && img.getAttribute("src") && !/\.svg(\?|$)/.test(img.getAttribute("src")) && !img.dataset.retried) {
      img.dispatchEvent(new Event("error"));
    }
  });

  /* ---------- Videos: play only while visible ---------- */
  /* Videos load nothing until they are close to the screen, then play only while visible. */
  var vids = document.querySelectorAll("video[autoplay]");
  if (vids.length && "IntersectionObserver" in window) {
    var vio = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        var v = en.target;
        if (en.isIntersecting) {
          var pr = v.play();
          if (pr && pr.catch) pr.catch(function () {});
        } else {
          v.pause();
        }
      });
    }, { threshold: 0.01, rootMargin: "200px 0px" });
    vids.forEach(function (v) { vio.observe(v); });
  }

  /* ---------- Cover shelf carousel ---------- */
  var shelf = document.getElementById("cover-shelf");
  if (shelf) {
    var stepW = function () {
      var book = shelf.querySelector(".shelf-book");
      return book ? (book.offsetWidth + 26) * 2 : 400;
    };
    document.querySelectorAll(".shelf-nav.prev").forEach(function (b) {
      b.addEventListener("click", function () { shelf.scrollBy({ left: -stepW(), behavior: "smooth" }); });
    });
    document.querySelectorAll(".shelf-nav.next").forEach(function (b) {
      b.addEventListener("click", function () { shelf.scrollBy({ left: stepW(), behavior: "smooth" }); });
    });
  }

  /* ---------- Gold dust: site-wide ambient particles ---------- */
  var dust = document.getElementById("dust");
  var lowEnd = window.innerWidth < 1024 || (navigator.deviceMemory && navigator.deviceMemory <= 4) ||
    (navigator.connection && navigator.connection.saveData) || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
  if (dust && !reduceMotion && !lowEnd) {
    var ctx = dust.getContext("2d");
    var P = [];
    var DW = 0, DH = 0;
    function dustResize() {
      DW = dust.width = window.innerWidth;
      DH = dust.height = window.innerHeight;
    }
    dustResize();
    window.addEventListener("resize", dustResize);
    var COUNT = Math.min(70, Math.floor(window.innerWidth / 18));
    for (var i = 0; i < COUNT; i++) {
      P.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        r: 0.6 + Math.random() * 1.6,
        s: 0.08 + Math.random() * 0.25,
        a: 0.08 + Math.random() * 0.3,
        ph: Math.random() * Math.PI * 2
      });
    }
    var hidden = false;
    document.addEventListener("visibilitychange", function () { hidden = document.hidden; });
    (function dustTick(now) {
      requestAnimationFrame(dustTick);
      if (hidden) return;
      ctx.clearRect(0, 0, DW, DH);
      var t = (now || 0) / 1000;
      for (var i = 0; i < P.length; i++) {
        var p = P[i];
        p.y -= p.s;
        p.x += Math.sin(t * 0.5 + p.ph) * 0.15;
        if (p.y < -5) { p.y = DH + 5; p.x = Math.random() * DW; }
        var tw = 0.5 + 0.5 * Math.sin(t * 1.3 + p.ph);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(243, 212, 146," + (p.a * tw) + ")";
        ctx.fill();
      }
    })(0);
  }

  /* ---------- Ad and campaign attribution ----------
     Remembers how the visitor arrived (Google Ads click ID, UTM tags, referring site)
     so a message they send can be credited to the right campaign. Session storage
     only, unless the visitor has accepted marketing cookies. */
  var ATTR_KEYS = ["gclid", "gbraid", "wbraid", "msclkid", "fbclid", "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"];
  function attrStore() {
    return window.BAN_CONSENT === "granted" ? window.localStorage : window.sessionStorage;
  }
  function readAttr() {
    var a = null;
    try { a = JSON.parse(sessionStorage.getItem("ban-attr") || "null"); } catch (e) {}
    if (!a) { try { a = JSON.parse(localStorage.getItem("ban-attr") || "null"); } catch (e) {} }
    if (a && a.ts && Date.now() - a.ts > 90 * 864e5) a = null;
    return a || {};
  }
  (function captureAttr() {
    var got = {}, any = false, ext = "";
    try {
      var q = new URLSearchParams(location.search);
      ATTR_KEYS.forEach(function (k) { var v = q.get(k); if (v) { got[k] = v.slice(0, 300); any = true; } });
      if (document.referrer) {
        var h = new URL(document.referrer).hostname;
        if (h && h !== location.hostname) ext = h;
      }
    } catch (e) {}
    var have = readAttr();
    if (!any && (!ext || have.ts)) return;
    if (!any) got = {};
    got.landing = location.pathname;
    if (ext) got.referrer = ext;
    got.first_seen = new Date().toISOString().slice(0, 10);
    got.ts = Date.now();
    try { attrStore().setItem("ban-attr", JSON.stringify(got)); } catch (e) {}
  })();
  function track(name, params) {
    if (window.banTrack) { try { window.banTrack(name, params); } catch (e) {} }
  }

  /* Phone number clicks count as a conversion for ads. */
  document.addEventListener("click", function (e) {
    var a = e.target.closest ? e.target.closest('a[href^="tel:"]') : null;
    if (!a) return;
    var where = a.closest("header, footer, .dock, .promo-bar, .page-hero, .hero, section");
    track("phone_click", { link_location: where ? (where.className || where.tagName).toString().split(" ")[0] : "page" });
  });

  /* ---------- Helpers ---------- */
  function getCookie(name) {
    var m = document.cookie.match("(^|;)\\s*" + name + "\\s*=\\s*([^;]+)");
    return m ? decodeURIComponent(m.pop()) : "";
  }

  function postJSON(url, data) {
    return fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCookie("csrftoken")
      },
      body: JSON.stringify(data)
    }).then(function (r) { return r.json(); });
  }

  /* ---------- Inquiry form ---------- */
  document.querySelectorAll("form[data-inquiry]").forEach(function (form) {
    var tsField = form.querySelector("[name=ts]");
    if (tsField) tsField.value = String(Date.now());
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var status = form.querySelector(".form-status");
      var btn = form.querySelector("button[type=submit]");
      var payload = {
        name: form.querySelector("[name=name]").value,
        email: form.querySelector("[name=email]").value,
        phone: (form.querySelector("[name=phone]") || {}).value || "",
        service: (form.querySelector("[name=service]") || {}).value || "publishing",
        message: form.querySelector("[name=message]").value,
        page: location.pathname,
        website: (form.querySelector("[name=website]") || {}).value || "",
        ts: (form.querySelector("[name=ts]") || {}).value || "",
        attribution: readAttr()
      };
      if (btn) { btn.disabled = true; btn.textContent = "Sending…"; }
      postJSON("/api/inquiry/", payload).then(function (res) {
        if (res.ok) {
          track("generate_lead", { form_name: form.getAttribute("data-form-name") || "contact_form", page_path: location.pathname });
          form.reset();
          if (status) {
            status.textContent = "Thank you. We received your message and will reply to your email shortly.";
            status.className = "form-status ok";
          }
          var lm = form.closest(".lead-modal");
          if (lm) {
            try { sessionStorage.setItem("ban-lead-done", "1"); } catch (e) {}
            setTimeout(function () { lm.classList.remove("open"); lm.setAttribute("aria-hidden", "true"); }, 2600);
          }
        } else {
          if (status) {
            status.textContent = res.error || "Something went wrong. Please try again or email us directly.";
            status.className = "form-status err";
          }
        }
      }).catch(function () {
        if (status) {
          status.textContent = "Could not send right now. Please email support@booksanation.com.";
          status.className = "form-status err";
        }
      }).finally(function () {
        if (btn) { btn.disabled = false; btn.textContent = btn.dataset.label || "Send message"; }
      });
    });
  });

  /* ---------- Live chat widget ---------- */
  var fab = document.getElementById("chat-fab");
  var panel = document.getElementById("chat-panel");
  if (fab && panel) {
    var log = panel.querySelector(".chat-log");
    var textarea = panel.querySelector("textarea[name=chat-body]");
    var nameInput = panel.querySelector("input[name=chat-name]");
    var emailInput = panel.querySelector("input[name=chat-email]");
    var sendBtn = panel.querySelector(".chat-send");
    var closeBtn = panel.querySelector(".chat-close");
    var sessionKey = "";
    var lastId = 0;
    var pollTimer = null;
    var greeted = false;

    try { sessionKey = sessionStorage.getItem("ban-chat-session") || ""; } catch (e) {}

    function addMsg(sender, body) {
      var div = document.createElement("div");
      div.className = "chat-msg " + sender;
      div.textContent = body;
      log.appendChild(div);
      log.scrollTop = log.scrollHeight;
    }

    function openPanel() {
      panel.classList.add("open");
      fab.setAttribute("aria-expanded", "true");
      var badge = fab.querySelector(".chat-badge");
      if (badge) badge.classList.add("hide");
      if (!greeted) {
        addMsg("system", "Welcome to Books A Nation. Tell us about your book. We reply here and by email.");
        greeted = true;
      }
      textarea.focus();
      startPoll();
    }

    function closePanel() {
      panel.classList.remove("open");
      fab.setAttribute("aria-expanded", "false");
      stopPoll();
    }

    window.banOpenBuiltInChat = openPanel;

    /* The Live Agent button opens Tawk.to when it is connected, otherwise the built in chat. */
    function openLiveAgent() {
      track("chat_open", { chat_provider: window.banOpenLiveAgent ? "tawk" : "built_in" });
      var badge = fab.querySelector(".chat-badge");
      if (badge) badge.classList.add("hide");
      if (window.banOpenLiveAgent) window.banOpenLiveAgent(); else openPanel();
    }

    fab.addEventListener("click", function () {
      panel.classList.contains("open") ? closePanel() : openLiveAgent();
    });
    closeBtn.addEventListener("click", closePanel);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && panel.classList.contains("open")) closePanel();
    });

    /* Open chat from any "open live chat" link */
    document.querySelectorAll("[data-open-chat]").forEach(function (el) {
      el.addEventListener("click", function (e) { e.preventDefault(); openLiveAgent(); });
    });

    function send() {
      var body = textarea.value.trim();
      if (!body) return;
      addMsg("visitor", body);
      textarea.value = "";
      postJSON("/api/chat/send/", {
        body: body,
        website: (panel.querySelector("input[name=chat-website]") || {}).value || "",
        session: sessionKey,
        name: nameInput ? nameInput.value : "",
        email: emailInput ? emailInput.value : ""
      }).then(function (res) {
        if (res.ok && res.session) {
          if (!sessionKey) {
            addMsg("system", "Thanks, your message is with our team. Leave your email above and we'll reply there too.");
          }
          sessionKey = res.session;
          try { sessionStorage.setItem("ban-chat-session", sessionKey); } catch (e) {}
        }
      }).catch(function () {
        addMsg("system", "Message could not be sent. Please email support@booksanation.com.");
      });
    }

    sendBtn.addEventListener("click", send);
    textarea.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
    });

    function poll() {
      if (!sessionKey) return;
      fetch("/api/chat/poll/?session=" + encodeURIComponent(sessionKey) + "&after=" + lastId)
        .then(function (r) { return r.json(); })
        .then(function (res) {
          (res.messages || []).forEach(function (m) {
            lastId = Math.max(lastId, m.id);
            if (m.sender === "staff") {
              addMsg("staff", m.body);
              var badge = fab.querySelector(".chat-badge");
              if (badge && !panel.classList.contains("open")) badge.classList.remove("hide");
            }
          });
        })
        .catch(function () {});
    }

    function startPoll() {
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = setInterval(poll, 6000);
      poll();
    }
    function stopPoll() {
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = sessionKey ? setInterval(poll, 30000) : null;
    }
    if (sessionKey) stopPoll();
  }
})();

/* ---------- Promo bar + lead-capture modal ---------- */
(function () {
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Promo bar dismiss (remember for the session)
  var promo = document.getElementById("promo-bar");
  var promoClose = document.getElementById("promo-close");
  var promoKey = (promo && promo.getAttribute("data-promo-key")) || "ban-promo-closed";
  try { if (promo && sessionStorage.getItem(promoKey) === "1") promo.classList.add("hide"); } catch (e) {}
  if (promoClose && promo) {
    promoClose.addEventListener("click", function () {
      promo.classList.add("hide");
      try { sessionStorage.setItem(promoKey, "1"); } catch (e) {}
    });
  }

  // Lead modal
  var modal = document.getElementById("lead-modal");
  if (!modal) return;
  function openModal() {
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  }
  function closeModal() {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    try { sessionStorage.setItem("ban-lead-done", "1"); } catch (e) {}
  }
  modal.querySelectorAll("[data-lead-close]").forEach(function (el) {
    el.addEventListener("click", closeModal);
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && modal.classList.contains("open")) closeModal();
  });
  document.querySelectorAll("[data-open-lead]").forEach(function (el) {
    el.addEventListener("click", function (e) { e.preventDefault(); openModal(); });
  });
  // Auto-show once per session, desktop only (Google penalises pop-ups on mobile),
  // never on the contact page, and only after the visitor has read a little:
  // 25 seconds on the page or 40% scrolled, whichever comes first.
  var seen = false;
  try { seen = sessionStorage.getItem("ban-lead-done") === "1"; } catch (e) {}
  var mobile = window.innerWidth < 900 || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
  var onContact = location.pathname.indexOf("/contact") === 0;
  if (!seen && !mobile && !onContact) {
    var fired = false;
    function autoOpen() {
      if (fired) return;
      fired = true;
      window.removeEventListener("scroll", onScroll);
      if (!modal.classList.contains("open") && !document.querySelector(".chat-panel.open")) openModal();
    }
    function onScroll() {
      var max = document.documentElement.scrollHeight - window.innerHeight;
      if (max > 0 && window.scrollY / max >= 0.4) autoOpen();
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    setTimeout(autoOpen, reduce ? 40000 : 25000);
  }
})();
