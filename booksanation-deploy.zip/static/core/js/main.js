/* Books A Nation — site behaviour (no external dependencies) */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Mobile nav ---------- */
  var navToggle = document.querySelector(".nav-toggle");
  var mainNav = document.querySelector(".main-nav");
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", function () {
      var open = mainNav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    mainNav.addEventListener("click", function (e) {
      if (e.target.tagName === "A") mainNav.classList.remove("open");
    });
  }

  /* ---------- Active nav link ---------- */
  var path = location.pathname;
  document.querySelectorAll(".main-nav a[href]").forEach(function (a) {
    var href = a.getAttribute("href");
    if (href === "/" ? path === "/" : path.indexOf(href) === 0) a.classList.add("active");
  });

  /* ---------- Scroll reveal with automatic stagger ---------- */
  document.querySelectorAll(".card-grid, .steps, .genre-grid, .platform-grid, .mosaic").forEach(function (grid) {
    var kids = grid.querySelectorAll(":scope > .reveal");
    kids.forEach(function (el, i) { el.style.transitionDelay = Math.min(i * 60, 360) + "ms"; });
  });

  if (!reduceMotion && "IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add("in");
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    document.querySelectorAll(".reveal").forEach(function (el) { io.observe(el); });
  } else {
    document.querySelectorAll(".reveal").forEach(function (el) { el.classList.add("in"); });
  }

  /* ---------- Card tilt + hover light (desktop) ---------- */
  if (!reduceMotion && window.matchMedia("(hover: hover)").matches) {
    document.querySelectorAll(".card, .platform-tile").forEach(function (el) {
      el.addEventListener("pointermove", function (e) {
        var r = el.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width - 0.5;
        var py = (e.clientY - r.top) / r.height - 0.5;
        el.style.transform = "perspective(900px) rotateY(" + (px * 5) + "deg) rotateX(" + (-py * 5) + "deg) translateY(-5px)";
        el.style.setProperty("--mx", ((px + 0.5) * 100) + "%");
        el.style.setProperty("--my", ((py + 0.5) * 100) + "%");
      });
      el.addEventListener("pointerleave", function () { el.style.transform = ""; });
    });
  }

  /* ---------- Videos: play only while visible ---------- */
  var vids = document.querySelectorAll("video[autoplay]");
  if (vids.length && "IntersectionObserver" in window) {
    var vio = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        var v = en.target;
        if (en.isIntersecting) {
          var pr = v.play();
          if (pr && pr.catch) pr.catch(function () {});
        } else {
          v.pause();
        }
      });
    }, { threshold: 0.15 });
    vids.forEach(function (v) { vio.observe(v); });
  }

  /* ---------- Cover shelf carousel ---------- */
  var shelf = document.getElementById("cover-shelf");
  if (shelf) {
    var stepW = function () {
      var book = shelf.querySelector(".shelf-book");
      return book ? (book.offsetWidth + 26) * 2 : 400;
    };
    document.querySelectorAll(".shelf-nav.prev").forEach(function (b) {
      b.addEventListener("click", function () { shelf.scrollBy({ left: -stepW(), behavior: "smooth" }); });
    });
    document.querySelectorAll(".shelf-nav.next").forEach(function (b) {
      b.addEventListener("click", function () { shelf.scrollBy({ left: stepW(), behavior: "smooth" }); });
    });
  }

  /* ---------- Gold dust: site-wide ambient particles ---------- */
  var dust = document.getElementById("dust");
  if (dust && !reduceMotion) {
    var ctx = dust.getContext("2d");
    var P = [];
    var DW = 0, DH = 0;
    function dustResize() {
      DW = dust.width = window.innerWidth;
      DH = dust.height = window.innerHeight;
    }
    dustResize();
    window.addEventListener("resize", dustResize);
    var COUNT = Math.min(70, Math.floor(window.innerWidth / 18));
    for (var i = 0; i < COUNT; i++) {
      P.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        r: 0.6 + Math.random() * 1.6,
        s: 0.08 + Math.random() * 0.25,
        a: 0.08 + Math.random() * 0.3,
        ph: Math.random() * Math.PI * 2
      });
    }
    var hidden = false;
    document.addEventListener("visibilitychange", function () { hidden = document.hidden; });
    (function dustTick(now) {
      requestAnimationFrame(dustTick);
      if (hidden) return;
      ctx.clearRect(0, 0, DW, DH);
      var t = (now || 0) / 1000;
      for (var i = 0; i < P.length; i++) {
        var p = P[i];
        p.y -= p.s;
        p.x += Math.sin(t * 0.5 + p.ph) * 0.15;
        if (p.y < -5) { p.y = DH + 5; p.x = Math.random() * DW; }
        var tw = 0.5 + 0.5 * Math.sin(t * 1.3 + p.ph);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(243, 212, 146," + (p.a * tw) + ")";
        ctx.fill();
      }
    })(0);
  }

  /* ---------- Helpers ---------- */
  function getCookie(name) {
    var m = document.cookie.match("(^|;)\\s*" + name + "\\s*=\\s*([^;]+)");
    return m ? decodeURIComponent(m.pop()) : "";
  }

  function postJSON(url, data) {
    return fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCookie("csrftoken")
      },
      body: JSON.stringify(data)
    }).then(function (r) { return r.json(); });
  }

  /* ---------- Inquiry form ---------- */
  document.querySelectorAll("form[data-inquiry]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var status = form.querySelector(".form-status");
      var btn = form.querySelector("button[type=submit]");
      var payload = {
        name: form.querySelector("[name=name]").value,
        email: form.querySelector("[name=email]").value,
        phone: (form.querySelector("[name=phone]") || {}).value || "",
        service: (form.querySelector("[name=service]") || {}).value || "publishing",
        message: form.querySelector("[name=message]").value,
        page: location.pathname
      };
      if (btn) { btn.disabled = true; btn.textContent = "Sending…"; }
      postJSON("/api/inquiry/", payload).then(function (res) {
        if (res.ok) {
          form.reset();
          if (status) {
            status.textContent = "Thank you. We received your message and will reply to your email shortly.";
            status.className = "form-status ok";
          }
          var lm = form.closest(".lead-modal");
          if (lm) {
            try { sessionStorage.setItem("ban-lead-done", "1"); } catch (e) {}
            setTimeout(function () { lm.classList.remove("open"); lm.setAttribute("aria-hidden", "true"); }, 2600);
          }
        } else {
          if (status) {
            status.textContent = res.error || "Something went wrong. Please try again or email us directly.";
            status.className = "form-status err";
          }
        }
      }).catch(function () {
        if (status) {
          status.textContent = "Could not send right now. Please email support@booksanation.com.";
          status.className = "form-status err";
        }
      }).finally(function () {
        if (btn) { btn.disabled = false; btn.textContent = btn.dataset.label || "Send message"; }
      });
    });
  });

  /* ---------- Live chat widget ---------- */
  var fab = document.getElementById("chat-fab");
  var panel = document.getElementById("chat-panel");
  if (fab && panel) {
    var log = panel.querySelector(".chat-log");
    var textarea = panel.querySelector("textarea[name=chat-body]");
    var nameInput = panel.querySelector("input[name=chat-name]");
    var emailInput = panel.querySelector("input[name=chat-email]");
    var sendBtn = panel.querySelector(".chat-send");
    var closeBtn = panel.querySelector(".chat-close");
    var sessionKey = "";
    var lastId = 0;
    var pollTimer = null;
    var greeted = false;

    try { sessionKey = sessionStorage.getItem("ban-chat-session") || ""; } catch (e) {}

    function addMsg(sender, body) {
      var div = document.createElement("div");
      div.className = "chat-msg " + sender;
      div.textContent = body;
      log.appendChild(div);
      log.scrollTop = log.scrollHeight;
    }

    function openPanel() {
      panel.classList.add("open");
      fab.setAttribute("aria-expanded", "true");
      var badge = fab.querySelector(".chat-badge");
      if (badge) badge.classList.add("hide");
      if (!greeted) {
        addMsg("system", "Welcome to Books A Nation. Tell us about your book. We reply here and by email.");
        greeted = true;
      }
      textarea.focus();
      startPoll();
    }

    function closePanel() {
      panel.classList.remove("open");
      fab.setAttribute("aria-expanded", "false");
      stopPoll();
    }

    fab.addEventListener("click", function () {
      panel.classList.contains("open") ? closePanel() : openPanel();
    });
    closeBtn.addEventListener("click", closePanel);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && panel.classList.contains("open")) closePanel();
    });

    /* Open chat from any "open live chat" link */
    document.querySelectorAll("[data-open-chat]").forEach(function (el) {
      el.addEventListener("click", function (e) { e.preventDefault(); openPanel(); });
    });

    function send() {
      var body = textarea.value.trim();
      if (!body) return;
      addMsg("visitor", body);
      textarea.value = "";
      postJSON("/api/chat/send/", {
        body: body,
        session: sessionKey,
        name: nameInput ? nameInput.value : "",
        email: emailInput ? emailInput.value : ""
      }).then(function (res) {
        if (res.ok && res.session) {
          if (!sessionKey) {
            addMsg("system", "Thanks, your message is with our team. Leave your email above and we'll reply there too.");
          }
          sessionKey = res.session;
          try { sessionStorage.setItem("ban-chat-session", sessionKey); } catch (e) {}
        }
      }).catch(function () {
        addMsg("system", "Message could not be sent. Please email support@booksanation.com.");
      });
    }

    sendBtn.addEventListener("click", send);
    textarea.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
    });

    function poll() {
      if (!sessionKey) return;
      fetch("/api/chat/poll/?session=" + encodeURIComponent(sessionKey) + "&after=" + lastId)
        .then(function (r) { return r.json(); })
        .then(function (res) {
          (res.messages || []).forEach(function (m) {
            lastId = Math.max(lastId, m.id);
            if (m.sender === "staff") addMsg("staff", m.body);
          });
        })
        .catch(function () {});
    }

    function startPoll() {
      if (pollTimer) return;
      pollTimer = setInterval(poll, 6000);
      poll();
    }
    function stopPoll() {
      if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
    }
  }
})();

/* ---------- Promo bar + lead-capture modal ---------- */
(function () {
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Promo bar dismiss (remember for the session)
  var promo = document.getElementById("promo-bar");
  var promoClose = document.getElementById("promo-close");
  try { if (promo && sessionStorage.getItem("ban-promo-closed") === "1") promo.classList.add("hide"); } catch (e) {}
  if (promoClose && promo) {
    promoClose.addEventListener("click", function () {
      promo.classList.add("hide");
      try { sessionStorage.setItem("ban-promo-closed", "1"); } catch (e) {}
    });
  }

  // Lead modal
  var modal = document.getElementById("lead-modal");
  if (!modal) return;
  function openModal() {
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  }
  function closeModal() {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    try { sessionStorage.setItem("ban-lead-done", "1"); } catch (e) {}
  }
  modal.querySelectorAll("[data-lead-close]").forEach(function (el) {
    el.addEventListener("click", closeModal);
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && modal.classList.contains("open")) closeModal();
  });
  document.querySelectorAll("[data-open-lead]").forEach(function (el) {
    el.addEventListener("click", function (e) { e.preventDefault(); openModal(); });
  });
  // Auto-show once per session, after a short delay
  var seen = false;
  try { seen = sessionStorage.getItem("ban-lead-done") === "1"; } catch (e) {}
  if (!seen) {
    setTimeout(function () {
      if (!modal.classList.contains("open")) openModal();
    }, reduce ? 15000 : 11000);
  }
})();
