# Books A Nation — booksanation.com

Independent book publishing services website. Python/Django, no runtime
dependency on any AI subscription. Owner: Sheldon.

## Stack

- Django 5.2 LTS (Python 3.12), SQLite in dev / PostgreSQL 16 in production
- Gunicorn + Nginx on Ubuntu 24.04 (GoDaddy VPS) — same pattern as Publishing Core
- Three.js (vendored at `static/core/js/vendor/`) powers the Studio demo only
- No other frontend dependencies; CSS/JS are hand-written in `static/core/`

## Run locally

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Open http://127.0.0.1:8000/. Admin at `/admin/` (`python manage.py createsuperuser`).

## Structure

- `core/data.py`: services, platforms, FAQ and studio-cover lists (single source of truth)
- `core/models.py`: Inquiry (contact form), ChatSession/ChatMessage (live chat)
- `templates/`: base + page templates; `static/core/`: css/js/images
- `static/core/js/home3d.js`: Three.js publishing globe (home page)
- `static/core/js/fx.js`: custom cursor with ember trail, magnetic buttons,
  orange page-sweep transitions (desktop pointer only, reduced-motion safe)
- `static/core/video/`: real animation videos rendered in house from our own
  Three.js scenes (static/anim/anim.html is the render harness; frames were
  captured headlessly and encoded with ffmpeg). No stock, no AI imagery.
- `static/core/img/showcase/`: original sample covers designed in house (invented
  titles and names; never real published books)
- `static/core/img/concepts/`: earlier abstract concept covers (kept as assets)
- `static/core/img/covers/`: client cover images, kept as an archive only.
  Not shown on the public site (owner's request). If ever used again: never
  stretch, recolor, retouch or fabricate content on these.
- Copy rule (owner): no em/en dashes, stylistic hyphens, hashtags, middots
  or decorative check marks anywhere in public copy or UI.
- Live chat: visitor widget on every page posts to `/api/chat/send/`; staff
  reply from Django admin (Chat sessions → add message with sender "Staff");
  the widget polls and shows staff replies.

## Deployment (summary — see DEPLOY.md)

1. Server: Ubuntu 24.04, Python 3.12, PostgreSQL 16, Nginx.
2. `.env` from `.env.example` (secret key, DB, Titan SMTP).
3. `python manage.py migrate && python manage.py collectstatic`
4. Gunicorn systemd service → Nginx reverse proxy → HTTPS (Let's Encrypt).
5. DNS: booksanation.com A record → VPS IP (GoDaddy DNS).

## SEO notes

- `sitemap.xml` (django.contrib.sitemaps) and `robots.txt` are served by the app.
- Every page has unique title/description, canonical URL, OG tags.
- JSON-LD: Organization (site-wide), FAQPage (/faq/).
- After launch: verify domain in Google Search Console, submit sitemap.
